import { Routes, RouterModule, PreloadAllModules, ExtraOptions } from '@angular/router';
// guard
import { LoginRouteGuardGuard } from 'app/core/auth/login-route-guard.guard';
import { SubscriptionRouteGuardGuard } from 'app/core/auth/subscription-route-guard.guard';
import { AgreementRouteGuardGuard } from 'app/core/auth/agreement-route-guard.guard';

import { MainViewComponent } from 'app/modules/main-view/main-view.component';
import { AppointmentComponent } from 'app/modules/appointment/appointment.component';
import { FileUploadComponent } from './shared/components/file-upload/file-upload.component';
import { PrintComponent } from 'app/modules/print/print.component';




const APP_ROUTES: Routes = [
    {
        path: '***',
        redirectTo: 'prelogin'
    },
    {
        path: 'clinic-view/clinics/:clinicId/facilities/:facilityId',
        component: MainViewComponent,
        canActivate: [LoginRouteGuardGuard, SubscriptionRouteGuardGuard, AgreementRouteGuardGuard],
        children: [
            { path: '', redirectTo: 'encounter/', pathMatch: 'full' },
            { path: 'doctors/:doctorId/appointments/:action', component: AppointmentComponent },
            { path: 'appointments/:action', component: AppointmentComponent },
        ]
    },
    {
        path: 'print',
        component: PrintComponent
    },
    {
        path: 'fileUpload',
        component: FileUploadComponent
    },


];

export const routingConfiguration: ExtraOptions = {
    paramsInheritanceStrategy: 'always',
    enableTracing: true
};
export let AppRouterModule = RouterModule.forRoot(APP_ROUTES);
