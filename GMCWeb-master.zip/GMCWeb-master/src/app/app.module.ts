import { BrowserModule } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { ToastrModule, ToastNoAnimation, ToastNoAnimationModule } from 'ngx-toastr';
import { SelectDropDownModule } from 'ngx-select-dropdown';
// import {NgxMaterialTimepickerModule} from 'ngx-material-timepicker';

// import { NgxMyDatePickerModule } from 'ngx-mydatepicker';
import { Ng4LoadingSpinnerModule } from 'ng4-loading-spinner';

// services
import { AuthService } from 'app/core/auth/auth.service';
import { TestService } from 'app/core/services/test.service';
import { AppRouterModule } from './app.routes';
import { AuthInterceptor } from 'app/core/auth/auth.interceptor';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { RestapiService } from 'app/core/services/restapi.service';
import { MedicineapiService } from 'app/shared/components/encounter-medicines-box/medicine.api.service';
import { UploadFileService } from 'app/core/services/upload-file.service';
import { UtilityService } from 'app/core/services/utility.service';
import { ClinicService } from 'app/core/services/clinic-service.service';
import { AppointmentEncounterService } from 'app/core/services/patient-encounter.service';
import { ParamSelectionService } from 'app/core/services/param-selection.service';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { DownloadFileService } from 'app/core/services/download-file.service';
import { ProfileService } from 'app/core/services/profile.service';
import { UniqueNameService } from 'app/core/services/unique-name.service';
import { PostCodeValidatorService } from './core/services/post-code-validator.service';

// guard
import { LoginRouteGuardGuard } from 'app/core/auth/login-route-guard.guard';
import { SubscriptionRouteGuardGuard } from 'app/core/auth/subscription-route-guard.guard';
import { AgreementRouteGuardGuard } from 'app/core/auth/agreement-route-guard.guard';


// components
import { AppComponent } from './app.component';
import { MainViewComponent } from 'app/modules/main-view/main-view.component';
import { AppointmentComponent } from 'app/modules/appointment/appointment.component';
import { PrintComponent } from 'app/modules/print/print.component';


// modules
import { PreloginModule } from 'app/modules/prelogin/prelogin.module';
import { SharedModule } from 'app/shared/shared.module';
import { SubscriptionModule } from 'app/modules/subscription/subscription.module';
import { RegistrationModule } from 'app/modules/registration/registration.module';
import { ProfileListModule } from 'app/modules/profile-list/profile-list.module';
import { InformationModule } from 'app/modules/information/information.module';
import { ProfileModule } from 'app/modules/profile/profile.module';
import { DocumentsModule } from 'app/modules/documents/documents.module';
import { SchedulesModule } from 'app/modules/schedules/schedules.module';
import { EncounterModule } from 'app/modules/encounter/encounter.module';
import { ImportDataModule } from 'app/modules/import-data/import-data.module';




@NgModule({
  declarations: [
    AppComponent,
    MainViewComponent,
    AppointmentComponent,
    PrintComponent,
  ],
  imports: [
    BrowserModule,
    CommonModule,
    PreloginModule,
    SubscriptionModule,
    RegistrationModule,
    ProfileListModule,
    ProfileModule,
    DocumentsModule,
    SchedulesModule,
    EncounterModule,
    ImportDataModule,
    InformationModule,
    SharedModule,
    HttpClientModule,
    AppRouterModule,
    FormsModule,
    HttpModule,
    ReactiveFormsModule,
    ToastNoAnimationModule,
    SelectDropDownModule,
    // NgxMaterialTimepickerModule.forRoot(),
    // NgxMyDatePickerModule.forRoot(),
    Ng4LoadingSpinnerModule.forRoot(),

    ToastrModule.forRoot({
      toastComponent: ToastNoAnimation,
    })
  ],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: AuthInterceptor,
      multi: true
    },
    TestService,
    ProfileService,
    UniqueNameService,
    AuthService,
    RestapiService,
    MedicineapiService,
    JwtHelperService,
    AppointmentEncounterService,
    UploadFileService,
    ParamSelectionService,
    ConfirmationPopupService,
    LoginRouteGuardGuard,
    SubscriptionRouteGuardGuard,
    AgreementRouteGuardGuard,
    UtilityService,
    ClinicService,
    DownloadFileService,
    PostCodeValidatorService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
