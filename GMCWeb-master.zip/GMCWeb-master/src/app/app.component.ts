import { Component, ViewContainerRef, HostListener, OnInit, ElementRef } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/forkJoin';
import { TestService } from 'app/core/services/test.service';
import { AuthService } from 'app/core/auth/auth.service';
import 'rxjs/add/operator/pairwise';
import { Router, ActivatedRoute } from '@angular/router';

declare var $: any;

declare var $: any;

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  message: string;
  QA_TESTING_AUTHTOKEN = 'cWF0ZXN0aW5nYXV0aHRva2Vu';

  constructor(private testService: TestService,
    private authService: AuthService,
    private activateRoute: ActivatedRoute,
    private router: Router,
    vRef: ViewContainerRef) {

  }


  @HostListener('window:popstate', ['$event'])
  browserBack($event) {
    $('.modal-backdrop').remove();
  }

  test401() {
    console.log('test 401');
    this.testService.getData()
      .subscribe((response: any) => {
        this.message = `Worked with status = ${response.status}`;
      },
        error => this.message = `Failed with status = ${error.status}`);
  }

  test401Multiple() {
    console.log('test multiple 401');
    const dataObservable$ = this.testService.getData();
    const lookupObservable$ = this.testService.getLookup();

    Observable.forkJoin(dataObservable$, lookupObservable$)
      .subscribe(([dataResult, lookupResult]) => {
        this.message = `Worked with getData status = ${dataResult.status} and getLookup status = ${lookupResult.status}`;
      },
        error => this.message = `Failed with status = ${error.status}`);
  }
  ngOnInit() {
    this.router.events.pairwise().subscribe((e) => {
      // $('body').scrollTop(0);
      document.body.scrollTop = 0;
      document.documentElement.scrollTop = 0;
    });

    // if (localStorage.getItem('authToken') === null || localStorage.getItem('authToken') === 'null') {
    //   setTimeout(() => {
    //     const firstParam: string = this.activateRoute.snapshot.queryParamMap.get('authToken');
    //     if (firstParam === this.QA_TESTING_AUTHTOKEN) {
    //         localStorage.setItem('authToken', this.QA_TESTING_AUTHTOKEN);
    //     } else {
    //         localStorage.setItem('authToken', null);
    //         this.router.navigate(['under-maintenance']);
    //     }
    // }, 200);
    // }
  }
}
