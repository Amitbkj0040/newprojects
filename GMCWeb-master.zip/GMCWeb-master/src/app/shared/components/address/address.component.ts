import { Component, OnInit, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { PostCode } from 'app/core/validators/postcode.validator';
import { Country, DEFAULT_COUNTRY } from 'app/core/models/country';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Observable } from 'rxjs/Observable';
import { RestapiService } from 'app/core/services/restapi.service';
import { UtilityService } from 'app/core/services/utility.service';
import { PostCodeValidatorService } from 'app/core/services/post-code-validator.service';

@Component({
  selector: 'app-address',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.css']
})
export class AddressComponent implements OnInit, OnChanges {
  @Input() mode: string;
  @Input() options: AddressOptions;
  @Input() formGroup: FormGroup;
  @Input() get mandatory() {
    return this.isMandatory;
  }
  @Input() selectedCountry: Country = DEFAULT_COUNTRY;
  @Output() formGroupChange = new EventEmitter();
  @Output() valid = new EventEmitter();
  @Output() mandatoryChange = new EventEmitter();
  @Output() countryChange = new EventEmitter();
  set mandatory(value) {
    this.isMandatory = value;
    this.mandatoryChange.emit(value);
  }

  isMandatory: boolean;
  addressForm: FormGroup;
  postCodeValidator = new PostCode();
  isZipCodeRequired = true;
  cityApiEndPoint = APIEndPoint.GET_CITIES;
  countryApiEndPoint = APIEndPoint.GET_COUNTRIES;

  constructor(
    public formBuilder: FormBuilder,
    public restApiService: RestapiService,
    public utilityservice: UtilityService,
    public postCodeValidatorService: PostCodeValidatorService
  ) { }

  ngOnInit() {
    this.createAddressForm();
    this.onAddressFormChange();
  }


  setCity(value) {
    this.addressForm.controls['city'].setValue(value);
  }

  resetCity() {
    this.addressForm.controls['city'].setValue(null);
  }

  setCountry(value) {
    this.selectedCountry = value && value.id ? value : null;
    this.resetCity();
    this.addressForm.controls['country'].setValue(value && value.id ? value : null);
    if (this.selectedCountry) {
      this.updateZipValidation(this.selectedCountry.countryIATACode);
    } else {
      this.updateZipValidation(null);
    }
    this.countryChange.emit(value);
  }

  updateZipValidation(countryIATACode) {
    if (this.addressForm) {
      const zip = this.addressForm.get('zip');
      this.isZipCodeRequired = this.postCodeValidatorService.isZipCodeRequired(countryIATACode);
      zip.setValidators([this.postCodeValidator.valid(countryIATACode)]);
      zip.setValue(zip.value);
    }
  }


  onAddressFormChange() {
    this.addressForm.valueChanges.subscribe(address => {
      this.formGroupChange.emit(address);
      this.valid.emit(this.addressForm.valid && (this.options.isVirtualClinic ? address.country : true)
        && address.city && (address.address1 && address.address1.length > 0));
      this.checkIsAddressMandatory(address);
    });
  }

  checkIsAddressMandatory(address) {
    if (this.utilityservice.areAllFieldsNull(address.city)) {
      address.city = null;
    }
    if (this.utilityservice.areAllFieldsNull(address.country)) {
      address.country = null;
    }

    const ADDRESS = { ...address };
    delete ADDRESS.id;
    if (this.utilityservice.areAllFieldsNull(ADDRESS) && !this.options.mandatory) {
      this.mandatory = false;
    } else {
      this.mandatory = true;
    }
  }


  createAddressForm() {
    this.addressForm = this.formBuilder.group({
      id: null,
      address1: [null],
      address2: [null],
      city: [{
        id: null,
        name: null
      }],
      country: [{
        id: null,
        name: null,
        countryCode: null,
        countryISD: null,
      }],
      zip: [null],
      locality: [null]
    });
    this.addressForm = this.formGroup;
  }

  updateCountryValidation() {
    this.addressForm.get('country').setValidators(null);
    this.addressForm.get('country').setValue(this.addressForm.get('country').value);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes && changes['selectedCountry'] && changes['selectedCountry'].currentValue) {
      const countryCode = changes['selectedCountry'].currentValue.countryIATACode ?
        changes['selectedCountry'].currentValue.countryIATACode : null;
      setTimeout(() => {
        this.updateZipValidation(countryCode);
        if (!this.options.isVirtualClinic) {
          this.updateCountryValidation();
        }
      }, 100);
    }
  }
}


interface AddressOptions {
  isVirtualClinic: boolean;
  disableCountry: boolean;
  disableCity: boolean;
  showLocality: boolean;
  mandatory: boolean;
}
