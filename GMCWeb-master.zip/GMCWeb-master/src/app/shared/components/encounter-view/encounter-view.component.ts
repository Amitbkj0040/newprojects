import { Component, OnInit, Input, Output, EventEmitter, ViewEncapsulation } from '@angular/core';
import { Encounter } from 'app/core/models/app.models';
import { RestapiService } from 'app/core/services/restapi.service';
import { Router, ActivatedRoute } from '@angular/router';
import { DownloadFileService } from 'app/core/services/download-file.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-encounter-view',
  templateUrl: './encounter-view.component.html',
  styleUrls: ['./encounter-view.component.css'],
})
export class EncounterViewComponent implements OnInit {
  @Input() encounterView: any;
  @Input() docType = 'HEALTH_RECORD';
  @Input() shared?: string;
  @Input() options?: { clinicId?: string, facilityId?: string, doctorId?: string };
  @Input() from: string;
  @Output() back = new EventEmitter();
  public showPresShare = false;
  public showAccess = false;
  public encounterId: string;
  public patientId: string;

  @Output() print = new EventEmitter();

  constructor(private restapiservice: RestapiService,
    private router: Router,
    public downloadFileService: DownloadFileService,
    private location: Location,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    console.log('from ', this.from, this.shared);
  }

  printPrescription() {
    this.print.emit(true);
  }


  viewDocument(fileUploadId) {
    this.downloadFileService.downloadDocument(fileUploadId).subscribe(resp => {
      console.log('download document response', resp);
      const type = resp.type;
      this.viewFile(resp, type);
    });
  }
  viewFile(resp, type) {
    const blob = new Blob([resp], { type: type });
    const url = window.URL.createObjectURL(blob);
    const newWindow = window.open(url, '_blank');
    if (!newWindow) {
      alert('Please allow pop-ups on this site!');
    }
  }
  onShare(encounterid, patientid) {
    this.showPresShare = !this.showPresShare;
    this.encounterId = encounterid;
    this.patientId = patientid;

  }
  onAccess(encounterid, patientid) {
    console.log('hello');
    this.showAccess = !this.showAccess;
    console.log('hello', this.showAccess);
    this.encounterId = encounterid;
    this.patientId = patientid;
  }

  onBack() {
    this.encounterView = null;
    this.back.emit('');
  }
}
