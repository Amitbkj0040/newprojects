import { Component, OnInit } from '@angular/core';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';



@Component({
  selector: 'app-confirmation-popup',
  templateUrl: './confirmation-popup.component.html',
  styleUrls: ['./confirmation-popup.component.css']
})
export class ConfirmationPopupComponent implements OnInit {
  public confimationData: { message, showPopup };
  constructor(
    public confirmationPopup: ConfirmationPopupService
  ) { }

  public userAction(value) {
    this.confirmationPopup.toggle(value);
  }

  ngOnInit() {
    this.confirmationPopup.showConfirmationPopup.subscribe(options => {
      this.confimationData = options;
    });
  }

}


