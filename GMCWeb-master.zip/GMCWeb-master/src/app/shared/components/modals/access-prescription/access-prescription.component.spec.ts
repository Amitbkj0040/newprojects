import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccessPrescriptionComponent } from './access-prescription.component';

describe('AccessPrescriptionComponent', () => {
  let component: AccessPrescriptionComponent;
  let fixture: ComponentFixture<AccessPrescriptionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccessPrescriptionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccessPrescriptionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
