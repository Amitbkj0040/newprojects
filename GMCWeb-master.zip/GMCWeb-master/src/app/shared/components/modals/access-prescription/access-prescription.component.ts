import { Component, OnInit, Output, Input, EventEmitter, ViewEncapsulation } from '@angular/core';
import { APIDef, APIEndPoint } from 'app/core/models/ApiEndPoint';
import { RestapiService } from 'app/core/services/restapi.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { Dictionary } from 'app/core/models/dictionary';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-access-prescription',
  templateUrl: './access-prescription.component.html',
  styleUrls: ['./access-prescription.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AccessPrescriptionComponent implements OnInit {
  @Input() showModal: boolean;
  @Output() hide = new EventEmitter<boolean>();
  @Input() options: { clinicId: string, facilityId: string, doctorId: string, patientId: string, encounterId: string };
  // shareForm: FormGroup;
  // public isRequesting = false;
  // public prescriptionwrapper = [];
  // public writeMessage = false;
  // public isAdd = true;
  // public today = new Date();
  // public newDate: any;
  public docFirstName: string;
  public docLastName: string;
  public accessDays: any;
  public accessId: string;
  sharedById: any;
  sharedDataId: any;
  public accessList = [];
  public isRequesting = false;

  constructor(public formBuilder: FormBuilder,
    public restapiService: RestapiService,
    public toastrService: ToastrService,
    public confirmationPopup: ConfirmationPopupService) { }

  ngOnInit() {
    console.log(this.options.clinicId, this.options.facilityId, this.options.doctorId, this.options.patientId, this.options.encounterId);
    this.getAccessList();
    this.getDoctorProfile();
  }

  onClose() {
    this.hide.emit(false);
    this.showModal = false;
    console.log('show modal', this.showModal);
  }

  getDoctorProfile() {
    this.restapiService.invoke(APIEndPoint.GET_DOCTOR_BY_ID, { clinicId: this.options.clinicId, doctorId: this.options.doctorId },
      null).subscribe((res: any) => {
        this.docFirstName = res.firstName;
        this.docLastName = res.lastName;
      });
  }

  getAccessList() {
    this.isRequesting = true;
    this.restapiService.invoke<any>(APIEndPoint.GET_ACCESS_PERMISSION_LIST,
      {
        clinicId: this.options.clinicId, staffId: this.options.doctorId, encounterId: this.options.encounterId
      }, null).subscribe(resp => {
        this.isRequesting = false;
        if (resp.data !== null) {
          this.accessList = resp.data;
          this.sharedById = resp.sharedById;
          this.sharedDataId = resp.sharedDataId;
        } else {
          this.accessList = [];
        }
      });
  }

  onEdit(accessId) {
    this.accessId = accessId;
  }

  onPermissionCancel(accessId) {
    this.accessId = null;
    this.getAccessList();
  }

  onChange(access: any) {
    const today = new Date();
    today.setDate(today.getDate() + access.accessInDays);
    access.accessExpireDate = today;
  }

  onGrantAccess(access) {
    const body = _.cloneDeep(access);
    body.sharedBy = {};
    body.sharedBy.id = this.sharedById;
    if (body.sharedWithInternalDoctor !== null) {
      delete body.sharedWithInternalDoctor;
      body.sharedWithInternalDoctor = { id: access.sharedWithInternalDoctor.id, name: access.sharedWithInternalDoctor.name };
    }
    this.restapiService.invoke<any>(APIEndPoint.GRANT_SHARED_ENCOUNTER,
      {
        clinicId: this.options.clinicId, emrId: this.options.encounterId
      }, body, { days: access.accessInDays }).subscribe(resp => {
        this.accessId = null;
        this.toastrService.success('Successfully Granted Access');
      });
  }

  onRevokeAccess(access) {
    this.confirmationPopup.confirm({ message: Dictionary.REVOKE_ACCESS }).subscribe(data => {
      if (data) {
        const shareDocumentRevokeVO = {
          'sharedById': this.sharedById, 'sharedDataId': this.sharedDataId,
          'sharedWithExternal': access.sharedWithExternal, 'sharedWithId': access.id,
          'sharedWithInternalDoctorId': access.sharedWithInternalDoctor !== null ? access.sharedWithInternalDoctor.id : null
        };
        this.restapiService.invoke<any>(APIEndPoint.REVOKE_SHARED_ENCOUNTER,
          {
            clinicId: this.options.clinicId, doctorId: this.options.doctorId
          }, shareDocumentRevokeVO).subscribe(resp => {
            this.toastrService.success('Successfully Revoked Access');
            this.getAccessList();
          });
      }
    });
  }

}
