import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { AppointmentSlotForDates, AppointmentType } from 'app/core/models/app.models';
import { from } from 'rxjs/observable/from';
import { Router, ActivatedRoute } from '@angular/router';
import { RestapiService } from 'app/core/services/restapi.service';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Subject } from 'rxjs/Subject';
import { Dictionary } from 'app/core/models/dictionary';

@Component({
  selector: 'app-appointment-slot',
  templateUrl: './appointment-slot.component.html',
  styleUrls: ['./appointment-slot.component.css']
})
export class AppointmentSlotComponent implements OnInit {
  @Input() update_appointment: boolean;
  @Input() mode?= 'EDIT';
  @Input() isToday: boolean;
  @Input() seletedPatientDetails: any;
  @Input() selectedColIndex: number;
  @Input() futureDate;
  @Input() options: { clinicId: string, facilityId: string, doctorId: string, patientId: string, appointmentId: string, from: string };
  @Input() appointment$: Observable<AppointmentSlotForDates[]>;
  @Input() futureAppointments$?: Observable<AppointmentSlotForDates[]>;
  @Output() hide = new EventEmitter<boolean>();
  @Output() refreshAppointmentEvent = new EventEmitter<any>();
  @Output() updateSlotTime = new EventEmitter<any>();

  loading: boolean;
  public appointmentSuggestion$: Observable<AppointmentSlotForDates[]>;
  public selectedIndex: any;
  public hasSlots: boolean;
  private unsubscribe = new Subject<void>();

  constructor(public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    public toastrService: ToastrService,
    public confirmationPopup: ConfirmationPopupService) { }

  ngOnInit() {
    console.log('hello this is the following', this.seletedPatientDetails);

    if (this.futureDate) {
      this.appointmentSuggestion$ = this.restapiservice.invoke(APIEndPoint.GET_SLOTS_APPOINTMENTS,
        { clinicId: this.options.clinicId, facilityId: this.options.facilityId, doctorId: this.options.doctorId, }, null,
        { startDate: this.futureDate, endDate: this.futureDate });
    } else {
      if (this.isToday) {
        this.appointmentSuggestion$ = this.appointment$;
      } else {
        this.appointmentSuggestion$ = this.futureAppointments$;
      }
    }
  }

  public closeAppointmentUpdateModal(updatedAppointment) {
    this.hide.emit(true);
    this.update_appointment = false;
    this.refreshAppointmentEvent.emit(updatedAppointment.startTime);
  }

  public updateAppointment(appointmentSlot, date, selectedIndex, isPastTimeSlot) {
    console.log('appointment mode is', this.mode, appointmentSlot);
    if (this.seletedPatientDetails && this.seletedPatientDetails.appointmentType !== AppointmentType.VIRTUAL) {
      const isVirtualPatient = this.seletedPatientDetails.appointmentType === AppointmentType.VIRTUAL;
      console.log('isVirtualAppointment', isVirtualPatient);
      const body = {
        appointmentDate: date.dates[this.selectedColIndex],
        appointmentStatus: 'CONFIRMED',
        startTime: appointmentSlot[this.selectedColIndex].slot,
        emr: this.seletedPatientDetails.encounter,
        patient: { id: this.seletedPatientDetails.patient.id }
      };
      this.loading = true;
      if (!isPastTimeSlot) {
        this.restapiservice
          .invoke<any>(isVirtualPatient ? APIEndPoint.UPDATE_VIRTUAL_APPOINTMENT : APIEndPoint.UPDATE_APPOINTMENT,
            // tslint:disable-next-line:max-line-length
            { clinicId: this.options.clinicId, facilityId: this.options.facilityId, doctorId: this.options.doctorId, appointmentId: this.options.appointmentId, virtualAppointmentId: this.seletedPatientDetails.id }, isVirtualPatient ? { ...this.seletedPatientDetails, startTime: appointmentSlot[0].slot } : body)
          .takeUntil(this.unsubscribe)
          .subscribe(updatedAppointment => {
            // tslint:disable-next-line:max-line-length
            this.loading = false;
            // tslint:disable-next-line: max-line-length
            this.toastrService.success(Dictionary.SUCCESSFUL_TIME_SLOT_UPDATION({ Slot: updatedAppointment.startTime, EntityName: updatedAppointment.patient.firstName }));
            this.closeAppointmentUpdateModal(updatedAppointment);

          });
      } else {
        this.toastrService.error('You Cannot Select Past time slot');
        this.loading = false;
      }
    } else {
      this.updateSlotTime.emit(appointmentSlot[this.selectedColIndex].slot);
      this.hide.emit(false);
    }
    // console.log('Appointment', this.seletedPatientDetails);
  }

  public checkForSlots(slotAppointments) {
    return slotAppointments.filter(slot => (slot[this.selectedColIndex] &&
      slot[this.selectedColIndex].appointment === null)).length > 0 ? true : false;
  }

  public editPatientProfile(patienDetails) {
    this.router.navigate([`./clinic-view/clinics/${this.options.clinicId}/patients/${this.seletedPatientDetails.patient.id}/edit`],
      {
        queryParams: {
          doctorId: this.options.doctorId,
          facilityId: this.options.facilityId,
          from: this.options.from
        }
      }
    );
  }



}
