import { Component, OnInit, Input, Output, SimpleChanges, OnChanges, EventEmitter } from '@angular/core';
import { RestapiService } from 'app/core/services/restapi.service';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { PasswordValidation } from './passwordValidation';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { ToastrService } from 'ngx-toastr';
import { Dictionary } from 'app/core/models/dictionary';
import { ChangePassword } from 'app/core/models/changePassword';
// Password Validation File must be in model


@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit, OnChanges {
  @Input('userName') userName: string;
  @Output() hide = new EventEmitter<boolean>();
  changePasswordForm: FormGroup;
  public changePassword: ChangePassword = {
    loginName: null,
    oldPassword: null,
    newPassword: null,
    confirmNewPassword: null
  };

  constructor(public formBuilder: FormBuilder,
    public restapiService: RestapiService,
    public toastrService: ToastrService) { }

  public onSummit() {
    const formObj = this.changePasswordForm.getRawValue();
    if (formObj.newPassword && formObj.confirmNewPassword) {
      this.restapiService.invoke<ChangePassword>(APIEndPoint.CHANGE_PASSWORD, null, formObj).subscribe(resp => {
        this.toastrService.success(Dictionary.SUCCESSFUL_PASSWORD_CHANGED);
        this.hide.emit(false);
      }, error => {
        console.log('error ', error);
      });
    } else {
      this.toastrService.error('Password did not match');
    }
  }

  createForm() {
    this.changePasswordForm = this.formBuilder.group({
      loginName: [this.userName],
      oldPassword: [this.changePassword.oldPassword, Validators.compose([Validators.required,
      Validators.pattern(/^[a-zA-Z0-9!@#$%^&*()_-]{8,20}$/)])],
      newPassword: [this.changePassword.newPassword, Validators.compose([Validators.required,
      Validators.pattern(/^[a-zA-Z0-9!@#$%^&*()_-]{8,20}$/)])],
      confirmNewPassword: [this.changePassword.confirmNewPassword, Validators.required],
    }, {
        validator: PasswordValidation.MatchPassword
      }
    );
  }

  hideModalInParent() {
    this.hide.emit(false);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes && changes['userName'].currentValue) {
      console.log('user naeeadfasdf asdfasdf', this.userName);
    }
  }

  ngOnInit() {
    this.createForm();
  }

}
