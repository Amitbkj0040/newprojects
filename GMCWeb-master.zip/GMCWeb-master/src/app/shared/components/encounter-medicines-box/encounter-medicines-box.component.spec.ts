import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EncounterMedicinesBoxComponent } from './encounter-medicines-box.component';

describe('EncounterMedicinesBoxComponent', () => {
  let component: EncounterMedicinesBoxComponent;
  let fixture: ComponentFixture<EncounterMedicinesBoxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EncounterMedicinesBoxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EncounterMedicinesBoxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
