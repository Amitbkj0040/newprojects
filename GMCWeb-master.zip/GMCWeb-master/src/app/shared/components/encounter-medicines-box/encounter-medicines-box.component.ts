import { Component, OnInit, Input, ElementRef, HostListener, OnDestroy } from '@angular/core';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';
import { APIEndPoint, APIDef } from './medicine.apiEndPoints';
import { MedicineapiService } from './medicine.api.service';
import * as _isEmpty from 'lodash/isEmpty';
import {
  Medicine, MedQuantity, MedSchedule,
  MedTime, MedFrequency, MedDuration, Doctor, MedRoute
} from './model';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { FindValueSubscriber } from 'rxjs/operators/find';

@Component({
  selector: 'app-encounter-medicines-box',
  templateUrl: './encounter-medicines-box.component.html',
  styleUrls: ['./encounter-medicines-box.component.css']
})
export class EncounterMedicinesBoxComponent implements OnInit, OnDestroy {
  @Input() api: APIDef;
  @Input() options: { placeholder: string };
  @Input() keyName: string = null;
  @Input() selectedValues: Medicine[];
  public unsubscribe = new Subject();
  public searchField: FormControl;
  public searchForm: FormGroup;
  public results$: Observable<{ name: string }[] | string[]>;
  public selectedTimes: string[] = [];
  public selectedDuration: string;
  public selectedShedules: string[] = [];
  public selectedFrequency: string;
  public selectedRoute: string;
  public selectedQuantity: string;
  public medQuantities$: Observable<MedQuantity[]>;
  public medFrequencies$: Observable<MedFrequency[]>;
  public medRoutes$: Observable<MedRoute[]>;
  public medSchedules$: Observable<MedSchedule[]>;
  public medTimings$: Observable<MedTime[]>;
  public medDurations$: Observable<MedDuration[]>;
  public selectedValues$: Observable<Medicine[]>;
  public selectedIndex = 0;
  public resultLength: number;
  public result: any[] = [];
  public selectedMedIndex: number;
  public isSuggestionShow = false;
  public customMedTime: string[] = [];
  public customMedDurationDay: string[] = [];
  public customMedDurationMonth: string[] = [];
  public customMedFrequency: string[] = [];
  public customMedSchedule: string[] = [];
  public customMedQuantitySpoon: string[] = [];
  public customMedQuantityTablet: string[] = [];
  public customMedQuantityMl: string[] = [];
  public medSchedules: MedSchedule[] = [];
  public hideAlert: boolean;
  currentUser = 'Please select the value';

  constructor(
    private fb: FormBuilder,
    private medicineapiService: MedicineapiService,
    public elemRef: ElementRef
  ) {
    this.searchField = new FormControl();
    this.searchForm = fb.group({ search: this.searchField });
    this.results$ = this.searchField.valueChanges
      .debounceTime(400)
      .switchMap(term => this.medicineapiService.invoke<{ name: string }[] | string[]>(this.api, {}, null, { name: term })).map(data =>
        this.getResultLength(data)
      );
  }

  public getResultLength(data) {
    this.result = data;
    this.resultLength = data.length;
    this.selectedIndex = 0;
    return data;
  }

  @HostListener('document:click', ['$event']) onClick(event) {
    if (!this.elemRef.nativeElement.contains(event.target)) {
      this.isSuggestionShow = false;
    }
  }

  @HostListener('keydown', ['$event']) keydown(event) {
    this.handleKeyDown(event);
  }

  public handleKeyDown(event) {
    switch (event.keyCode) {
      case 40:
        if (this.selectedIndex < this.resultLength - 1) {
          this.selectedIndex++;
        } else {
          this.selectedIndex = this.resultLength - 1;
        }
        this.isSuggestionShow = true;
        break;
      case 38:
        if (this.selectedIndex > 0) {
          this.selectedIndex--;
        } else {
          this.selectedIndex = 0;
        }
        break;
      case 9:
        this.isSuggestionShow = false;
        break;
      case 13:
        this.handleClick(this.selectedIndex);
        break;
      default:
        break;
    }
  }


  public handleClick(index) {
    const value: Medicine = this.result[index];
    this.select(value);
  }

  public removeItem(index: number) {
    this.selectedValues.splice(index, 1);
    this.customMedTime = [];
    this.customMedDurationDay = [];
    this.customMedDurationMonth = [];
    this.customMedFrequency = [];
    this.customMedSchedule = [];
    this.customMedQuantityMl = [];
    this.customMedQuantitySpoon = [];
    this.customMedQuantityTablet = [];
  }
  public addCustomValue() {
    this.select(this.searchForm.value.search);
    this.searchForm.controls['search'].setValue('');
  }
  public select(med: Medicine) {
    console.log('medicine from select', med);
    if (!this.selectedValues.find(ele => ele.name === med.name)) {
      const medicine: Medicine = {
        medicineId: med.medicineId,
        name: med.name,
        quantity: '',
        frequency: '',
        route: '',
        time: [],
        duration: '',
        schedule: [],
        tagList: [],
        activeTag: null
      };
      if (medicine.name) {
        this.selectedValues.push(medicine);
        this.selectedMedIndex = this.selectedValues.length - 1;
      }
      if (typeof med === 'string' && !this.selectedValues.includes(med)) {
        medicine.name = med;
        this.selectedValues.push(medicine);
      }


      // if (this.selectedValues.length === 0 && this.searchField.value) {
      // medicine.name = this.searchField.value;
      // this.selectedValues.push(medicine);
      // }
      this.getMedicineTagList(med.medicineId, true);
    }
    this.searchForm.controls['search'].setValue(null);
    this.isSuggestionShow = false;
  }


  public getMedicineTagList(medicineId, isNewMedicine = false) {
    this.medicineapiService.invoke(APIEndPoint.GET_TAGLIST_BY_MED_ID, null, null,
      { medicineId }).takeUntil(this.unsubscribe).subscribe((res) => {
        this.selectedValues.some((element, medIndex) => {
          if (element.medicineId === medicineId) {
            element.tagList = res.tagList;
            element.activeTag = element.activeTag ? element.activeTag : null;
            // const selectedtag = res.tagList.find((elem: any) => elem.isDefault);
            // element.activeTag = selectedtag.tagId ? selectedtag.tagId : res.tagList[0].tagId;
            // if (isNewMedicine) {
            //   if (selectedtag) {
            //     this.updateInstruction(selectedtag.tagId, medIndex);
            //   } else {
            //     this.updateInstruction(res.tagList[0].tagId, medIndex);
            //   }
            // }
            return true;
          }
        });
      });
  }
  public updateInstruction(tagId, medIndex) {
    console.log('medindex', medIndex);
    if (tagId !== 'null') {
      this.medicineapiService.invoke(APIEndPoint.GET_INSTUCTIONS_BY_TAG_ID, null, null,
        { tagId }).takeUntil(this.unsubscribe).subscribe((res) => {
          console.log('response from medicine', res);
          const updatedvalue = {
            ...this.selectedValues[medIndex],
            schedule: res.schedule,
            time: res.time,
            duration: res.duration,
            frequency: res.frequency,
            route: res.route,
            quantity: res.quantity
          };
          this.selectedValues[medIndex] = updatedvalue;
          this.customValueInit();
        });
    }
  }

  medTimeChanged(medTime: MedTime, event, medIndex: number, islastTime: boolean) {
    if (event.target.checked) {
      if (islastTime) {
        if (medTime.name.indexOf('|') === -1) {
          this.selectedValues[medIndex].time.push(this.customMedTime[medIndex]);
        } else {
          if (this.customMedTime[medIndex]) {
            this.selectedValues[medIndex].time.push(medTime.name.replace('|', this.customMedTime[medIndex]));
          } else {
            event.target.checked = false;
            // alert('please enter the value');
            this.hideAlert = true;
          }
        }
      } else {
        this.selectedValues[medIndex].time.push(medTime.name);
      }
    } else {

      if (islastTime) {

        this.selectedValues[medIndex].time.splice(this.selectedValues[medIndex].time.
          indexOf(medTime.name.replace('|', this.customMedTime[medIndex]), 1));
        this.customMedTime[medIndex] = '';
      } else {
        this.selectedValues[medIndex].time.splice(this.selectedValues[medIndex].time.indexOf(medTime.name), 1);
      }
    }
  }

  medScheduleChaged(medSchedule: MedSchedule, event, medIndex: number, isLastSchedule) {
    if (event.target.checked) {
      if (isLastSchedule) {
        if (medSchedule.name.indexOf('|') === -1) {
          this.selectedValues[medIndex].schedule.push(this.customMedSchedule[medIndex]);
        } else {
          if (this.customMedSchedule[medIndex]) {
            this.selectedValues[medIndex].schedule.push(medSchedule.name.replace('|', this.customMedSchedule[medIndex]));
          } else {
            event.target.checked = false;
            this.hideAlert = true;
            // alert('please enter the value');
          }
        }
      } else {
        this.selectedValues[medIndex].schedule.push(medSchedule.name);
      }
    } else {

      if (isLastSchedule) {
        this.selectedValues[medIndex].schedule.splice(this.selectedValues[medIndex].schedule.
          indexOf(this.customMedSchedule[medIndex]), 1);
        this.customMedSchedule[medIndex] = '';

      } else {
        this.selectedValues[medIndex].schedule.splice(this.selectedValues[medIndex].schedule.indexOf(medSchedule.name), 1);
      }
    }
  }

  selectDuration(duration: string, medIndex: number, event, islastDuration: boolean) {
    if (event.target.checked) {
      if (islastDuration) {
        if (this.customMedDurationMonth[medIndex]) {
          this.selectedValues[medIndex].duration = duration.replace('|', this.customMedDurationMonth[medIndex]);
          this.customMedDurationDay[medIndex] = '';
        } else {
          event.target.checked = false;
          this.hideAlert = true;
          // alert('please enter the value');
        }
      } else {
        if (this.customMedDurationDay[medIndex]) {
          this.selectedValues[medIndex].duration = duration.replace('|', this.customMedDurationDay[medIndex]);
          this.customMedDurationMonth[medIndex] = '';
        } else {
          event.target.checked = false;
          this.hideAlert = true;
          // alert('please enter the value');
        }
      }

    }
  }

  selectRoute(route: string, medIndex: number) {
    this.selectedValues[medIndex].route = route;
  }

  selectFrequency(frequency: string, medIndex: number, event, islastFreq) {
    if (event.target.checked) {
      if (islastFreq) {
        if (this.customMedFrequency[medIndex]) {
          this.selectedValues[medIndex].frequency = frequency.replace('|', this.customMedFrequency[medIndex]);
        } else {
          event.target.checked = false;
          this.hideAlert = true;
          // alert('please enter the value');
        }
      } else {
        this.selectedValues[medIndex].frequency = frequency;
        this.customMedFrequency[medIndex] = '';
      }
    }
  }

  selectQuantity(quantity: string, medIndex: number, event, islastQuantity, isSecondLastQuantity) {
    if (event.target.checked) {
      if (islastQuantity) {
        if (this.customMedQuantityMl[medIndex]) {
          this.selectedValues[medIndex].quantity = quantity.replace('|', this.customMedQuantityMl[medIndex]);
          this.customMedQuantityTablet[medIndex] = '';
          this.customMedQuantitySpoon[medIndex] = '';
        } else {
          event.target.checked = false;
          this.hideAlert = true;
          // alert('please enter the value');
        }
      } else if (isSecondLastQuantity) {
        if (this.customMedQuantityTablet[medIndex]) {
          this.selectedValues[medIndex].quantity = quantity.replace('|', this.customMedQuantityTablet[medIndex]);
          this.customMedQuantityMl[medIndex] = '';
          this.customMedQuantitySpoon[medIndex] = '';
        } else {
          event.target.checked = false;
          this.hideAlert = true;
          // alert('please enter the value');
        }
      } else {
        if (this.customMedQuantitySpoon[medIndex]) {
          this.selectedValues[medIndex].quantity = quantity.replace('|', this.customMedQuantitySpoon[medIndex]);
          this.customMedQuantityMl[medIndex] = '';
          this.customMedQuantityTablet[medIndex] = '';
        } else {
          event.target.checked = false;
          this.hideAlert = true;
          // alert('please enter the value');
        }
      }
    }
  }

  customValueInit() {
    if (this.selectedValues.length > 0) {
      if (this.selectedValues[this.selectedValues.length - 1].schedule.length >= 0) {
        console.log('here is selected values', this.selectedValues);
        this.selectedValues.forEach((medicine, index) => {
          console.log('here is medicine and its index', medicine, index);
          medicine[index] = {
            ...medicine, tagList: medicine.tagList ? medicine.tagList : [],
            activeTag: medicine.activeTag ? medicine.activeTag : null
          };
          console.log('here is medicine nd tag', medicine, medicine.tagList);
          if (medicine[index].tagList.length > 0) {
            this.getMedicineTagList(medicine.medicineId, false);
          }

          if (medicine.time.length === 0) {
            this.customMedTime[index] = '';
          } else {
            medicine.time.forEach(time => {
              time.split(' ').forEach(ele => {
                if (!isNaN(parseInt(ele, 10))) {
                  this.customMedTime[index] = ele;
                }
              });
            });
          }

          if (!medicine.frequency) {
            this.customMedFrequency[index] = '';
          } else {
            medicine.frequency.split(' ').forEach(ele => {
              if (!isNaN(parseInt(ele, 10))) {
                this.customMedFrequency[index] = ele;
              }
            });
          }

          try {
            if (!medicine.duration) {
              this.customMedDurationDay[index] = '';
              this.customMedDurationMonth[index] = '';
            } else {
              if (medicine.duration.split(' ')[1].includes('Day(s)')) {
                this.customMedDurationDay[index] = medicine.duration.split(' ')[0];
              } else if (medicine.duration.split(' ')[1].includes('Month(s)')) {
                this.customMedDurationMonth[index] = medicine.duration.split(' ')[0];
              }
            }
          } catch  {
            console.log('get some error');
          }


          if (medicine.schedule.length === 0) {
            this.customMedSchedule[index] = '';
          } else {
            this.customMedSchedule[index] = medicine.schedule.filter(ele => {
              return !(this.selectedShedules.includes(ele));
            })[0];
          }


          if (!medicine.quantity) {
            this.customMedQuantitySpoon[index] = '';
            this.customMedQuantityTablet[index] = '';
            this.customMedQuantityMl[index] = '';
          } else {
            if (medicine.quantity.split(' ')[1].includes('Tea')) {
              this.customMedQuantitySpoon[index] = medicine.quantity.split(' ')[0];
            } else if (medicine.quantity.split(' ')[1].includes('Tablet')) {
              this.customMedQuantityTablet[index] = medicine.quantity.split(' ')[0];
            } else if (medicine.quantity.split(' ')[1].includes('ML')) {
              this.customMedQuantityMl[index] = medicine.quantity.split(' ')[0];
            }
          }
        });
      }
    }
  }

  ngOnInit() {
    this.medTimings$ = this.medicineapiService.invoke<MedTime[]>(APIEndPoint.GET_MED_TIMES);
    this.medQuantities$ = this.medicineapiService.invoke<MedQuantity[]>(APIEndPoint.GET_QUANTITIES);
    this.medFrequencies$ = this.medicineapiService.invoke<MedFrequency[]>(APIEndPoint.GET_MED_FREQUENCIES);
    this.medRoutes$ = this.medicineapiService.invoke<MedRoute[]>(APIEndPoint.GET_MED_ROUTES);
    this.medDurations$ = this.medicineapiService.invoke<MedFrequency[]>(APIEndPoint.GET_MED_DURATION);
    this.medSchedules$ = this.medicineapiService.invoke<MedSchedule[]>(APIEndPoint.GET_MED_SCHEDULES).map(schedules => {
      this.selectedShedules = [];
      schedules.forEach(ele => {
        this.selectedShedules.push(ele.name);
      });
      return schedules;
    });
    this.customValueInit();
    // this.customMedTime = this.selectedValues[0].time.find(ele =>
    // ele.match(/\d+/g).map(Number)).match(/\d+/g).map(Number)[0];
    console.log('On Init', this.selectedValues);
  }
  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
