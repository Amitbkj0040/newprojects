export class APIEndPoint {
    // meta controllers
    public static GET_MED_TIMES: APIDef = { 'method': 'GET', api: () => `api/meta/times` };
    public static GET_QUANTITIES: APIDef = { 'method': 'GET', api: () => `api/meta/quantities` };
    public static GET_MED_SCHEDULES: APIDef = { 'method': 'GET', api: () => `api/meta/schedules` };
    public static GET_MED_FREQUENCIES: APIDef = { 'method': 'GET', api: () => `api/meta/frequencies` };
    public static GET_MED_DURATION: APIDef = { 'method': 'GET', api: () => `api/meta/durations` };
    public static GET_MED_ROUTES: APIDef = { 'method': 'GET', api: () => `api/meta/routes` };
    public static GET_TAGLIST_BY_MED_ID: APIDef = {
        'method': 'GET',
        api: () => `gm/api/MedicineTag/Find`
    };
    public static GET_INSTUCTIONS_BY_TAG_ID: APIDef = {
        'method': 'GET',
        api: () => `gm/api/TagInstruction/Find`
    };
}


export interface APIDef {
    method: string;
    api: any;
}


export interface APIInput {
    clinicId?: string;
}

