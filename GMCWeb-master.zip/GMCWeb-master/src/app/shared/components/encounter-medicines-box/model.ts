export interface Medicine {
    medicineId?: string;
    highlightedName?: string;
    name: string;
    quantity: string;
    frequency: string;
    route: string;
    time: string[];
    duration: string;
    schedule: string[];
    tagList?: any[];
    activeTag?: string;
}

export interface MedQuantity {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedSchedule {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedTime {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedFrequency {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedDuration {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedRoute {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface Doctor {
    id: string;
    practiceLicense: string;
    qualification?: string;
    specialistIn: {
        name?: string;
        id: number;
    };
    staffType: string;
    clinic: {
        id: string;
    };
    signature: string;
    title: string;
    firstName: string;
    lastName?: string;
    phone: string;
    alterPhone?: string;
    address: {
        address1: string,
        address2?: string,
        addressType: string,
        city: {
            id: number,
            // state: {
            // country: {
            // id: number
            // },
            // id: number
            // }
        },
        zip: string
    };
    user: {
        loginName: string;
        isOwner: boolean;
    };
    dob: string;
    age: string;
    gender: string;
    document?: Document[];
    bloodGroup?: string;
    email?: string;
    occupation?: string;
    logo?: string;
    loginName?: string;
    physicalExams?: [{
        id?: string;
        name?: string;
        unit?: string;
    }];
}
