import { Component, OnInit, Input, OnDestroy, OnChanges, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.css']
})
export class LoaderComponent implements OnInit, OnChanges {
  isSpinerShow = false;
  @Input('show') show;

  ngOnChanges(changes: SimpleChanges) {
    console.log('show', this.show);
    const show = changes['show'];
    if (show && show.currentValue) {
      this.isSpinerShow = true;
    } else {
      this.isSpinerShow = false;
    }
  }

  ngOnInit() {

  }

}
