import {
  Component, OnInit, Input, Output, EventEmitter, OnDestroy, SimpleChanges, OnChanges,
  ElementRef,
  HostListener
} from '@angular/core';
import { Month } from 'app/core/models/month';
import { Subject } from 'rxjs/Subject';
import { CurrentDate } from 'app/core/models/currentDate';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-date-picker',
  templateUrl: './date-picker.component.html',
  styleUrls: ['./date-picker.component.css'],
})

export class DatePickerComponent implements OnInit, OnDestroy, OnChanges {
  @Input() placeholder: string;
  @Input() selectedDate: string;
  @Input() age: string;
  @Input() minAge = 19;
  @Input() option: { disable?: boolean, disablePrevDates?: false; };
  @Output() updatedDate = new EventEmitter();
  public activeDate: CurrentDate;
  public activeMonth: string;
  public isCalShow = false;
  public daysList: CurrentDate[] = new Array<CurrentDate>();
  public selectedDateInFormate: string;
  public inputIsValid = true;
  private unsubscribe = new Subject<void>();
  public monthList: Array<{ name: string, Id: number }>[];
  public isMonthListAcitve = false;
  public selectedDateObject: CurrentDate;
  public isAgeChangeHandle = true;

  constructor(
     private elemRef: ElementRef,
     private toasterService: ToastrService
    ) { }

  @HostListener('document:click', ['$event'])
  public onClick(event) {
    if (!this.elemRef.nativeElement.contains(event.target)) {
      this.isCalShow = false;
    }
  }
  @HostListener('keydown.tab', ['$event']) onKeydownHandler(event: KeyboardEvent) {
    this.isCalShow = false;
  }

  public getDaysInMonth(month, year) {
    const date = new Date(year, month, 1);
    let days = [];
    const daysList = [];
    let isFirstIteration = true;
    while (date.getMonth() === month) {
      if (days.length < 7) {
        if (!isFirstIteration) {
          days.push(this.getDateInObject(date));
        } else {
          for (let i = 0; i < this.getDateInObject(date).day; i++) {
            days.push({});
          }
          days.push(this.getDateInObject(date));
          isFirstIteration = false;
        }
      } else {
        daysList.push(days);
        days = [];
        days.push(this.getDateInObject(date));
      }
      date.setDate(date.getDate() + 1);
    }
    if (date.getMonth() !== month) {
      daysList.push(days);
    }
    return daysList;
  }

  public setCalendar(month, year): void {
    this.activeMonth = Month['month_' + month];
    this.activeDate.year = year;
    this.daysList = this.getDaysInMonth(month, year);
  }

  public setMonth(month): void {
    this.activeMonth = Month['month_' + month];
    this.activeDate.month = month;
    this.setCalendar(month, this.activeDate.year);
  }

  public setYear(yearValue): void {
    this.setCalendar(this.selectedDateObject.month, yearValue);
  }

  public getListOfMonths() {
    const monthList: Array<{ name: string, Id: number }>[] = [];
    let monthIndex = 0;
    for (let i = 0; i < 4; i++) {
      const monthRow = [];
      for (let j = 0; j < 3; j++) {
        const monthNameObj = { name: Month['month_' + monthIndex], Id: monthIndex };
        monthRow.push(monthNameObj);
        monthIndex++;
      }
      monthList.push(monthRow);
    }
    return monthList;
  }


  public getDateInObject(dateString) {
    const date = new Date(dateString);
    const result = {
      dateString: date,
      year: date.getFullYear(),
      month: date.getMonth(),
      day: date.getDay(),
      date: date.getDate()
    };
    return result;
  }

  public getSeletedDateInFormat(dateString) {
    const date = this.getDateInObject(dateString);
    const month = (date.month + 1) < 10 ? '0' + (date.month + 1) : (date.month + 1);
    const day = date.date < 10 ? '0' + date.date : date.date;
    // this.selectedDateInFormate = day + '/' + month + '/' + date.year;
    if (this.option && this.option.disablePrevDates) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      if (moment(yesterday).isBefore(dateString, 'day')) {
        this.selectedDateInFormate = day + '/' + month + '/' + date.year;
      } else {
        this.toasterService.warning('Past Date cannot be selectable');
      }
    } else {
      this.selectedDateInFormate = day + '/' + month + '/' + date.year;
    }
  }


  public initCalendar(todayDate): void {
    this.getSeletedDateInFormat(todayDate);
    this.activeDate = this.getDateInObject(todayDate);
    this.selectedDateObject = this.getDateInObject(todayDate);
    this.setMonth(this.activeDate.month);
    this.setCalendar(this.activeDate.month, this.activeDate.year);
  }

  public getPrevMonthDays() {
    let newMonth = this.activeDate.month;
    newMonth = (newMonth > 0) ? newMonth - 1 : newMonth;
    this.activeDate.month = newMonth;
    this.setMonth(this.activeDate.month);
    this.setCalendar(this.activeDate.month, this.activeDate.year);
  }

  public getNextMonthDays() {
    let newMonth = this.activeDate.month;
    newMonth = (newMonth < 11) ? newMonth + 1 : newMonth;
    this.activeDate.month = newMonth;
    this.setMonth(this.activeDate.month);
    this.setCalendar(this.activeDate.month, this.activeDate.year);
  }

  public getPrevYearMonthDays() {
    let newYear = this.activeDate.year;
    newYear--;
    this.activeDate.year = newYear;
    this.setCalendar(this.activeDate.month, this.activeDate.year);
  }

  public getNextYearMonthDays() {
    let newYear = this.activeDate.year;
    newYear++;
    this.activeDate.year = newYear;
    this.setCalendar(this.activeDate.month, this.activeDate.year);
  }

  public getTodayDate() {
    const todayDate = new Date();
    this.activeDate = this.getDateInObject(todayDate);
    this.selectedDateObject = this.getDateInObject(todayDate);
    this.getSeletedDateInFormat(todayDate);
    this.setMonth(this.activeDate.month);
    this.setCalendar(this.activeDate.month, this.activeDate.year);
    this.isMonthListAcitve = false;
    this.isCalShow = false;
  }

  public selectMonth(month) {
    this.setMonth(month.Id);
    this.isMonthListAcitve = false;
  }


  public setDate(value: Date, isCalShow: boolean, self: boolean) {
    this.inputIsValid = true;
    if (value) {
      this.activeDate = this.getDateInObject(value);
      this.selectedDateObject = this.getDateInObject(value);
      this.getSeletedDateInFormat(value);
      this.updatedDate.emit({ data: value, self: self });
      this.isCalShow = isCalShow;
      this.isAgeChangeHandle = false;
    }
  }

  public validateDate(value: string) {
    const regExp = new RegExp(/^([0-2][0-9]|(3)[0-1])(\/)(((0)[0-9])|((1)[0-2]))(\/)\d{4}$/i);
    this.inputIsValid = ((value.match(regExp) !== null));
    if (this.inputIsValid) {
      const dateArray = value.split('/');
      const day = parseInt(dateArray[0], 10);
      const month = parseInt(dateArray[1], 10);
      const year = parseInt(dateArray[2], 10);
      const date = new Date(year, (month - 1), day);
      this.setCalendar(month, year);
      this.setDate(date, false, true);
    }
  }




  ngOnInit() {
    this.monthList = this.getListOfMonths();
    if (!this.selectedDate) {
      const todayDate = new Date();
      this.initCalendar(todayDate);
      this.selectedDateInFormate = '';
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    const selectedDate = changes['selectedDate'];
    const age = changes['age'];
    if (selectedDate && selectedDate.currentValue) {
      this.initCalendar(selectedDate.currentValue);
    } else {
      if (this.isAgeChangeHandle) {
        this.selectedDateInFormate = '';
      }
    }
    if (age && (age.currentValue > this.minAge)) {
      const date = this.getDateInObject(new Date());
      const newDate = new Date((date.year - age.currentValue), date.month, date.date);
      this.setCalendar(date.month, date.year - age.currentValue);
      this.setDate(newDate, false, false);
    }
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
