import { Component, OnInit } from '@angular/core';
import { AuthService } from 'app/core/auth/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration-header',
  templateUrl: './registration-header.component.html',
  styleUrls: ['./registration-header.component.css']
})
export class RegistrationHeaderComponent implements OnInit {

  constructor(public authService: AuthService, private router: Router) { }

  ngOnInit() {
  }

  public logout() {
    this.authService.logoutUser().subscribe(response => {
      this.router.navigate(['/']);
    });
  }

}
