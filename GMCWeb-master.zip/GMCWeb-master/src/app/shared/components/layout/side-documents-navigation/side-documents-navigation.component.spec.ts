import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SideDocumentsNavigationComponent } from './side-documents-navigation.component';

describe('SideDocumentsNavigationComponent', () => {
  let component: SideDocumentsNavigationComponent;
  let fixture: ComponentFixture<SideDocumentsNavigationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SideDocumentsNavigationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SideDocumentsNavigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
