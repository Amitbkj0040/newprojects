import { Component, OnInit, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'app/core/auth/auth.service';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

@Component({
  selector: 'app-side-documents-navigation',
  templateUrl: './side-documents-navigation.component.html',
  styleUrls: ['./side-documents-navigation.component.css']
})
export class SideDocumentsNavigationComponent implements OnInit {
  private unsubscribe = new Subject<void>();
  public clinicId: string;
  public facilityId: string;
  public staffId: string;
  @Input() typeOfEncounter: string;

  constructor(
    private activatedRoute: ActivatedRoute,
    private router: Router,
    public authService: AuthService
  ) { }

  ngOnInit() {
    Observable.combineLatest(this.activatedRoute.parent.params,
      this.activatedRoute.params).takeUntil(this.unsubscribe).subscribe(params => {
        console.log('params fm side nav', params);
        this.clinicId = params[0]['clinicId'];
        this.facilityId = params[0]['facilityId'];
        this.staffId = params[1]['staffId'];
      });
  }

  allDocuments() {
    this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/'
      + this.facilityId + '/staffs/' + this.staffId + '/documents/allEncounters']);
  }
  sharedByMeDocuments() {
    this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/'
      + this.facilityId + '/staffs/' + this.staffId + '/documents/sharedByMe']);
  }
  sharedWithMeDocuments() {
    this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/'
      + this.facilityId + '/staffs/' + this.staffId + '/documents/sharedWithMe']);
  }
}
