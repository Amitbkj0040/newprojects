import { Component, OnInit, OnDestroy, HostListener, ElementRef, Input } from '@angular/core';
import { Doctor, Facility, AddStaff, StaffType } from 'app/core/models/app.models';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/fromEvent';
import { RestapiService } from 'app/core/services/restapi.service';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { ActivatedRoute, Router } from '@angular/router';
import { AuthService } from 'app/core/auth/auth.service';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/observable/forkJoin';
import { Location } from '@angular/common';
import { Dictionary } from 'app/core/models/dictionary';
import { ToastrService } from 'ngx-toastr';
import { ProfileService } from 'app/core/services/profile.service';



@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnDestroy {
  public doctors$: Observable<Doctor[]>;
  public profile$: Observable<any>;
  public staffType = StaffType;
  @Input() facilityId: string;
  public clinicId: string;
  public token: any;
  public isViewChangeDropdownShow = false;
  public selectedView: string;
  public doctorId: string;
  public staffId: string;
  public unsubscribe = new Subject<void>();
  public toggle = false;
  public profile = '../../../../assets/img/avatar.png';
  constructor(
    public restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    public authService: AuthService,
    public jwtHelper: JwtHelperService,
    private location: Location,
    private toaster: ToastrService,
    public profileService: ProfileService,
    public elemRef: ElementRef
  ) { }

  onClick(event) {
    this.toggle = !this.toggle;
  }

  public changeView(view) {
    if (view === View.ManageView && this.authService.getRoles().includes(StaffType.ADMIN)) {
      this.selectedView = 'Manage';
      this.router.navigate(['/manage-view/clinics/' + this.authService.getClinicId() + '/facilities']);
    } else if (view === View.ClinicView) {
      this.selectedView = 'Clinic';
      if (this.authService.getRoles().includes(StaffType.DOCTOR)) {
        this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId +
          '/doctors/' + this.authService.getStaffId() + '/appointments/view']);
      } else if (this.authService.getRoles().includes(StaffType.ADMIN) || this.authService.getRoles().includes(StaffType.SUPPORT_STAFF)) {
        this.getDoctors().takeUntil(this.unsubscribe).subscribe(doctors => {
          console.log('Doctor in header');
          if (doctors.length > 0) {
            this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId +
              '/doctors/' + doctors[0].id + '/appointments/view']);
          } else {
            // ToDo
            this.toaster.error(Dictionary.NO_DOCTOR_FOUND);
          }
        });
      }
    }
  }

  private getDoctors(): Observable<Doctor[]> {
    return this.restapiservice
      .invoke<Doctor[]>(APIEndPoint.GET_DOCTORS,
        { clinicId: this.clinicId, facilityId: this.facilityId });
  }

  public logout() {
    this.authService.logoutUser().subscribe(response => {
      this.router.navigate(['/']);
    });
  }

  public viewProfile() {
    this.router.navigate(['/profile-view/clinics/' + this.clinicId + '/myprofile/view']);
  }

  public viewClinic() {
    this.router.navigate(['/clinics/' + this.clinicId + '/view']);
  }

  public viewSubscription() {
    this.router.navigate(['/profile-view/clinics/' + this.clinicId + '/subscription-details']);
  }
  public redirectToRoot() {
    if (this.authService.getRoles().includes('ADMIN')) {
      this.changeView(View.ManageView);
    } else if (this.authService.getRoles().includes('DOCTOR') || this.authService.getRoles().includes('SUPPORT_STAFF')) {
      this.changeView(View.ClinicView);
    }
  }


  ngOnInit() {
    this.profile$ = this.profileService.getImage();
    if (this.location.path() !== '/clinics/add') {
      Observable.combineLatest(this.activatedRoute.params, this.activatedRoute.url).takeUntil(this.unsubscribe).subscribe(response => {
        this.clinicId = response[0]['clinicId'];
        if (this.clinicId) {
            this.restapiservice.invoke<Facility[]>(APIEndPoint.GET_FACILITIES, { clinicId: this.clinicId }).subscribe(facilities => {
              if (facilities.length > 0) {
                this.facilityId = this.facilityId ? this.facilityId : facilities[0].id;
                const currentView = response[1][0]['path'];
                if (currentView === View.ManageView) {
                  this.selectedView = 'Manage';
                } else if (currentView === View.ClinicView) {
                  this.selectedView = 'Clinic';
                }
              }
            });
        }
      });
    }


    if (this.authService.isUserDoctor()) {
      this.doctorId = this.authService.getStaffId();
      console.log('doctorId', this.doctorId);
      this.restapiservice.invoke<Doctor>(APIEndPoint.GET_DOCTOR_BY_ID,
        { clinicId: this.clinicId, doctorId: this.doctorId }).takeUntil(this.unsubscribe)
        .subscribe(doctor => {
          if (doctor.logo) {
            this.profile = doctor.logo;
            this.profileService.setImage(this.profile);
          }
          console.log('doctor logo', doctor);
        });

    } else {
      this.staffId = this.authService.getStaffId();
      this.restapiservice.invoke<AddStaff>(APIEndPoint.GET_SUPPORT_STAFF_BY_ID,
        { clinicId: this.clinicId, staffId: this.staffId }).takeUntil(this.unsubscribe)
        .subscribe(staff => {
          if (staff.logo) {
            this.profile = staff.logo;
            this.profileService.setImage(this.profile);
          }
          console.log('staff logo', staff);
        });
    }
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
    this.profileService.setImage(null);
  }

  @HostListener('document: click', ['$event']) onclick(event) {
    if (!this.elemRef.nativeElement.contains(event.target)) {
      this.toggle = false;
    }
  }

}


enum View {
  ManageView = 'manage-view',
  ClinicView = 'clinic-view'
}
