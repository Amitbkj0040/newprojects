import { Component, OnInit, OnDestroy, Input, OnChanges, SimpleChanges, HostListener, ElementRef, Output, EventEmitter } from '@angular/core';
import { Doctor, AddStaff, StaffType } from 'app/core/models/app.models';
import { Subscription } from 'rxjs/Subscription';
import { Facility } from 'app/core/models/app.models';
import { Observable } from 'rxjs/Observable';
import { RestapiService } from 'app/core/services/restapi.service';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs/Subject';
import { ClinicDetails } from 'app/core/models/clinicDetails';
import { Location } from '@angular/common';
import { AuthService } from 'app/core/auth/auth.service';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { ParamSelectionService } from 'app/core/services/param-selection.service';
import { ClinicService } from 'app/core/services/clinic-service.service';



@Component({
  selector: 'app-main-tab',
  templateUrl: './main-tab.component.html',
  styleUrls: ['./main-tab.component.css']
})
export class MainTabComponent implements OnInit, OnChanges, OnDestroy {
  @Input() facilityId: string;
  @Input() clinic: ClinicDetails;
  @Output() facilityChange = new EventEmitter();
  public clinicId: string;
  public doctorId: string;
  public staffId: string;
  public staffID: string;
  public staff: AddStaff;
  public staffType = StaffType;
  public profileImg = '../../../../assets/img/avatar.png';
  private unsubscribe = new Subject<void>();
  public subscribe: Subscription;
  public facilityList: Facility[] = [];
  public currentView$: Observable<any>;
  public currentView: string;
  public isStaffId: boolean;
  public openSideNav = false;
  // public currentProfileView: string;
  public token: any;
  public selectedFacility: Facility;
  public currentEndPoint: string;
  public listOfTabs = ['encounters',
    'appointments',
    'schedules',
    'doctor-list',
    'doctors',
    'patient-list',
    'patients',
    'facility-list',
    'facilities',
    'staff-list',
    'staffs',
    'unavailability',
    'documents',
    'document-details'];
  public IsAppointmentScreen = false;
  constructor(
    public api: RestapiService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    public location: Location,
    public authService: AuthService,
    public jwtHelper: JwtHelperService,
    private gmParams: ParamSelectionService,
    private elemRef: ElementRef,
    public clinicService: ClinicService
  ) {

  }
  @HostListener('document:click', ['$event'])
  public onClick(event) {
    if (!this.elemRef.nativeElement.contains(event.target)) {
      this.openSideNav = false;
    }
  }

  public manageViewRoute(redirectLink) {
    this.router.navigate(['/manage-view/clinics/' + this.token.clinic + '/' + redirectLink]);
  }

  public clinicViewRoute(redirectLink) {
    if (redirectLink === 'patients') {
      this.router.navigate(['/clinic-view/clinics/' + this.token.clinic + '/' + redirectLink]);
    } else {
      this.router.navigate(['/clinic-view/clinics/' + this.token.clinic + '/facilities/' + this.facilityId +
        '/doctors/' + this.doctorId + '/encounters/add']);
    }
  }


  public selectFacility(facility: Facility) {
    this.selectedFacility = facility;
    this.facilityChange.emit(facility.id);
    this.gmParams.setParam('facility', this.selectedFacility);
    const currentPath = this.location.path();
    const pathArray = currentPath.split('/');
    pathArray[pathArray.indexOf('facilities') + 1] = facility.id;
    const newPath = pathArray.join('/');
    this.router.navigate([newPath]);
    this.clinicService.callFacilityChange({ isFacilityChange: true, facilityId: facility.id });
  }
  public getCurrentView(view) {
    this.currentView = view[0].path;
    return view[0].path;
  }
  public getCurrentTabPage() {
    const path = this.location.path();
    const pathArray = path.split('/');
    pathArray.forEach(element => {
      this.listOfTabs.forEach(elem => {
        if (element === elem) {
          this.currentEndPoint = elem;
        }
      });
    });
  }

  clickEncounter() {
    if (this.token.roles.includes(StaffType.ADMIN) && this.token.roles.includes(StaffType.DOCTOR)) {
      this.router.navigate(['/clinic-view/clinics', this.clinicId, 'facilities', this.facilityId, 'doctors', this.staffId, 'encounters']);
    } else {
      this.router.navigate(['/clinic-view/clinics', this.clinicId, 'facilities', this.facilityId, 'doctors', this.doctorId, 'encounters']);
    }

    this.openSideNav = !this.openSideNav;
  }

  private getToken() {
    this.token = this.jwtHelper.decodeToken(this.authService.getAuthToken());
  }

  public getFacilityId() {
    const path = this.location.path();
    const pathArray = path.split('/');
    const facilityId = pathArray[pathArray.indexOf('facilities') + 1];
    return facilityId;
  }

  public getDoctorId() {
    const path = this.location.path();
    const pathArray = path.split('/');
    let doctorId = pathArray[pathArray.indexOf('doctors') + 1];
    if (!doctorId) {
      doctorId = pathArray[pathArray.indexOf('staffs') + 1];
    }
    return doctorId;
  }

  ngOnInit() {
    this.staffId = this.authService.getStaffId();
    this.getCurrentTabPage();
    this.getToken();
    this.currentView$ = this.activatedRoute.url.map(url =>
      this.getCurrentView(url)
    );
    this.router.events.takeUntil(this.unsubscribe).subscribe(data => {
      this.getCurrentTabPage();
      this.getToken();
    });
    this.activatedRoute.params.takeUntil(this.unsubscribe).subscribe(params => {
      this.clinicId = params['clinicId'];
    });
    this.gmParams.params().subscribe(params => {
      this.doctorId = params['doctor'] ? params['doctor'].id : null;
      this.facilityId = params['facility'] ? params['facility'].id : null;
      if (!this.doctorId) {
        this.api
          .invoke<Doctor[]>(APIEndPoint.GET_DOCTORS,
            { clinicId: this.authService.getClinicId(), facilityId: this.facilityId }).takeUntil(this.unsubscribe).subscribe(data => {
              if (this.authService.isUserDoctor() && !this.authService.isUserAdmin()) {
                this.doctorId = this.authService.getStaffId();
              } else {
                this.doctorId = data[0].id;
              }
            });
      }
    });

    // For displaying the Profile Name and Desination on the Main tab when login as Doctor or staff
    if (this.staffId !== undefined || this.staffId !== '') {
      this.api.invoke<AddStaff>(APIEndPoint.GET_STAFF_BY_ID,
        { clinicId: this.token.clinic, staffId: this.staffId }).takeUntil(this.unsubscribe).subscribe(data => {
          this.staff = data;
        });
    }

    this.api.invoke<ClinicDetails>(APIEndPoint.GET_CLINIC_BY_ID,
      { clinicId: this.clinicId })
      .subscribe(clinic => {
        this.profileImg = clinic.logo;
      });
  }

  ngOnChanges(changes: SimpleChanges) {
    // only run when property "data" changed
    if (changes['clinic']) {
      this.clinic = changes['clinic'].currentValue;
      if (this.clinic) {
        if (this.facilityList.length === 0) {
          this.getFacilities(this.clinic.id).takeUntil(this.unsubscribe).subscribe(facilities => {
            console.log('facility in main tab');
            this.setSeletedFacility(facilities);
          });
        } else {
          this.setSeletedFacility(this.facilityList);
        }
      }
    }
  }

  setSeletedFacility(facilities: Facility[]) {
    if (facilities.length > 0) {
      if (this.facilityId) {
        facilities.some(facility => {
          // tslint:disable-next-line:triple-equals
          if (facility.id == this.facilityId) {
            this.selectedFacility = facility;
            return true;
          }
        });
        if (!this.selectedFacility) {
          this.selectedFacility = facilities[0];
        }
      } else {
        this.selectedFacility = facilities[0];
      }
      this.gmParams.setParam('facility', this.selectedFacility);
    }
    this.facilityList = facilities;
    return facilities;
  }

  isUserDoctor() {
    return this.authService.isUserDoctor();
  }

  getFacilities(clinicId: string): Observable<Facility[]> {
    return this.api
      .invoke<Facility[]>(APIEndPoint.GET_FACILITIES,
        { clinicId: clinicId });
  }


  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
