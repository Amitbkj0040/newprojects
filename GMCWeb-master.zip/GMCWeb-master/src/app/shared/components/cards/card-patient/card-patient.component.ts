import { Component, OnInit, Input, OnDestroy, ViewEncapsulation, OnChanges, HostListener, SimpleChanges } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { RestapiService } from 'app/core/services/restapi.service';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Appointment, AppointmentStatus, AppointmentType, AppointmentSlotForDates } from 'app/core/models/app.models';
import { AppointmentEncounterService } from 'app/core/services/patient-encounter.service';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { Dictionary } from 'app/core/models/dictionary';


@Component({
  selector: 'app-card-patient',
  templateUrl: './card-patient.component.html',
  styleUrls: ['./card-patient.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class CardPatientComponent implements OnInit, OnDestroy, OnChanges {
  selectedAppointmentIndex = 0;
  AppointmentStatus = AppointmentStatus;
  AppointmentType = AppointmentType;
  @Input() clinicId: string;
  @Input() facilityId: string;
  @Input() doctorId: string;
  appointmentSubject: BehaviorSubject<Appointment[]>;
  appointments$: Observable<Appointment[]>;
  appointment$: Observable<AppointmentSlotForDates[]>;
  appointments: Appointment[];
  skipDisable = false;
  showClosedAppointments = false;
  openClosedStateSwitched = false;
  selectedopenindex = 0;
  closedState = false;
  patientSearchTxt = '';
  patientWalkin = true;
  totalOpenEncounters;
  openAppointmentsCount = 0;
  closedAppointmentsCount = 0;
  activeAppointment: any;
  public showBookAppointmentDialog = false;
  public isMobileView: boolean;
  isClose = false;
  hideAlert = false;
  public update_appointment = false;
  public isToday = false;


  private unsubscribe;
  selectedColIndex: any;
  seletedPatientDetails: any;
  appointmentId: string;

  constructor(
    private restapiservice: RestapiService,
    public appointmentEncounterService: AppointmentEncounterService,
    public confirmationPopup: ConfirmationPopupService,
    private toastrService: ToastrService,
    private router: Router) {
    this.detectMobileView();
  }
  @HostListener('window:resize', ['$event']) onresize(event) {
    this.detectMobileView();
  }

  detectMobileView() {
    if (window.innerWidth <= 768) {
      this.isMobileView = true;
    } else {
      this.isMobileView = false;
    }
  }
  public getAppointedPatients() {
    this.openAppointmentsCount = 0;
    this.closedAppointmentsCount = 0;
    this.appointments$ = this.getAppointments().map(appointments => {
      this.appointments = appointments;
      // ( online 1 && status != closed )&& ( koi offline && !confirmed  )
      // console.log('$$$$$$$$$$$', );
      if (this.appointments.filter(appointment => appointment.appointmentType === AppointmentType.ONLINE).length === 1 &&
        this.appointments.filter(appointment =>
          appointment.appointmentType === AppointmentType.ONLINE)[0].appointmentStatus !== AppointmentStatus.CLOSED &&
        this.appointments.filter(appointment =>
          appointment.appointmentStatus === AppointmentStatus.CONFIRMED
          && (appointment.appointmentType === AppointmentType.OFFLINE || appointment.appointmentType === AppointmentType.VIRTUAL)).length === 0) {
        this.hideAlert = true;
      }
      this.appointments.forEach(appointment => {
        if (appointment.appointmentStatus !== AppointmentStatus.CLOSED) {
          this.openAppointmentsCount++;
        } else {
          this.closedAppointmentsCount++;
        }
      });
      this.selectAppointment(appointments, MovementMode.NEXT);
      return appointments;
    });
  }

  selectAppointment(appointments: Appointment[], mode: MovementMode) {
    let openAppointmentFound = false;
    let selectedOpenAptIndex = -1;
    let openApptIndex = -1;
    let firstOpenAptIndex = -1;
    const nextIncrementOnSelectedIndex = mode === MovementMode.NEXT ? 0 : 1;
    if (appointments.length > 0) {
      for (let index = 0; index < appointments.length; index++) {
        if (appointments[index].appointmentStatus !== AppointmentStatus.CLOSED) {
          if (firstOpenAptIndex === -1 && mode === MovementMode.SKIP &&
            this.selectedAppointmentIndex === this.openAppointmentsCount - 1) {
            firstOpenAptIndex = index;
            break;
          }
          if (++openApptIndex === this.selectedAppointmentIndex + nextIncrementOnSelectedIndex) {
            openAppointmentFound = true;
            selectedOpenAptIndex = index;
            break;
          } else {
            openAppointmentFound = true;
            selectedOpenAptIndex = index;
          }
        }
      }
    }
    if (!openAppointmentFound) {
      if (mode === MovementMode.NEXT) {
        this.startEncouterForAppointment(null, 0, true);
      } else {
        this.startEncouterForAppointment(appointments[firstOpenAptIndex], 0, false);
      }
    } else {
      this.startEncouterForAppointment(appointments[selectedOpenAptIndex], openApptIndex, false);
    }
  }

  ngOnInit() {
    this.inItComponent();
  }

  inItComponent() {
    this.unsubscribe = new Subject<void>();
    this.showClosedAppointments = false;
    if (this.facilityId) {
      this.getAppointedPatients();
    }
    this.appointmentEncounterService.getClosedAppointment().takeUntil(this.unsubscribe).subscribe(appointment => {
      console.log('ghfffgfg', appointment);

      this.ngOnDestroy();
      this.ngOnInit();
    });

    this.appointmentEncounterService.getSkipAppointment().takeUntil(this.unsubscribe).subscribe(appointment => {
      console.log('ghfffgfg', appointment);
      // this.getSkipPatient();
      this.selectAppointment(this.appointments, MovementMode.SKIP);
    });
    this.appointmentEncounterService.getStartedAppointment().takeUntil(this.unsubscribe).subscribe(data => {
      this.selectedAppointmentIndex = data.appointmentIndex;
      if (this.openClosedStateSwitched) {
        this.showClosedAppointments = this.closedState;
        this.openClosedStateSwitched = false;
      }
    });
  }

  startEncouterForAppointment(appointment: Appointment, selectedAppointmentIndex: number, isClosed: boolean) {
    //  this.selectedAppointmentIndex = selectedAppointmentIndex;
    this.appointmentEncounterService.startEncounterForAppointment(appointment, selectedAppointmentIndex, this.isClose);
  }


  changeEncounter(appointment: Appointment, selectedAppointmentIndex: number, totalOpenEncounter: number,
    appointmentType: string, patientFN: string, patientLN: string,
    patientPhone: string, patientEmail: string, onlineId: string, slot: string, date: string) {
    if (appointment.appointmentType !== AppointmentType.ONLINE) {
      if (((this.selectedAppointmentIndex !== undefined) && (selectedAppointmentIndex !== this.selectedAppointmentIndex))
        || selectedAppointmentIndex === 0) {
        this.appointmentEncounterService.startEncounterForAppointment(appointment, selectedAppointmentIndex, this.isClose);
        this.appointmentEncounterService.setSelectedAppointmentIndexAndTotalEncounter(selectedAppointmentIndex, totalOpenEncounter);
        if (appointmentType === AppointmentType.ONLINE) {
          console.log('id', onlineId, appointmentType);
          this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId +
            '/doctors/' + this.doctorId + '/appointments/view'],
            {
              queryParams: {
                patientOnline: true,
                patientFN: patientFN,
                patientLN: patientLN,
                patientPhone: patientPhone,
                patientEmail: patientEmail,
                onlineId: onlineId,
                appointmentType: appointmentType,
                slot: slot,
                date: date,
                from: 'encounter'
              }
            });
        }
      }
    } else {
      this.patientWalkin = false;
      this.activeAppointment = { appointment };
      this.showBookAppointmentDialog = true;
    }
  }

  addWalkinPatient() {
    this.showBookAppointmentDialog = true;
  }

  onCreateAppointment(event) {
    this.showBookAppointmentDialog = false;
    this.patientWalkin = true;
    this.activeAppointment = null;
    this.getAppointedPatients();
  }
  hideAppointmentDialog() {
    this.showBookAppointmentDialog = false;
    this.activeAppointment = null;
  }

  hideSlotModal() {
    this.update_appointment = false;
  }

  onUpdateEncounter(appointment: Appointment, selectedAppointmentIndex: number) {
    if (this.selectedAppointmentIndex !== undefined
      || selectedAppointmentIndex === 0) {
      console.log('index', selectedAppointmentIndex);
      this.appointment$ = this.getAppointment();
      this.update_appointment = true;
      this.selectedColIndex = 0;
      this.isToday = true;
      this.seletedPatientDetails = appointment;
      this.appointmentId = appointment.id;
    }
  }

  deleteAppointment(appointment) {
    this.confirmationPopup.confirm({ message: Dictionary.DELETE_CONFIRMATION }).subscribe(data => {
      if (data) {
        this.restapiservice.invoke(APIEndPoint.DELETE_APPOINTMENT_BY_ID,
          { clinicId: this.clinicId, facilityId: this.facilityId, doctorId: this.doctorId, appointmentId: appointment.id })
          .subscribe(res => {
            this.toastrService.success(Dictionary.DELETE_APPOINTMENT_SUCCESS);
            this.getAppointedPatients();
          }, error => {
            this.toastrService.error(Dictionary.DELETE_APPOINTMENT_ERROR);
          });
      }
    });
  }

  refreshAppointment(event) {
    if (event) {
      this.ngOnInit();
    }

  }

  viewClosedAppointments(isClosed: boolean) {
    this.openClosedStateSwitched = true;
    this.closedState = isClosed;
    this.isClose = isClosed;
    let appointment = null;
    if (this.appointments.length > 0) {
      for (let index = 0; index < this.appointments.length; index++) {
        if ((this.appointments[index].appointmentStatus === AppointmentStatus.CLOSED) === isClosed) {
          appointment = this.appointments[index];
          break;
        }
      }
    }
    this.startEncouterForAppointment(appointment, 0, isClosed);
  }

  getAppointment(): Observable<AppointmentSlotForDates[]> {
    return this.restapiservice
      .invoke<AppointmentSlotForDates[]>(APIEndPoint.GET_SLOTS_APPOINTMENTS,
        { clinicId: this.clinicId, facilityId: this.facilityId, doctorId: this.doctorId },
        null,
        { startDate: 'today', endDate: 'today' }).map(resp => {
          console.log('hellorespfrom encounter', resp);
          return resp;
        });
  }

  getAppointments(): Observable<Appointment[]> {
    return this.appointments$ = this.restapiservice.invoke<Appointment[]>(APIEndPoint.GET_APPOINTMENTS,
      { clinicId: this.clinicId, facilityId: this.facilityId, doctorId: this.doctorId },
      null,
      { startDate: 'today', endDate: 'today' });
  }


  ngOnChanges(changes: SimpleChanges) {
    if (changes && changes.facilityId.currentValue) {
      this.inItComponent();
    }
  }

  // addWalkinPatient() {
  //   this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId +
  //     '/doctors/' + this.doctorId + '/appointments/view'],
  //     {
  //       queryParams: {
  //         patientWalkin: true,
  //         fromRoute: 'encounter',
  //         doctorId: this.doctorId,
  //         facilityId: this.facilityId
  //       }
  //     });
  // }

  convertOffline(isSelected) {
    if (!isSelected) {
      const currentOnlineAppointment = this.appointments
        .filter(appointment => appointment.appointmentStatus === AppointmentStatus.CONFIRMED
          && appointment.appointmentType === AppointmentType.ONLINE);

      this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId +
        '/doctors/' + this.doctorId + '/appointments/view'],
        {
          queryParams: {
            patientOnline: true,
            patientFN: currentOnlineAppointment[0].patient.firstName,
            patientLN: currentOnlineAppointment[0].patient.lastName,
            patientPhone: currentOnlineAppointment[0].patient.phone,
            patientEmail: currentOnlineAppointment[0].patient.email,
            onlineId: currentOnlineAppointment[0].id,
            appointmentType: currentOnlineAppointment[0].appointmentType,
            slot: currentOnlineAppointment[0].startTime,
            date: currentOnlineAppointment[0].appointmentDate,
            from: 'encounter'
          }
        });
    }
  }
  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}

enum MovementMode {
  SKIP,
  NEXT
}
