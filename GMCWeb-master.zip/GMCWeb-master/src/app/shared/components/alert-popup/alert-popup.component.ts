import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';

@Component({
  selector: 'app-alert-popup',
  templateUrl: './alert-popup.component.html',
  styleUrls: ['./alert-popup.component.css']
})
export class AlertPopupComponent implements OnInit {
  @Output() hidePopup = new EventEmitter<boolean>();
  // public message = 'this is your';
  @Input() message: string;
  constructor() { }

  userAction() {
    this.hidePopup.emit(false);
  }
  ngOnInit() {

  }

}
