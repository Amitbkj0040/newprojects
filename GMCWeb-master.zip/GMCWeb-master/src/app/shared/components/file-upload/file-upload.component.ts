
import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { UploadFileService } from 'app/core/services/upload-file.service';
import { Subject } from 'rxjs/Subject';
import { HttpEventType, HttpResponse } from '@angular/common/http';
import { Document } from 'app/core/models/app.models';
import { Observable } from 'rxjs/Observable';
import { RestapiService } from 'app/core/services/restapi.service';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { DownloadFileService } from 'app/core/services/download-file.service';
import { Subscription } from 'rxjs/Subscription';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { Dictionary } from 'app/core/models/dictionary';
import { ToastrService } from 'ngx-toastr';
import { FileType } from 'app/core/models/FileType.list';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.css']
})
export class FileUploadComponent implements OnInit {
  @Input() mode?: string;
  @Input() validFileTypes = FileType;
  @Input() options: { documentType: string, entityId?: string, entityType: string };
  @Input() isMTClinic?= false;
  @Input() selectedValues: Document[];
  @Output() uploadedFilesURL = new EventEmitter();
  @Output() uploadStarted = new EventEmitter();
  @Output() uploadFinished = new EventEmitter();
  public counter = 0;
  docType$: Observable<String[]>;
  public filesToUpload: { file: File, progress: number, inProgress: boolean, cancelled?: boolean, subscription?: Subscription }[] = [];
  private unsubscribe = new Subject<void>();
  public upload: any;
  public documents: Document[] = [];
  public fileName: string;
  public fileUri: string;
  public documentType: string;
  public customFileName: string;
  public docType: string[] = [];
  public MAX_FILE_SIZE = 1024 * 1024; // 1kb = 1024bites, 1mb = 1024kb
  documentList: { isDataUnsave: boolean, document: Document }[] = [];

  constructor(public fileUploader: UploadFileService,
    private restapiservice: RestapiService,
    public downloadFileService: DownloadFileService,
    public confirmationPopup: ConfirmationPopupService,
    public toasterService: ToastrService
  ) { }


  ngOnInit() {
    this.docType$ = this.restapiservice
      .invoke<String[]>(this.isMTClinic ? APIEndPoint.GET_DOCUMENT_TYPE_FOR_MT : APIEndPoint.GET_DOCUMENT_TYPE);
    if (this.selectedValues) {
      this.selectedValues.forEach((element) => {
        this.documentList.push({ isDataUnsave: false, document: element });
        this.docType.push(element.documentType);
      });
    }

  }

  changeDocType(index, docType) {
    this.documentList[index].document.documentType = docType;
    this.docType[index] = docType;
  }

  selectFile(event) {
    const fileToUpload = { file: event.target.files[0], progress: 0, inProgress: true };
    if (fileToUpload.file.size < this.MAX_FILE_SIZE) {
      if (this.validFileTypes.includes(fileToUpload.file.type) || this.validFileTypes.includes('ALL')) {
        this.filesToUpload.push(fileToUpload);
        event.srcElement.value = null;
        this.uploadStarted.emit(this.counter);
        if (this.counter === 0) {
          this.uploadStarted.emit();
        }
      } else {
        this.toasterService.error('Not valid file format');
      }
      this.uploadFile(fileToUpload);
    } else {
      this.toasterService.error('File size must be less than 1MB');
    }
  }

  uploadFile(fileToUpload: any) {
    this.counter++;
    const fileIndex = this.filesToUpload.length - 1;
    this.filesToUpload[fileIndex].subscription = this.fileUploader.singleFileUploader
      (fileToUpload.file, this.options.documentType, this.options.entityId, this.options.entityType)
      .takeUntil(this.unsubscribe).finally(() => {
        this.filesToUpload[fileIndex].inProgress = false;
        this.decrementFileUploadCount();
      })
      .subscribe(event => {
        if (event.type === HttpEventType.UploadProgress) {
          fileToUpload.progress = Math.min(95, Math.round(100 * event.loaded / event.total));
          console.log(fileToUpload.progress);
        } else if (event instanceof HttpResponse) {
          console.log('File is completely uploaded!');
          console.log('custom file name', this.customFileName);
          fileToUpload.progress = 100;
          const response = JSON.parse((event.body).toString());
          console.log('resp fm doc', response);
          this.documents.push({
            id: response.fileUploadId,
            entityType: this.options.entityType,
            fileName: response.fileName,
          });
        }
      });
  }

  decrementFileUploadCount() {
    if (--this.counter === 0) {
      this.documents.forEach(document => {
        this.selectedValues.unshift(document);
        this.documentList.unshift({ isDataUnsave: true, document: document });
      });

      this.selectedValues.forEach(item => {
        if (!item.hasOwnProperty('documentType')) {
          item.documentType = null;
        }
      });

      //  this.selectedValues = this.documents;
      this.documents = [];
      this.filesToUpload = [];
      this.docType.unshift('Select Document');
      this.uploadFinished.emit(this.documents);
    }
  }

  removeItem(index) {
    this.filesToUpload[index].cancelled = true;
    if (this.filesToUpload[index].inProgress) {
      this.filesToUpload[index].inProgress = false;
      this.filesToUpload[index].subscription.unsubscribe();
      this.decrementFileUploadCount();
    }
  }

  downloadDocument(fileUploadId, fileName) {
    this.downloadFileService.downloadDocument(fileUploadId).subscribe(resp => {
      console.log('download document', resp);
      this.saveFile(resp, fileName);
    });
  }

  saveFile(resp, fileName) {
    const a = document.createElement('a');
    const blob = new Blob([resp], { type: 'octet/stream' });
    const url = window.URL.createObjectURL(blob);
    a.href = url;
    a.download = fileName;
    a.click();
    window.URL.revokeObjectURL(url);
  }

  viewDocument(fileUploadId) {
    this.downloadFileService.downloadDocument(fileUploadId).subscribe(resp => {
      console.log('download document response', resp);
      const type = resp.type;
      this.viewFile(resp, type);
    });
  }
  viewFile(resp, type) {
    const blob = new Blob([resp], { type: type });
    const url = window.URL.createObjectURL(blob);
    window.open(url);
  }
  removeOldItem(index) {
    this.confirmationPopup.confirm({ message: Dictionary.DELETE_CONFIRMATION }).subscribe(data => {
      if (data) {
        this.selectedValues.splice(index, 1);
        this.documentList.splice(index, 1);
        this.docType.splice(index, 1);
      }
    });
  }



}
