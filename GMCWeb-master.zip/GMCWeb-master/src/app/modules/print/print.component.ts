import { Component, OnInit, OnDestroy, ViewChild, Renderer, ElementRef } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { RestapiService } from 'app/core/services/restapi.service';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { FormBuilder, FormGroup } from '@angular/forms';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Location } from '@angular/common';
import * as _isEmpty from 'lodash/isEmpty';
declare var $: any;

@Component({
  selector: 'app-print',
  templateUrl: './print.component.html',
  styleUrls: ['./print.component.css']
})
export class PrintComponent implements OnInit, OnDestroy {
  @ViewChild('htmlContainer') htmlContainer: ElementRef;
  public unsubscribe = new Subject();
  public printDetails: any;
  public printForm: FormGroup;
  public formatList$: Observable<any>;
  public paddingTop: string;
  public paddingBottom: string;
  public paddingRight: string;
  public paddingLeft: string;
  public eventName: string;
  public top = 30;
  public bottom = 0;
  public right = 10;
  public left = 10;
  public printPreferenceId: string;
  public isLandscape = false;
  public isDefault = 'WITHOUT_HEADER';
  public MAX_PAGE_HEIGHT = 1123;
  constructor(
    public activatedRoute: ActivatedRoute,
    public restapiService: RestapiService,
    public renderer: Renderer,
    public formBuilder: FormBuilder,
    public location: Location
  ) {
    this.createPrintForm();
  }

  ngOnInit() {
    this.activatedRoute.queryParams.takeUntil(this.unsubscribe).subscribe((params) => {
      console.log('params', params);
      this.printDetails = {
        clinicId: params.clinicId,
        facilityId: params.facilityId,
        patientId: params.patientId,
        doctorId: params.doctorId,
        encounterId: params.encounterId,
        staffId: params.staffId,
        from: params.from,
        emrType: params.emrType,
        docType: params.docType ? params.docType : ''
      };
      this.getFormatList();
      this.getPrintPreference(params.clinicId, params.doctorId);
    });
    this.paddingTop = this.top + 'px';
    this.paddingBottom = this.bottom + 'px';
    this.paddingLeft = this.left + 'px';
    this.paddingRight = this.right + 'px';
  }


  createPrintForm() {
    this.printForm = this.formBuilder.group({
      templateFormat: [this.isDefault],
      pageOrientation: ['Portrait'],
      marginTop: [30],
      marginBottom: [0],
      marginLeft: [10],
      marginRight: [10],
    });
  }


  /*
     page break code start here
  */
  public createPageBreak(totalNumberOfPageBreak) {
    const contentContaineroffSetTop = 120; // $('#contentCover').offset().top
    if (totalNumberOfPageBreak > 0) {
      for (let i = 1; i <= totalNumberOfPageBreak; i++) {
        this.insertPageBreak(contentContaineroffSetTop + i * this.MAX_PAGE_HEIGHT, totalNumberOfPageBreak);
      }
    }
  }

  public insertPageBreak(offsetTop, totalNumberOfPageBreak) {
    const totalNumberOfElement = $('#contentCover *').filter(function () {
      return offsetTop - 15 <= this.offsetTop && this.offsetTop <= offsetTop + 15;
    });
    $('.custom-break-page, .custom-break-page-absolute').remove();
    if (totalNumberOfElement.length > 0) {
      const $this = this;
      $(`<div class="custom-break-page" style="width: ${$('#contentCover').outerWidth()}px; margin-left: -${$this.paddingLeft}; position: relative; " ></div><div  style="page-break-before: always"></div>`).insertBefore(totalNumberOfElement[0]);

    } else {
      if (totalNumberOfPageBreak > 0) {
        $('#contentCover').append(`<div class="custom-break-page-absolute" style="position: absolute; left: -2px; margin-left: 0px; top: ${(offsetTop - 10) - $('#contentCover').offset().top}px"></div> <div  style="page-break-before: always"></div>`);
      }
    }
  }

  public getHTMLContainerOuterHeight() {
    return $('#contentCover').outerHeight();
  }

  public getNumberOfPageBreak(HTMLContainerOuterHeight) {
    return Math.floor(HTMLContainerOuterHeight / this.MAX_PAGE_HEIGHT);
  }

  public getPrinthtml(clinicId, facilityId, patientId, encounterId, templateFormat) {
    if (this.printDetails.docType !== 'DOCUMENT') {
      if (this.printDetails.from === 'sharedDocument') {
        this.restapiService.printHTML(`/api/clinics/${clinicId}/emrs/${encounterId}/viewHTML`, templateFormat)
          .takeUntil(this.unsubscribe).subscribe((data: any) => {
            console.log('########## from shared', data);
            this.renderer.setElementProperty(this.htmlContainer.nativeElement, 'innerHTML', data.body);
            // if (this.printDetails.emrType === 'GMC_EMR') {
            //   this.createPageBreak(this.getNumberOfPageBreak(this.getHTMLContainerOuterHeight()));
            // }
          });
      } else {
        this.restapiService.
          printHTML(`/api/clinics/${clinicId}/facilities/${facilityId}/patients/${patientId}/encounter/${encounterId}/viewHTML`, templateFormat)
          .takeUntil(this.unsubscribe).subscribe((data: any) => {
            console.log('##############################', data);
            this.renderer.setElementProperty(this.htmlContainer.nativeElement, 'innerHTML', data.body);
            // this.createPageBreak(this.getNumberOfPageBreak(this.getHTMLContainerOuterHeight()));
          });
      }
    } else {
      this.restapiService.invoke(APIEndPoint.GET_DOCUMENT_BY_ID, { documentId: this.printDetails.encounterId })
      .takeUntil(this.unsubscribe)
      .subscribe((res: any) => {
        this.renderer.setElementProperty(this.htmlContainer.nativeElement, 'innerHTML', `<img src="${res.URI}" style="max-width: 100%"/>`);
      });
    }
  }

  public getPrintPreference(clinicId, doctorId) {
    this.restapiService.invoke(APIEndPoint.GET_PRINT_PREFERENCE_BY_DOCTORID, { clinicId, doctorId })
      .takeUntil(this.unsubscribe)
      .subscribe((data: any) => {
        // const value = {'formatting'}
        data = data[data.length - 1];
        this.printPreferenceId = data && data.id ? data.id : null;
        let pathValue;
        if (data) {
          pathValue = {
            templateFormat: data.templateFormat,
            pageOrientation: data.pageOrientation,
            headersAndFooters: data.headersAndFooters,
            marginTop: data.marginTop,
            marginBottom: data.marginBottom,
            marginLeft: data.marginLeft,
            marginRight: data.marginRight,
          };

        } else {
          pathValue = {
            templateFormat: 'WITH_HEADER',
            pageOrientation: 'Portrait',
            headersAndFooters: null,
            marginTop: 35,
            marginBottom: 35,
            marginLeft: 50,
            marginRight: 50,
          };
        }
        this.isLandscape = (pathValue.pageOrientation && pathValue.pageOrientation === 'LandScape') ? true : false;
        this.paddingTop = pathValue.marginTop + 'px';
        this.paddingBottom = pathValue.marginBottom + 'px';
        this.paddingLeft = pathValue.marginLeft + 'px';
        this.paddingRight = pathValue.marginRight + 'px';
        console.log('this is the vlae to path', pathValue);
        this.printForm.patchValue(pathValue);
        this.getPrinthtml(
          this.printDetails.clinicId,
          this.printDetails.facilityId,
          this.printDetails.patientId,
          this.printDetails.encounterId,
          pathValue.templateFormat);
      });
  }


  public getFormatList() {
    console.log(this.printDetails.emrType);
    if (this.printDetails.emrType === 'GMC_APP_UPLOADED_EMR') {
      this.eventName = 'VIEW_EMR_APP_HTML';

    } else if (this.printDetails.emrType === 'GMC_PAD_UPLOADED_EMR') {
      this.eventName = 'VIEW_EMR_PAD_HTML';
    } else {
      this.eventName = 'VIEW_EMR_HTML';
    }
    this.formatList$ = this.restapiService.invoke(APIEndPoint.GET_FORMATES, { eventName: this.eventName });
  }

  public changeFormat(value) {
    this.isDefault = value;
    this.getPrinthtml(
      this.printDetails.clinicId,
      this.printDetails.facilityId,
      this.printDetails.patientId,
      this.printDetails.encounterId,
      this.isDefault);
  }



  public changeMargin(place, value) {
    value = value + 'px';
    console.log('value', value);
    switch (place) {
      case 'top':
        this.paddingTop = value;
        break;
      case 'bottom':
        this.paddingBottom = value;
        break;
      case 'left':
        this.paddingLeft = value;
        $('.custom-break-page').css({ 'margin-left': '-' + value });
        break;
      case 'right':
        this.paddingRight = value;
        break;
    }
  }

  public printPrescription() {
    this.updatePrintPreference().takeUntil(this.unsubscribe)
      .subscribe((data) => {

        const html = `<style type="text/css" media="print">
    @media print{
      .prescription-body {
        font-size: "Roboto", sans-serif !important;
        max-width: 100% !important;
        padding: 0px !important;
        font-size: 14px !imortant;
        min-height: 0 !important;
        background: none !important;
      }
      .prescription-body .patient-data {
        font-size: 14px !important;
      }
      .name {
        font-size: 16px;
      }
      body {
        background-color: #fff !important;
      }
      .comma li {
        margin-bottom: 0px;
      }
      .complaints-observation .patient-data,.complaints-observation .comma {
        display: inline;
      }
      @page {
        size: ${this.printForm.value.pageOrientation};
        margin-top: ${this.paddingTop};
        margin-bottom: ${this.paddingBottom};
        margin-right: ${this.paddingRight};
        margin-left: ${this.paddingLeft};
      }
    }
  </style>${this.htmlContainer.nativeElement.innerHTML}`;

        const printHeight = window.innerHeight * 0.9;
        const printWidth = window.innerWidth * 0.8;
        const printwWindow = window.open('', '_blank', 'toolbar=no,scrollbars=yes,resizable=yes,location=no,top=100,left=100,width='
          + printWidth + ',height=' + printHeight);
        if (!printwWindow) {
          alert('Please allow pop-ups on this site!');
        }
        // this.location.back();
        printwWindow.document.write(html);
        printwWindow.document.close();
        printwWindow.print();
        printwWindow.close();
        this.location.back();
      }, (error) => {
        console.log('get some error', error);
      });
  }

  updatePrintPreference() {
    if (_isEmpty(this.printPreferenceId)) {
      return this.restapiService.invoke(APIEndPoint.POST_PRINT_PREFERENCE,
        { clinicId: this.printDetails.clinicId, doctorId: this.printDetails.doctorId, }, this.printForm.value)
        .map((data) => {
          return data;
        });
    } else {
      return this.restapiService.invoke(APIEndPoint.UPDATE_PRINT_PREFERENCE_BY_ID,
        {
          clinicId: this.printDetails.clinicId,
          doctorId: this.printDetails.doctorId,
          printPreferenceId: this.printPreferenceId
        }, this.printForm.value)
        .map((data) => {
          return data;
        });
    }
  }

  public goBack() {
    this.location.back();
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
