import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SharedModule } from 'app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InformationRoutingModule } from 'app/modules/information/information.routes';
import { ContactComponent } from 'app/modules/information/contact/contact.component';
import { UnderMaintenanceComponent } from './under-maintenance/under-maintenance.component';

@NgModule({
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    InformationRoutingModule

  ],
  declarations: [
    ContactComponent,
    UnderMaintenanceComponent,
  ]
})
export class InformationModule { }
