import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactComponent } from 'app/modules/information/contact/contact.component';
import { UnderMaintenanceComponent } from './under-maintenance/under-maintenance.component';




const INFORMATION_ROUTES: Routes = [
    {
        path: 'contact',
        component: ContactComponent
    },
    {
        path: 'under-maintenance',
        component: UnderMaintenanceComponent
    },
];

@NgModule({
    exports: [RouterModule],
    imports: [RouterModule.forChild(INFORMATION_ROUTES)],
})

export class InformationRoutingModule { }
