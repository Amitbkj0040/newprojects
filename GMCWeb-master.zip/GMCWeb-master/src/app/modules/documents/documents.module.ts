import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { DocumentDetailsComponent } from 'app/modules/documents/document-details/document-details.component';
import { DocumentListComponent } from 'app/modules/documents/document-list/document-list.component';
import { DocumentsRoutingModule } from 'app/modules/documents/documents.routes';
import { VitalDetailsComponent } from './vital-details/vital-details.component';
@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    DocumentsRoutingModule
  ],
  declarations: [
    DocumentDetailsComponent,
    DocumentListComponent,
    VitalDetailsComponent
  ]
})
export class DocumentsModule { }
