import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vital-details',
  templateUrl: './vital-details.component.html',
  styleUrls: ['./vital-details.component.css']
})
export class VitalDetailsComponent implements OnInit {
  type = 'sharedWithMe';
  constructor() { }

  ngOnInit() {
  }

}
