import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainViewComponent } from 'app/modules/main-view/main-view.component';
import { LoginRouteGuardGuard } from 'app/core/auth/login-route-guard.guard';
import { SubscriptionRouteGuardGuard } from 'app/core/auth/subscription-route-guard.guard';
import { AgreementRouteGuardGuard } from 'app/core/auth/agreement-route-guard.guard';
import { DocumentListComponent } from 'app/modules/documents/document-list/document-list.component';
import { DocumentDetailsComponent } from 'app/modules/documents/document-details/document-details.component';
import { VitalDetailsComponent } from './vital-details/vital-details.component';




const DOCUMENTS_ROUTES: Routes = [
    {
        path: 'clinic-view/clinics/:clinicId/facilities/:facilityId',
        component: MainViewComponent,
        canActivate: [LoginRouteGuardGuard, SubscriptionRouteGuardGuard, AgreementRouteGuardGuard],
        children: [
            { path: '', redirectTo: 'encounter/', pathMatch: 'full' },
            { path: 'staffs/:staffId/documents/:type', component: DocumentListComponent },
            { path: 'staffs/:staffId/document-details/:encounterId/:type', component: DocumentDetailsComponent },
            { path: 'staffs/:staffId/vitals/:sharedWithId', component: VitalDetailsComponent },
        ]
    },

];

@NgModule({
    exports: [RouterModule],
    imports: [RouterModule.forChild(DOCUMENTS_ROUTES)],
})

export class DocumentsRoutingModule { }
