import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RestapiService } from 'app/core/services/restapi.service';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';

@Component({
  selector: 'app-document-list',
  templateUrl: './document-list.component.html',
  styleUrls: ['./document-list.component.css']
})
export class DocumentListComponent implements OnInit, OnDestroy {
  public pageNumber = 0;
  public pageSize = 10;
  public sort = '';
  public sortOn = '';
  public clinicId: string;
  public facilityId: string;
  public patientId: string;
  public encounterId: string;
  public staffId: string;
  public type = 'allEncounters';
  public docHeading = 'All Encounters';
  public encountersList$: Observable<any[]>;
  public _encounters = new Subject<any[]>();
  public encounters$ = this._encounters.asObservable();
  public encounters: any[] = [];
  public isRequesting = false;
  public sharedByMeEncounters$: Observable<any[]>;
  public _sharedByEncounters = new Subject<any[]>();
  public sharedByEncounters$ = this._sharedByEncounters.asObservable();
  public sharedByEncounters: any[] = [];
  public sharedWithMeEncounters$: Observable<any[]>;
  public _sharedWithEncounters = new Subject<any[]>();
  public sharedWithEncounters$ = this._sharedWithEncounters.asObservable();
  public sharedWithEncounters: any[] = [];
  private unsubscribe = new Subject();
  public selectedDocuments: Document[];
  public showPresShare = false;
  public showAccess = false;
  public searchText;
  public paginationFirstIndex = 0;
  public selectedPageIndex = 0;
  public totalDocumentList = [];
  public totalNoOfDocument = 0;
  public MIN_PAGE_BADGE = 3;


  constructor(private restapiservice: RestapiService,
    private router: Router,
    private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    Observable.combineLatest(this.activatedRoute.parent.params, this.activatedRoute.params)
      .takeUntil(this.unsubscribe).subscribe(responses => {
        console.log(responses);
        this.clinicId = responses[0]['clinicId'];
        this.facilityId = responses[0]['facilityId'];
        this.staffId = responses[1]['staffId'];
        this.type = responses[1]['type'];
        console.log('typeee', this.type);
        if (this.type === 'allEncounters') {
          this.pageNumber = 0;
          this.encounters = [];
          this.docHeading = 'All Encounters';
          this.encountersList$ = this.encounters$.map(res => {
            console.log('hello this is the res', res);
            return res;
          });
          this.pageNumber !== 0 ? this.getEncounters() : this.getEncounter(this.pageNumber, this.pageSize);
        } else if (this.type === 'sharedByMe') {
          this.pageNumber = 0;
          this.sharedByEncounters = [];
          this.docHeading = 'Encounters Shared By Me';
          this.sharedByMeEncounters$ = this.sharedByEncounters$;
          this.pageNumber !== 0 ? this.getSharedByEncounters() : this.getSharedByEncounter(this.pageNumber, this.pageSize);
        } else if (this.type === 'sharedWithMe') {
          this.pageNumber = 0;
          this.sharedWithEncounters = [];
          this.docHeading = 'Encounters Shared With Me';
          this.sharedWithMeEncounters$ = this.sharedWithEncounters$;
          this.pageNumber !== 0 ? this.getSharedWithEncounters() : this.getSharedWithEncounter(this.pageNumber, this.pageSize);
        }

      });
  }

  getEncounter(pageNumber, pageSize) {
    this.isRequesting = true;
    this.restapiservice
      .invoke<any>(APIEndPoint.GET_ALL_ENCOUNTERS,
        { clinicId: this.clinicId, staffId: this.staffId }, null,
        {
          'pageNumber': pageNumber,
          'pageSize': pageSize,
          'sort': this.sort,
          'sortOn': this.sortOn
        }).subscribe((encRes: any) => {
          console.log('hello this is the updated data', encRes);
          this.isRequesting = false;
          this.totalDocumentList = new Array(this.getPageCount(encRes.count, pageSize));
          this.encounters = [];
          encRes.data.forEach(element => {
            this.encounters.push(element);
          });
          this._encounters.next(this.encounters);
        }, err => {
          this.isRequesting = false;
          console.log(err);
        });

  }


  public changePaginationBadges(isNext) {
    const MIN_PAGE_BADGE = this.MIN_PAGE_BADGE - 1;
    if (isNext) {
      this.paginationFirstIndex = this.paginationFirstIndex + MIN_PAGE_BADGE < this.totalDocumentList.length - (MIN_PAGE_BADGE + 1) ?
        this.paginationFirstIndex + MIN_PAGE_BADGE : this.totalDocumentList.length - (MIN_PAGE_BADGE + 1);
    } else {
      this.paginationFirstIndex = this.paginationFirstIndex - (MIN_PAGE_BADGE) >= 0 ? this.paginationFirstIndex - MIN_PAGE_BADGE : 0;
    }
  }

  public getEncounterByPageNo(index, pageNumber) {
    this.getDocuments(pageNumber);
    const MIN_PAGE_BADGE = this.MIN_PAGE_BADGE - 1;
    this.selectedPageIndex = pageNumber;
    if (index === MIN_PAGE_BADGE) {
      this.changePaginationBadges(true);
    } else if (index === 0) {
      this.changePaginationBadges(false);
    }
  }

  public getDocuments(pageNumber) {
    switch (this.type) {
      case 'allEncounters':
        this.getEncounter(pageNumber, this.pageSize);
        break;
      case 'sharedByMe':
        this.getSharedByEncounter(pageNumber, this.pageSize);
        break;
      case 'sharedWithMe':
        this.getSharedWithEncounter(pageNumber, this.pageSize);
        break;
    }
  }


  public gotoEndToEnd(isFirst) {
    const MIN_PAGE_BADGE = this.MIN_PAGE_BADGE - 1;
    if (isFirst) {
      this.paginationFirstIndex = 0;
      this.getEncounter(1, this.pageSize);
    } else {
      this.paginationFirstIndex = this.totalDocumentList.length - (MIN_PAGE_BADGE + 1);
      this.getEncounter(this.totalDocumentList.length - 1, this.pageSize);
    }
  }

  getEncounters() {
    this.encountersList$ = this.restapiservice.invoke<any[]>(APIEndPoint.GET_ALL_ENCOUNTERS,
      { clinicId: this.clinicId, staffId: this.staffId }, null).map(res => {
        console.log('hello res', res);
        return res;
      });
  }

  public getPageCount(totalDocument, pageSize) {
    this.totalNoOfDocument = totalDocument;
    // tslint:disable-next-line:no-bitwise
    return (totalDocument / pageSize | 0) + 1;
  }

  getSharedByEncounter(pageNumber, pageSize) {
    this.isRequesting = true;
    this.paginationFirstIndex = 0;
    this.restapiservice
      .invoke<any>(APIEndPoint.GET_ENCOUNTER_SHARED_BY_ME,
        { clinicId: this.clinicId, staffId: this.staffId }, null,
        {
          'pageNumber': pageNumber,
          'pageSize': pageSize,
          'sort': this.sort,
          'sortOn': this.sortOn
        }).subscribe((encRes: any) => {
          this.isRequesting = false;
          this.totalDocumentList = new Array(this.getPageCount(encRes.count, pageSize));
          // encRes.data.forEach(element => {
          //   this.sharedByEncounters.push(element);
          // });
          this._sharedByEncounters.next(encRes.data);
        }, err => {
          this.isRequesting = false;
          console.log(err);
        });

  }
  getSharedByEncounters() {
    this.paginationFirstIndex = 0;
    this.sharedByMeEncounters$ = this.restapiservice.invoke<any[]>(APIEndPoint.GET_ENCOUNTER_SHARED_BY_ME,
      { clinicId: this.clinicId, staffId: this.staffId }, null).map(res => {
        return res;
      });
  }
  getSharedWithEncounter(pageNumber, pageSize) {
    this.isRequesting = true;
    this.paginationFirstIndex = 0;
    this.restapiservice
      .invoke<any>(APIEndPoint.GET_ENCOUNTER_SHARED_WITH_ME,
        { clinicId: this.clinicId, staffId: this.staffId }, null,
        {
          'pageNumber': pageNumber,
          'pageSize': pageSize,
          'sort': this.sort,
          'sortOn': this.sortOn
        }).subscribe((encRes: any) => {
          this.isRequesting = false;
          this.totalDocumentList = new Array(this.getPageCount(encRes.count, pageSize));
          // encRes.data.forEach(element => {
          //   this.sharedWithEncounters.push(element);
          // });
          this._sharedWithEncounters.next(encRes.data);
        }, err => {
          this.isRequesting = false;
          console.log(err);
        });


  }
  getSharedWithEncounters() {
    this.paginationFirstIndex = 0;
    this.sharedWithMeEncounters$ = this.restapiservice.invoke<any[]>(APIEndPoint.GET_ENCOUNTER_SHARED_WITH_ME,
      { clinicId: this.clinicId, staffId: this.staffId }, null).map(res => {
        return res;
      });
  }

  getNameFromVitalLabel(label: string) {
    return label.split(':')[0];
  }
  getMetalVitalsFromVitalLabel(label: string) {
    return label.split(':')[1];
  }


  onShare(encounterid, patientid) {
    this.showPresShare = !this.showPresShare;
    this.encounterId = encounterid;
    this.patientId = patientid;

  }
  onAccess(encounterid, patientid) {
    console.log('hello');
    this.showAccess = !this.showAccess;
    console.log('hello', this.showAccess);
    this.encounterId = encounterid;
    this.patientId = patientid;
  }

  onDoctorEncounterClick(id, docType) {
    this.router.navigate(['clinic-view/clinics/' + this.clinicId + '/facilities/'
      + this.facilityId + '/staffs/' + this.staffId + '/document-details/' + id + '/' + docType]);
  }

  onDocumentClicked(sharedWithEncounter, docType) {
    if (sharedWithEncounter.type === 'VITAL') {
      this.router.navigate(['clinic-view/clinics/' + this.clinicId + '/facilities/'
        + this.facilityId + '/staffs/' + this.staffId + '/vitals/' + sharedWithEncounter.sharedWithId]);
    } else {
      this.router.navigate(['clinic-view/clinics/' + this.clinicId + '/facilities/'
        + this.facilityId + '/staffs/' + this.staffId + '/document-details/' + sharedWithEncounter.id + '/' + docType], 
        {queryParams: {type: sharedWithEncounter.type}});
    }
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

}
