import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RestapiService } from 'app/core/services/restapi.service';
import { DownloadFileService } from 'app/core/services/download-file.service';
import { Encounter } from 'app/core/models/app.models';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Location } from '@angular/common';

@Component({
  selector: 'app-document-details',
  templateUrl: './document-details.component.html',
  styleUrls: ['./document-details.component.css']
})
export class DocumentDetailsComponent implements OnInit {
  public clinicId: string;
  public facilityId: string;
  public staffId: string;
  public encounterId: string;
  public patientId: string;
  public type = 'allEncounters';
  public docType: string;
  public patientEncounterView: Encounter;
  private unsubscribe = new Subject();
  public selectedDocuments: Document[];
  public showPresShare = false;
  public showAccess = false;
  public searchText;


  constructor(
    private restapiservice: RestapiService,
    private router: Router,
    public downloadFileService: DownloadFileService,
    private activatedRoute: ActivatedRoute,
    public location: Location
  ) { }

  ngOnInit() {
    Observable.combineLatest(this.activatedRoute.parent.params, this.activatedRoute.params, this.activatedRoute.queryParams)
      .takeUntil(this.unsubscribe).subscribe(responses => {
        console.log(responses);
        this.clinicId = responses[0]['clinicId'];
        this.facilityId = responses[0]['facilityId'];
        this.staffId = responses[1]['staffId'];
        this.encounterId = responses[1]['encounterId'];
        this.type = responses[1]['type'];
        this.docType = responses[2]['type'];
        console.log('responses from path', responses);
        this.getEncounterDetails();

      });

  }
  getEncounterDetails() {
    const apiEndPoint = this.docType === 'DOCUMENT' ? APIEndPoint.GET_DOCUMENT_BY_ID : APIEndPoint.GET_SHARED_ENCOUNTER_BY_ID;
    const params = this.docType === 'DOCUMENT' ? { documentId: this.encounterId } :
      { clinicId: this.clinicId, staffId: this.staffId, encounterId: this.encounterId };
    this.restapiservice.invoke<Encounter>(apiEndPoint, params
    ).takeUntil(this.unsubscribe).subscribe(res => {
      this.patientEncounterView = res;
      console.log('patient-encounter', this.patientEncounterView);
    });
  }

  onBack() {
    this.location.back();
  }

  printPrescription(event) {
    if (event) {
      this.router.navigate(['/print'], {
        queryParams:
        {
          clinicId: this.clinicId,
          facilityId: this.facilityId,
          doctorId: this.staffId,
          staffId: this.staffId,
          encounterId: this.encounterId,
          from: 'sharedDocument',
          emrType: this.patientEncounterView.emrType,
          docType: this.docType
        }
      });
    }
  }

}
