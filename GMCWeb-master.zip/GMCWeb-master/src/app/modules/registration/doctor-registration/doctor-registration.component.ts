import { Component, OnInit, OnDestroy, HostListener, ElementRef, ViewEncapsulation } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Doctor } from 'app/core/models/app.models';
import { RestapiService } from 'app/core/services/restapi.service';
import { Router, ActivatedRoute } from '@angular/router';
import { APIEndPoint, APIDef } from 'app/core/models/ApiEndPoint';
import { City } from 'app/core/models/city';
import { Observable } from 'rxjs/Observable';
import { Speciality } from 'app/core/models/speciality';
import { Subject } from 'rxjs/Subject';
import { IMyDpOptions } from 'mydatepicker';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { Dictionary } from 'app/core/models/dictionary';
import { AuthService } from 'app/core/auth/auth.service';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { share } from 'rxjs/operators';
import { UtilityService } from 'app/core/services/utility.service';
import { UniqueNameService } from 'app/core/services/unique-name.service';
import { BLOOD_GROUPS } from 'app/core/models/bloodGroup.list';
import { Country, DEFAULT_COUNTRY } from 'app/core/models/country';
import { PostCodeValidatorService } from 'app/core/services/post-code-validator.service';
import { COUNTRY_CODE_LIST } from 'app/core/models/DialCodeList';
import { PhoneValidator } from 'app/core/validators/phone.validator';
import { DEFAULT_COUNTRY_CODE } from 'app/core/models/GlobalVariable';

declare var $: any;

@Component({
  selector: 'app-doctor-registration',
  templateUrl: './doctor-registration.component.html',
  styleUrls: ['./doctor-registration.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class DoctorRegistrationComponent implements OnInit, OnDestroy {

  public myDatePickerOptions: IMyDpOptions = {
    // other options...
    dateFormat: 'yyyy-mm-dd',
  };
  model;
  apiPE: APIDef = APIEndPoint.GET_PHYSICALEXAMS;
  physicalExams: string[] = [];
  selectedPhysicalExams: Object[] = [];
  private unsubscribe = new Subject<void>();
  doctorForm: FormGroup;
  public mydate: any;
  selectedCity: City;
  public facilityId: string;
  public clinicId: string;
  public specialityDefaultIndex = 0;
  public cityDefaultIndex = 0;
  public doctor$: Observable<Doctor>;
  public doctorId: string;
  public title = 'Mr';
  public isTitleChange = false;
  public isCalShow = false;
  public specialistIn: string;
  public sign = 'abc';
  public doctorGetById: any;
  public cities$: Observable<City>;
  cityApiEndPoint = APIEndPoint.GET_CITIES;
  public specialities$: Observable<Speciality>;
  public bloodGroups = BLOOD_GROUPS;
  public genderList = ['Male', 'Female', 'TG'];
  public selectedCit: object;
  public actionMode: string;
  public isAddressFilled = false;
  public domainName: string;
  public isAdmin: boolean;
  public loginNameExists: boolean;
  apiLN: APIDef = APIEndPoint.GET_LOGIN_NAME;
  countries$: Observable<Country>;
  selectedCountry: Country = DEFAULT_COUNTRY;
  AUTH_TOKEN: any = '';
  isAddressValid: boolean;
  countryCode: any = 'in';
  mode = 'add';


  constructor(public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    public toastrService: ToastrService,
    private formBuilder: FormBuilder,
    public confirmationPopup: ConfirmationPopupService,
    public authService: AuthService,
    private jwtHelperService: JwtHelperService,
    private utilityservice: UtilityService,
    private uniqueNameService: UniqueNameService,
    private postCodeValidatorService: PostCodeValidatorService
  ) {
    this.createForm();
  }

  public setSpeciality(value) {
    console.log('speciality value', value);
    this.doctorForm.patchValue({ specialistIn: value });
  }

  ngOnInit() {
    this.AUTH_TOKEN = this.jwtHelperService.decodeToken(this.authService.getAuthToken());
    this.domainName = this.authService.getdomainName();
    this.countries$ = this.restapiservice.invoke<Country>(APIEndPoint.GET_COUNTRIES).map((res: any) => {
      res.unshift({ id: null, name: 'Select Country', countryCode: null });
      return res;
    });
    if (this.authService.isUserDoctor) {
      this.doctorId = this.authService.getStaffId();
      this.activatedRoute.params.takeUntil(this.unsubscribe).subscribe(params => {
        this.clinicId = params['clinicId'];
        console.log(this.clinicId);
      });
    }
    this.specialities$ = this.restapiservice.invoke<Speciality>(APIEndPoint.GET_SPECIALITIES);
    this.createForm();
    this.formOnChnages();
    this.getCountry();
  }

  formOnChnages() {
    this.doctorForm.controls['loginName'].valueChanges.debounceTime(400)
      .switchMap(term => this.getLoginName(term)).subscribe(resp => { this.loginNameExists = resp; },
        err => { this.loginNameExists = false; });
  }

  getCountry() {
    this.restapiservice.invoke<Country>(APIEndPoint.GET_COUNTRIES).takeUntil(this.unsubscribe).subscribe((res: any) => {
      const countryCodeList = res.map(elem => elem.countryCode);
      this.doctorForm.controls['phone'].setValue(this.doctorForm.controls['phone'].value);
      this.getSelectedCountry(countryCodeList);
    });
  }

  getSelectedCountry(countryCodeList) {
    setTimeout(() => {
      $('#country-listbox li').each(function () {
        if (!countryCodeList.includes($(this).attr('data-dial-code'))) {
          $(this).addClass('hide');
        }
      }, 500);
    });
  }

  setCountryCode(event) {
    this.doctorForm.patchValue({ countryCode: event.dialCode });
    const selectedCountryCode: any = COUNTRY_CODE_LIST.find(elem => elem.dialCode === event.dialCode);
    this.countryCode = selectedCountryCode.countryCode ? selectedCountryCode.countryCode : 'in';
    this.updatePhoneValidation(this.countryCode.toUpperCase());
  }

  updatePhoneValidation(countryIATACode) {
    const phoneControl = this.doctorForm.get('phone');
    phoneControl.setValidators([Validators.required, PhoneValidator(countryIATACode)]);
    phoneControl.setValue(phoneControl.value);

    const alternatePhoneControl = this.doctorForm.get('alterPhone');
    alternatePhoneControl.setValidators([PhoneValidator(countryIATACode)]);
    alternatePhoneControl.setValue(alternatePhoneControl.value);
  }

  getLoginName(userName: string): Observable<boolean> {
    return this.uniqueNameService.getDomainOrLoginName({ 'userName': userName }, this.apiLN);
  }


  @HostListener('window:beforeunload', ['$event'])
  public reloadDoctor($event) {
    let hasChanges = false;
    if (this.doctorForm.dirty) {
      console.log('dirtyyyy');
      hasChanges = true;
    }
    if (hasChanges) {
      $event.returnValue = Dictionary.LEAVE_PAGE_ALERT;
    }
  }

  setDOB(value) {
    const age = (new Date()).getFullYear() - value.data.getFullYear();
    this.doctorForm.controls['dob'].setValue(value.data);
    if (value.self) {
      this.doctorForm.controls['age'].setValue(age);
    }
    console.log('doctor details', this.doctorForm.getRawValue());
  }

  saveDoctor() {
    const formObj = this.doctorForm.getRawValue();
    if (formObj.specialistIn.name === '' || formObj.specialistIn.name === undefined || formObj.specialistIn.name === null) {
      this.toastrService.error(Dictionary.SPECIALITY_REQ);
    }
    if (formObj.credential === '' || formObj.credential === null || formObj.credential === undefined) {
      this.toastrService.error(Dictionary.PASSWORD_REQ);
    }
    this.doctorForm.controls['title'].setValue(this.title);
    this.doctorForm.controls['physicalExams'] = new FormControl(this.physicalExams);
    this.createDoctor();
  }


  validateAddress(address) {
    if (this.utilityservice.areAllFieldsNull(address.city)) {
      address.city = null;
    }
    if (this.utilityservice.areAllFieldsNull(address.country)) {
      address.country = null;
    }
    if (this.utilityservice.areAllFieldsNull(address.city) &&
      this.utilityservice.areAllFieldsNull(address.city) && (address.address1 === null || address.address1 === '') &&
      (address.zip === null || address.zip === '')) {
      address = null;
    }

    if (!this.AUTH_TOKEN.isVirtualClinic && this.isAddressFilled) {
      this.doctorForm.patchValue({ address: { country: this.selectedCountry } });
      address.country = this.selectedCountry;
    }
    return address;
  }

  createDoctor() {
    this.doctorForm.controls['email'].setValue(this.doctorForm.getRawValue().email ? this.doctorForm.getRawValue().email : null);
    this.doctorForm.controls['lastName'].setValue(this.doctorForm.getRawValue().lastName ? this.doctorForm.getRawValue().lastName : null);
    this.doctorForm.controls['alterPhone']
      .setValue(this.doctorForm.getRawValue().alterPhone ? this.doctorForm.getRawValue().alterPhone : null);
    const doctorDetails = this.doctorForm.getRawValue();
    doctorDetails.address = this.validateAddress(doctorDetails.address);
    if (!this.loginNameExists) {
      this.restapiservice
        .invoke<Doctor>(APIEndPoint.CREATE_DOCTOR,
          { clinicId: this.clinicId }, doctorDetails).subscribe(doctor => {
            console.log('successfully added', doctor);
            this.toastrService.success(Dictionary.SUCCESSFUL_REGISTRATION({ EntityName: doctor.firstName }));
            this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/facilities']);
          }, error => {
            this.toastrService.error(Dictionary.ERROR_MSG);
          });
    } else {
      this.showError();
    }
  }

  showError() {
    this.toastrService.error(Dictionary.LOGIN_NAME_EXIST);
  }


  createForm() {
    this.doctorForm = this.formBuilder.group({
      title: [this.title, [Validators.required]],
      staffType: ['DOCTOR', [Validators.required]],
      age: [null, Validators.compose([/*Validators.required  */, Validators.minLength(2), Validators.maxLength(3),
        Validators.pattern('(^[2-9][0-9]$)|(^[1][0-5][0-9]$)')])],
      firstName: ['', Validators.compose([Validators.required,
      Validators.minLength(2), Validators.pattern('[a-zA-Z ]*')])],
      lastName: [null, Validators.compose([Validators.pattern('[a-zA-Z ]*')])],
      email: [null, Validators.compose([Validators.pattern('[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}')])],
      gender: [null, Validators.required],
      practiceLicense: [null, Validators.required],
      qualification: [null],
      occupation: [null, Validators.compose([Validators.pattern('[a-zA-Z ]*')])],
      bloodGroup: [null],
      signature: [this.sign],
      loginName: [null],
      logo: [null],
      countryCode: [DEFAULT_COUNTRY_CODE, Validators.required],
      credential: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9\s!@#$%^&*()_-]{8,20}$/)])],
      specialistIn: [{
        id: '',
        name: '',
        description: ''
      }, Validators.required],
      metaVitals: this.formBuilder.array([this.formBuilder.group({
        id: '',
        name: '',
        unit: ''
      })]),
      dob: [null, Validators.compose([/*Validators.required  */])],
      document: [[]],
      phone: ['', Validators.compose([Validators.required, PhoneValidator(this.countryCode)])],
      alterPhone: [null, [PhoneValidator(this.countryCode)]],
      address: this.formBuilder.group({
        id: null,
        address1: [null, Validators.required],
        address2: [null],
        city: [{
          id: null,
          name: null
        }],
        country: [{
          id: null,
          name: null,
          countryIATACode: null,
          countryI: null,
          pinCodeLength: null
        }],
        zip: [null, Validators.compose([Validators.required])]
      })
    });
  }

  setLastName() {
    this.doctorForm.controls['lastName'].setValue(this.doctorForm.controls['lastName'].value === '' ? null :
      this.doctorForm.controls['lastName'].value);
  }

  setEmail() {
    this.doctorForm.controls['email'].setValue(this.doctorForm.controls['email'].value === '' || undefined ? null :
      this.doctorForm.controls['email'].value);
  }

  setAlterPhone() {
    this.doctorForm.controls['alterPhone'].setValue(this.doctorForm.controls['alterPhone'].value === '' ? null :
      this.doctorForm.controls['alterPhone'].value);
  }

  get address() {
    return this.doctorForm.get('address') as FormGroup;
  }


  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

}
