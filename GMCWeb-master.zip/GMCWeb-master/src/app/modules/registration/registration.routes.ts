import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginRouteGuardGuard } from 'app/core/auth/login-route-guard.guard';
import { SubscriptionRouteGuardGuard } from 'app/core/auth/subscription-route-guard.guard';
import { AgreementRouteGuardGuard } from 'app/core/auth/agreement-route-guard.guard';
import { ClinicRegisterationComponent } from 'app/modules/registration/clinic-registeration/clinic-registeration.component';
import { FacilityRegistrationComponent } from 'app/modules/registration/facility-registration/facility-registration.component';
import { DoctorRegistrationComponent } from 'app/modules/registration/doctor-registration/doctor-registration.component';



const REGISTRATION_ROUTES: Routes = [
    {
        path: '',
        redirectTo: 'prelogin',
        pathMatch: 'full'
    },
    {
        path: 'clinics/:action',
        component: ClinicRegisterationComponent,
    },
    {
        path: 'clinics/:clinicId/:action',
        component: ClinicRegisterationComponent,
        canActivate: [LoginRouteGuardGuard, SubscriptionRouteGuardGuard, AgreementRouteGuardGuard]
    },
    {
        path: 'clinic-view/:clinicId/facility-registration',
        component: FacilityRegistrationComponent,
        canActivate: [LoginRouteGuardGuard, AgreementRouteGuardGuard]
    },
    {
        path: 'clinic-view/:clinicId/doctor-registration',
        component: DoctorRegistrationComponent,
        canActivate: [LoginRouteGuardGuard, AgreementRouteGuardGuard]
    },
];

@NgModule({
    exports: [RouterModule],
    imports: [RouterModule.forChild(REGISTRATION_ROUTES)],
})

export class RegistrationRoutingModule { }
