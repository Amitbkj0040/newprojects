import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClinicRegisterationComponent } from './clinic-registeration.component';

describe('ClinicRegisterationComponent', () => {
  let component: ClinicRegisterationComponent;
  let fixture: ComponentFixture<ClinicRegisterationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClinicRegisterationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClinicRegisterationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
