import { Component, OnInit, OnDestroy } from '@angular/core';
import { ClinicDetails } from 'app/core/models/clinicDetails';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { RestapiService } from 'app/core/services/restapi.service';
import { APIEndPoint, APIDef } from 'app/core/models/ApiEndPoint';
import { City } from 'app/core/models/city';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs/Observable';
import { Domain } from 'app/core/models/app.models';
import { Subject } from 'rxjs/Subject';
import { AuthService } from 'app/core/auth/auth.service';
import { Dictionary } from 'app/core/models/dictionary';
import { Location } from '@angular/common';
import { UniqueNameService } from 'app/core/services/unique-name.service';
import { DEFAULT_COUNTRY } from 'app/core/models/country';


@Component({
  selector: 'app-clinic-registeration',
  templateUrl: './clinic-registeration.component.html',
  styleUrls: ['./clinic-registeration.component.css']
})


export class ClinicRegisterationComponent implements OnInit, OnDestroy {
  private unsubscribe = new Subject<void>();
  apiSP: APIDef = APIEndPoint.GET_SPECIALITIES;
  selectedSpecialities: Object[] = [];
  domain$: Observable<Domain>;
  public CityDefaultIndex = 0;
  userForm: FormGroup;
  mode = 'add';
  public isDisabled = false;
  public isDomainDisabled = false;
  public clinic$: Observable<ClinicDetails>;
  // public isNewClinic = true;
  // public addNewPanelAcitve = true;
  public profileImg = 'assets/img/add-profile.png';
  public uploadedProfileImage: any;
  // public hasImage: boolean;
  public clinic: any;
  public clinictype = true;
  // public isDoctor = false;
  // public clinicFacilityType: false;
  public clinicId: string;
  public doctorId: string;
  domainExists = false;
  public cities$: Observable<City>;
  domainSubject = new Subject<void>();
  panelTitle = 'Clinic Registration';
  public isMutilpleFacility: boolean = null;
  public selfChange = false;
  public isRequesting: boolean;
  apiDM: APIDef = APIEndPoint.GET_DOMAIN;
  cityApiEndPoint = APIEndPoint.GET_CITIES;

  constructor(
    public router: Router,
    public restapiService: RestapiService,
    public toastrService: ToastrService,
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private authService: AuthService,
    private location: Location,
    private uniqueNameService: UniqueNameService
  ) {
    this.createForm();
  }

  private setCity(value) {
    console.log('city value', value);
    this.userForm.patchValue({ address: { city: value } });
  }

  resetCity() {
    this.userForm.patchValue({ address: { city: null } });
  }

  ngOnInit() {
    this.doctorId = this.authService.getStaffId();
    this.cities$ = this.restapiService.invoke<City>(APIEndPoint.GET_CITIES, {countryId: DEFAULT_COUNTRY.id});
    Observable.combineLatest(this.activatedRoute.params).takeUntil(this.unsubscribe).subscribe(params => {
      this.clinicId = params[0]['clinicId'];
      this.mode = params[0]['action'];
      console.log('mode', this.mode);
      if (this.mode !== 'add') {
        this.clinic$ = this.restapiService.invoke<ClinicDetails>(APIEndPoint.GET_CLINIC_BY_ID,
          { clinicId: this.clinicId })
          .map(clinic => {
            this.profileImg = clinic.logo;
            if (this.mode === 'edit') {
              this.userForm.enable();
              this.isDisabled = false;
              this.isDomainDisabled = true;
              //  this.userForm.controls['name'].disable();
              this.userForm.get('domainName').disable();
              this.panelTitle = 'Edit Clinic';
            } else if (this.mode === 'view') {
              this.userForm.disable();
              this.isDisabled = true;
              this.panelTitle = 'Clinic View';
            }
            this.profileImg = clinic.logo;
            this.userForm.patchValue(clinic);
            this.selectedSpecialities = clinic.specialities;
            console.log('clinic', clinic);
            return clinic;
          });
      }
    });
  }
  // if (this.mode === 'view') {
  //   this.userForm.disable();
  //   this.isDisabled = true;
  // }

  changeProfileImage(event) {
    this.isRequesting = true;
    this.uploadedProfileImage = event;
  }
  uploadProfile(event) {
    this.isRequesting = false;
    if (event) {
      const partialText = event['partialText'];
      this.profileImg = JSON.parse(partialText)['fileDownloadUri'];
    }
    // this.userForm.controls['logo'] = new FormControl(event);
  }
  cancelClinic() {
    this.router.navigate(['/clinics/' + this.clinicId + '/view']);
  }

  saveClinic() {
    this.userForm.controls['specialities'] = new FormControl(this.selectedSpecialities);
    this.userForm.controls['logo'] = new FormControl(this.profileImg);
    const formObj = this.userForm.getRawValue();
    if (formObj.address.city.name === '' || formObj.address.city.name === null) {
      this.toastrService.error(Dictionary.CITY_REQ);
    }
    if (formObj.address.zip === '' || formObj.address.zip === null) {
      this.toastrService.error(Dictionary.ZIP_REQ);
    }

    // if (formObj.phone === '' || formObj.phone === null || formObj.phone === undefined) {
    //   this.toastrService.error(Dictionary.PHONE_REQ);
    // }
    console.log('specialitiesssss', this.selectedSpecialities);
    if (this.mode === 'add') {
      this.createOrganisation(formObj);
    } else if (this.mode === 'edit') {
      this.updateOrganisation(formObj);
    }
  }

  // togglePanel(value) {
  //   console.log(value);
  //   this.addNewPanelAcitve = value;
  // }
  createOrganisation(formObj) {
    this.userForm.controls['logo'] = new FormControl(this.profileImg);
    // const formObj = this.userForm.value;
    // const userObj = JSON.stringify(formObj);
    // console.log('userobject', userObj);
    console.log(JSON.stringify(formObj));
    if (!this.domainExists) {
      this.restapiService.invoke<ClinicDetails>(APIEndPoint.CREATE_CLINIC, null, formObj).subscribe(resp => {
        this.clinic = resp;
        this.clinicId = resp.id;
        this.toastrService.success(Dictionary.SUCCESSFUL_REGISTRATION({ EntityName: this.clinic.name }));
        this.authService.refreshAccessToken().takeUntil(this.unsubscribe).subscribe(token => {
          if ((formObj.clinicFacilityType === 'SINGLE') && (this.authService.isUserDoctor())) {
            console.log('admin doctor', this.doctorId);
            this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/doctors/' + this.doctorId + '/edit']);
          }
          if (formObj.clinicFacilityType === 'MULTIPLE') {
            this.router.navigate([`clinic-view/${this.clinicId}/facility-registration`]);
          } else if ((formObj.clinicFacilityType === 'SINGLE') && !(this.authService.isUserDoctor())) {
            this.router.navigate([`clinic-view/${this.clinicId}/doctor-registration`]);
          }
        });
        this.clinicId = resp.id;
      }, error => {
        this.toastrService.error(Dictionary.ERROR_MSG);
      });
    } else {
      this.showError();
    }

  }

  editOrganisation() {
    this.router.navigate(['/clinics/' + this.clinicId + '/edit']);
  }
  updateOrganisation(formObj) {
    this.restapiService
      .invoke<ClinicDetails>(APIEndPoint.UPDATE_CLINIC,
        { clinicId: this.clinicId }, formObj).subscribe(clinic => {
          console.log('successfully updated', clinic);
          this.userForm.get('domainName').enable();
          this.toastrService.success(Dictionary.SUCCESSFUL_UPDATION({ EntityName: clinic.name }));
          this.router.navigate(['manage-view/clinics/' + this.clinicId + '/facilities']);
        }, error => {
          this.toastrService.error(Dictionary.ERROR_MSG);
        });
  }

  showError() {
    this.toastrService.error(Dictionary.DOMAIN_EXIST);
  }


  getDomain(domain: string): Observable<boolean> {
    return this.uniqueNameService.getDomainOrLoginName({ 'domain': domain }, this.apiDM);
    // return this.restapiService.invoke<any>(APIEndPoint.GET_DOMAIN, null, null, {
    //   'domain': domain
    // }).map(resp => true).catch(err => Observable.of(false));
  }

  createForm() {
    this.userForm = this.formBuilder.group({
      logo: [null],
      registrationId: ['', Validators.compose([Validators.required])],
      name: ['', Validators.compose([Validators.required, Validators.minLength(2)])],
      email: ['', Validators.compose([Validators.required, Validators.pattern('[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}')])],
      portalURL: [''],
      specialities: this.formBuilder.array([this.formBuilder.group({
        id: '',
        name: '',
        description: ''
      })]),
      domainName: ['', Validators.compose([Validators.required, Validators.minLength(5)])], // {value: '', disabled: this.isDomainDisabled}
      isDisplayed: [true],
      gstin: [''],
      description: ['', Validators.compose([Validators.minLength(10), Validators.required, Validators.maxLength(50)])],
      clinicFacilityType: ['SINGLE'],
      phone: [null, ([Validators.pattern('^[1-9][0-9]{9}$')])],
      landLine: [null, ([Validators.pattern(/^[0-9]\d{2,4}-\d{6,8}$/)])],
      // ([Validators.pattern, ('\d{5}([- ]*)\d{6}')])
      address: this.formBuilder.group({
        address1: ['', Validators.required],
        address2: [''],
        city: [{
          id: '',
          name: ''
        }, Validators.required],
        country: [{id: 1}],
        // addressType: ['', Validators.compose([Validators.required])],
        zip: ['', Validators.compose([Validators.required, Validators.pattern('^[1-9][0-9]{5}$')])]
      })
    });
    this.userForm.controls['domainName'].valueChanges.debounceTime(400)
      .switchMap(term => this.getDomain(term)).subscribe(resp => { this.domainExists = resp; }, err => { this.domainExists = false; });
  }

  onBack() {
    this.location.back();
  }
  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
