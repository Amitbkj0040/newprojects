import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { Facility } from 'app/core/models/app.models';
import { ClinicDetails } from 'app/core/models/clinicDetails';
import { RestapiService } from 'app/core/services/restapi.service';
import { Router, ActivatedRoute } from '@angular/router';
import { restapiUrl } from 'app/core/services/rest-api-variable';
import { APIEndPoint, APIDef } from 'app/core/models/ApiEndPoint';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { City } from 'app/core/models/city';
import { tap } from 'rxjs/operators';
import { Speciality } from 'app/core/models/speciality';
import { Subject } from 'rxjs/Subject';
import { AuthService } from 'app/core/auth/auth.service';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { ToastrService } from 'ngx-toastr';
import { Dictionary } from 'app/core/models/dictionary';
import { Country, DEFAULT_COUNTRY } from 'app/core/models/country';
import { PhoneValidator } from 'app/core/validators/phone.validator';

@Component({
  selector: 'app-facility-registration',
  templateUrl: './facility-registration.component.html',
  styleUrls: ['./facility-registration.component.css']
})
export class FacilityRegistrationComponent implements OnInit, OnDestroy {
  clinicId: any;
  public doctorId: string;
  apiSP: APIDef = APIEndPoint.GET_SPECIALITIES;
  // public specialities$: Observable<Speciality>;
  private unsubscribe = new Subject<void>();
  facilityForm: FormGroup;
  mode = 'add';
  temp = 'register';
  actionMode: string;
  selectedCity: City;
  myevent: any;
  public facilityGetById: any;
  cities = [{ id: 1, name: 'city1' }];
  selectedSpecialities: Object[] = [];
  public cities$: Observable<City>;
  public facilityId: string;
  public facility$: Observable<Facility>;
  countries$: Observable<Country>;
  selectedCountry: Country = DEFAULT_COUNTRY;
  cityApiEndPoint = APIEndPoint.GET_CITIES;
  AUTH_TOKEN: any = '';
  isZipCodeValid = true;
  isZipCodeRequired = true;
  isAddressFilled = true;
  isAddressValid: boolean;

  constructor(
    public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    public toastrService: ToastrService,
    private formBuilder: FormBuilder,
    public authService: AuthService,
    public jwtHelper: JwtHelperService,
    public confirmationPopup: ConfirmationPopupService
    ) {

  }

  getToken() {
    return this.jwtHelper.decodeToken(this.authService.getAuthToken());
  }

  public createFacility(facilityDetails) {
    this.restapiservice
      .invoke<Facility>(
        APIEndPoint.CREATE_FACILITY,
        { clinicId: this.clinicId }, facilityDetails).subscribe(facility => {
          console.log(facility);
          console.log(facility.id);
          const facilityName = facility.name;
          this.toastrService.success(Dictionary.SUCCESSFUL_REGISTRATION({ EntityName: facilityName }));
          if (this.authService.isUserDoctor()) {
            this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/doctors/' + this.doctorId + '/edit']);
          } else {
            this.router.navigate([`clinic-view/${this.clinicId}/doctor-registration`]);
          }
        }, error => {
          this.toastrService.error(Dictionary.ERROR_MSG);
        });
  }



  public saveFacility() {
    const facilityDetails = this.facilityForm.getRawValue();
    if (facilityDetails.address.city.name === '' || facilityDetails.address.city.name === null) {
      this.toastrService.error(Dictionary.CITY_REQ);
    }
    if (facilityDetails.specialities.length === 0) {
      this.toastrService.error(Dictionary.SPECIALITY_REQ);
    }
    if (facilityDetails.address.zip === '' || facilityDetails.address.zip === null) {
      this.toastrService.error(Dictionary.ZIP_REQ);
    }
    if (!this.AUTH_TOKEN.isVirtualClinic && this.isAddressFilled) {
      this.facilityForm.patchValue({ address: { country: this.selectedCountry } });
      facilityDetails.address.country = this.selectedCountry;
    }
    this.createFacility(facilityDetails);
    this.facilityForm.controls['specialities'] = new FormControl(this.selectedSpecialities);
    // this.facilityForm.reset();
  }

  // formOnChnages() {
  //   this.facilityForm.get('address').valueChanges.subscribe(val => {
  //     if (val.country && val.country.countryIATACode) {
  //       if (this.postCodeValidatorService.isZipCodeRequired(val.country.countryIATACode)) {
  //         this.isZipCodeRequired = true;
  //         this.isZipCodeValid = this.validateZipCode(val.country.countryIATACode, val.zip);
  //       } else {
  //         this.isZipCodeRequired = false;
  //         this.isZipCodeValid = true;
  //       }
  //     }
  //     if (this.utilityservice.areAllFieldsNull(val.city)) {
  //       val.city = null;
  //     }
  //     if (this.utilityservice.areAllFieldsNull(val.country)) {
  //       val.country = null;
  //     }

  //     const ADDRESS = { ...val };
  //     delete ADDRESS.id;
  //     if (this.utilityservice.areAllFieldsNull(ADDRESS)) {
  //       this.isAddressFilled = false;
  //     } else {
  //       this.isAddressFilled = true;
  //     }
  //   });
  // }

  ngOnInit() {
    this.AUTH_TOKEN = this.jwtHelper.decodeToken(this.authService.getAuthToken());
    if (!this.AUTH_TOKEN.isVirtualClinic) {
      this.selectedCountry = DEFAULT_COUNTRY;
    }
    this.doctorId = this.authService.getStaffId();
    this.countries$ = this.restapiservice.invoke<Country>(APIEndPoint.GET_COUNTRIES).map((res: any) => {
      // const countryCodeList = res.map(elem => elem.countryCode);
      res.unshift({ id: null, name: 'Select Country', countryCode: null });
      return res;
    });
    this.createForm();
    // this.formOnChnages();
    this.activatedRoute.params.takeUntil(this.unsubscribe).subscribe(response => {
      this.clinicId = response['clinicId'];
    });

  }

  onCountryChange(country) {
    this.selectedCountry = country && country.id ? country : null;
    if (country) {
      this.updatePhoneValidation(country.countryIATACode);
    }
  }

  updatePhoneValidation(countryIATACode) {
    const phoneControl = this.facilityForm.get('phone');
    phoneControl.setValidators([Validators.required, PhoneValidator(countryIATACode)]);
    phoneControl.setValue(phoneControl.value);

    const alternatePhoneControl = this.facilityForm.get('alternatephone');
    alternatePhoneControl.setValidators([PhoneValidator(countryIATACode)]);
    alternatePhoneControl.setValue(alternatePhoneControl.value);
  }


  @HostListener('window:beforeunload', ['$event'])
  public reloadFacility($event) {
    let hasChanges = false;
    if (this.facilityForm.dirty) {
      console.log('dirtyyyy');
      hasChanges = true;
    }
    if (hasChanges) {
      $event.returnValue = Dictionary.LEAVE_PAGE_ALERT;
    }
  }

  // cancel() {
  //   this.confirmationPopup.toggleConfirmationPopup({showPopup: true, message: Dictionary.CANCEL_CONFIRMATION});
  //   this.confirmationPopup.userAction.takeUntil(this.unsubscribe).subscribe(data => {
  //     if (data) {
  //       this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/facilities']);
  //       this.confirmationPopup.getConfirmationPopup(null);
  //     }
  //   });
  // }


  selectCity(data) {
    console.log(data);
  }

  createForm() {
    this.facilityForm = this.formBuilder.group({
      name: ['', Validators.compose([Validators.minLength(2), Validators.required])],
      specialities: this.formBuilder.array([this.formBuilder.group({
        id: '',
        name: '',
        description: ''
      })]),
      phone: ['', Validators.compose([Validators.required, PhoneValidator(this.selectedCountry.countryIATACode)])],
      alternatephone: [null, Validators.compose([PhoneValidator(this.selectedCountry.countryIATACode)])],
      description: ['', Validators.compose([Validators.minLength(10), Validators.maxLength(50), Validators.required])],
      email: [null, Validators.compose([Validators.pattern('[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}')])],
      document: this.formBuilder.array([]),
      address: this.formBuilder.group({
        id: '',
        address1: ['', Validators.required],
        address2: [null],
        country: [{
          id: null,
          name: null,
          countryIATACode: null,
          countryI: null,
          pinCodeLength: null
        }],
        city: [{
          id: '',
          name: ''
        }, Validators.required],
        zip: [null],
        locality: [null],
      })
    });
  }

  setAlternatePhoneNumber() {
    this.facilityForm.controls['alternatephone'].setValue(this.facilityForm.controls['alternatephone'].value === '' ? null :
     this.facilityForm.controls['alternatephone'].value);
  }

  setEmail() {
    this.facilityForm.controls['email'].setValue(this.facilityForm.controls['email'].value === '' ? null :
     this.facilityForm.controls['email'].value);
  }

  get address() {
    return this.facilityForm.controls['address'] as FormGroup;
  }


  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }


}
