import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { DoctorRegistrationComponent } from 'app/modules/registration/doctor-registration/doctor-registration.component';
import { ClinicRegisterationComponent } from 'app/modules/registration/clinic-registeration/clinic-registeration.component';
import { FacilityRegistrationComponent } from 'app/modules/registration/facility-registration/facility-registration.component';
import { RegistrationRoutingModule } from 'app/modules/registration/registration.routes';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    RegistrationRoutingModule
  ],
  declarations: [
    ClinicRegisterationComponent,
    FacilityRegistrationComponent,
    DoctorRegistrationComponent,
  ]
})
export class RegistrationModule { }
