import { Component, OnInit, OnDestroy, HostListener, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RestapiService } from 'app/core/services/restapi.service';
import { FormGroup, FormBuilder } from '@angular/forms';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Observable } from 'rxjs/Observable';
import { Doctor, AppointmentSlotForDates, Appointment, HTTPStaffSchedule, StaffSchedule, KeyType } from 'app/core/models/app.models';
import { AppointmentStatus, AppointmentType } from 'app/core/models/app.models';
import { Subject } from 'rxjs/Subject';
import { Patient } from 'app/core/models/Patient';
import { ParamSelectionService } from 'app/core/services/param-selection.service';
import { ToastrService } from 'ngx-toastr';
import { Dictionary } from 'app/core/models/dictionary';
import { AuthService } from 'app/core/auth/auth.service';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { Mode } from 'app/core/models/ActionMode.enum';

// import { AppointmentDateSlot } from '../../../model/app.models';

declare var $: any;

@Component({
  selector: 'app-appointment',
  templateUrl: './appointment.component.html',
  styleUrls: ['./appointment.component.css'],
  encapsulation: ViewEncapsulation.None,
})
export class AppointmentComponent implements OnInit, OnDestroy {
  AppointmentType = AppointmentType;
  appointmentform: FormGroup;
  totalAppointment: Appointment[];
  selectedColIndex: number;
  firstName: any;
  lastName: any;
  public mode = Mode.ADD;
  next = 1;
  nextResponsive = 0;
  public isResponsive = false;
  public IsSearchPatient: boolean;
  public pageNumber = 0;
  public pageSize = 10;
  public search = '';
  public sort = '';
  public sortOn = '';
  public appointment$: Observable<AppointmentSlotForDates>;
  public allAppointments$: Observable<Appointment[]>;
  public futureAppointments$: Observable<AppointmentSlotForDates>;
  public clinicId: string;
  public facilityId: string;
  public doctorId: string;
  public patientId: string;
  public staffId: string;
  public seletedPatientDetails: any;
  public patientAppointment: Appointment;
  public appointmentId: string;
  public docSearchTxt: string;
  public searchText = '';
  public docSearchableFields: ['firstName', 'lastName'];
  public totalConfirmAppointment: number;
  public totalSlotAppointmentsToday: any;
  public totalSlotAppointmentsFuture: any;
  public totalAppointments: any;
  public totalPatients: any;
  patients$: Observable<Patient[]>;
  private unsubscribe = new Subject<void>();
  firstname: string;
  lastname: string;
  selectedSlot: string;
  selectedDate: string;
  public sub: Observable<string>;
  public doctors$: Observable<Doctor[]>;
  public staffSchedule$: Observable<StaffSchedule[]>;
  public selectedDoc: Doctor;
  public hasPrev = false;
  public selectedIndex: number;
  public selectedPatientIndex = 0;
  public resultLength: Patient[] = [];
  physicalExams = {};
  public isRequesting = false;
  public patientWalkin: boolean;
  public patientOnline: boolean;
  public fromRoute: string;
  public fromAppointment = false;
  public _doctorList = new Subject<Doctor[]>();
  public doctorList$ = this._doctorList.asObservable();
  public doctorList: Doctor[] = [];
  public patientPhone: string;
  public patientFN: string;
  public patientLN: string;
  public patientEmail: string;
  public onlineId: string;
  public isOnline = false;
  public onlineAppoinment: Appointment;
  public selectedAppointment;
  public appointmentType: string;
  public from: string;
  public isMobileView: boolean;
  public update_appointment = false;
  public isToday = false;
  public showBookAppointmentDialog = false;
  public appointmentDialogMode = 'ADD';
  public futureDate;
  updatedPhysicalExamDetails: any[] = [];
  activePhysicalExamDetails: any[] = [];
  activeAppointment: Appointment;
  doctorDefaultPhysicalExam: any;
  doctorMetaVitals: any;
  showPatientEditBtn = true;
  isVitalButtonDisable = true;

  constructor(
    public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    private gmParams: ParamSelectionService,
    public authService: AuthService,
    public toastrService: ToastrService,
    public confirmationPopup: ConfirmationPopupService
  ) {
    this.detectMobileView();
  }

  @HostListener('window:resize', ['$event']) onresize(event) {
    this.detectMobileView();
  }

  detectMobileView() {
    if (window.innerWidth < 768) {
      this.isMobileView = true;
    } else {
      this.isMobileView = false;
    }
  }

  bookAppointment(slot: string, date: string, totalAppointment: Appointment[], patientPhone: string, patientFN: string,
    patientLN: string, onlineId: string, patientEmail: string, appointmentType: string, selectedColIndex: number, appointment, isToday: boolean) {
    // this.IsSearchPatient = true;
    this.appointmentDialogMode = 'ADD';
    this.selectedSlot = slot;
    this.selectedDate = date;
    this.totalAppointment = totalAppointment;
    this.selectedColIndex = selectedColIndex;
    this.patientPhone = patientPhone;
    this.patientFN = patientFN;
    this.patientLN = patientLN;
    this.patientEmail = patientEmail;
    this.selectedAppointment = { ...appointment, date, dateUpdated: false };
    this.onlineId = onlineId;
    this.isToday = isToday;
    this.showBookAppointmentDialog = true;
    this.appointmentType = appointmentType;
    if (this.appointmentType === AppointmentType.ONLINE) {
      this.searchPatient(this.patientPhone);
    } else {
      this.searchPatient('');
    }
  }

  editVirtualAppointment(appointment, date, isToday, index) {
    if (appointment.appointment.appointmentStatus === AppointmentStatus.CONFIRMED) {
      this.selectedAppointment = appointment;
      this.appointmentDialogMode = 'EDIT';
      this.selectedDate = date;
      this.showBookAppointmentDialog = true;
      this.isToday = isToday;
      this.selectedColIndex = index;
    }
  }

  hideAppointmentDialog(event) {
    this.showBookAppointmentDialog = event;
    this.appointmentDialogMode = 'ADD';
    this.patientWalkin = false;
    this.appointment$ = this.getAppointments('today', 'today');
    this.futureAppointments$ = this.getAppointments('today+' + this.next, 'today+' + (this.next + 1));
  }

  onCreateAppointment(event) {
    this.showBookAppointmentDialog = event;
    this.appointmentDialogMode = 'ADD';
    this.patientWalkin = false;
    this.appointment$ = this.getAppointments('today', 'today');
    this.futureAppointments$ = this.getAppointments('today+' + this.next, 'today+' + (this.next + 1));
  }

  compareTime(firstTime: string, secondTime: string) {
    const firstHrMin: string[] = firstTime.split(':');
    const secondHrMin: string[] = secondTime.split(':');
    return parseInt(firstHrMin[0], 10) * 60 + parseInt(firstHrMin[1], 10) -
      parseInt(secondHrMin[0], 10) * 60 - parseInt(secondHrMin[1], 10);
  }

  getAppointments(startDate: string, endDate: string): Observable<AppointmentSlotForDates> {
    this.isRequesting = true;
    return this.restapiservice
      .invoke<AppointmentSlotForDates>(APIEndPoint.GET_SLOTS_APPOINTMENTS,
        { clinicId: this.clinicId, facilityId: this.facilityId, doctorId: this.selectedDoc.id },
        null,
        { startDate: startDate, endDate: endDate }).map(resp => {
          this.isRequesting = false;
          console.log('helloresp', resp);
          return resp;
        });
  }

  // getAppointmentById(appointmentId) {
  //   this.restapiservice
  //     .invoke<any>(APIEndPoint.GET_APPOINTMENT_BY_ID,
  //       { clinicId: this.clinicId, facilityId: this.facilityId, doctorId: this.doctorId, appointmentId: appointmentId },
  //       null).subscribe(resp => {
  //         this.editAppointment = resp;
  //         console.log('thisedit', this.editAppointment);
  //         return this.editAppointment;
  //       });
  // }

  getAllAppointments(): Observable<Appointment[]> {
    return this.restapiservice.invoke<Appointment[]>(APIEndPoint.GET_APPOINTMENTS,
      { clinicId: this.clinicId, facilityId: this.facilityId, doctorId: this.doctorId },
      null,
      { startDate: 'today', endDate: 'today' }).map(response => {
        return response;
      });
  }

  getSchedules(staffId: string): Observable<StaffSchedule[]> {
    return this.restapiservice
      .invoke<HTTPStaffSchedule[]>(APIEndPoint.GET_STAFF_SCHEDULES,
        { clinicId: this.authService.getClinicId(), facilityId: this.facilityId, staffId: staffId }).map(httpStaffSchedules => {
          const staffSchedules: StaffSchedule[] = [];
          httpStaffSchedules.forEach(httpStaffSchedule => {
            staffSchedules.push(StaffSchedule.fromHTTPStaffSchedule(httpStaffSchedule));
          });
          return staffSchedules;
        });
  }

  getPatient(): Observable<Patient[]> {
    return this.restapiservice
      .invoke<Patient[]>(APIEndPoint.GET_PATIENTS,
        { clinicId: this.clinicId });
  }

  nextAppointments() {
    if (!this.isResponsive) {
      this.next += 2;
      this.futureAppointments$ = this.getAppointments('today+' + this.next, 'today+' + (this.next + 1));
    } else {
      this.nextResponsive += 1;
      console.log('next ', this.nextResponsive);
      this.appointment$ = this.getAppointments('today+' + this.nextResponsive, 'today+' + this.nextResponsive);
    }
  }

  prevAppointments() {
    if (!this.isResponsive) {
      if (this.next > 2) {
        this.next -= 2;
        this.futureAppointments$ = this.getAppointments('today+' + this.next, 'today+' + (this.next + 1));
      }
    } else {
      console.log('prev', this.nextResponsive);
      if (this.nextResponsive > 0) {
        this.nextResponsive -= 1;
        this.appointment$ = this.getAppointments('today+' + this.nextResponsive, 'today+' + (this.nextResponsive));
      }
    }
  }

  getDoctors(pageNumber, pageSize) {
    this.restapiservice
      .invoke<Doctor[]>(APIEndPoint.GET_DOCTORS,
        { clinicId: this.clinicId, facilityId: this.facilityId }, null,
        {
          'pageNumber': pageNumber,
          'pageSize': pageSize,
          'search': this.search,
          'sort': this.sort,
          'sortOn': this.sortOn
        }).subscribe((doctorRes: any) => {
          this.isRequesting = false;
          doctorRes.forEach(element => {
            this.doctorList.push(element);
          });
          this._doctorList.next(this.doctorList);
        });
  }

  getDoctorById(doctorId: string): Observable<Doctor> {
    return this.restapiservice.invoke<Doctor>(APIEndPoint.GET_DOCTOR_BY_ID, { clinicId: this.clinicId, doctorId: doctorId });
  }

  isUserAdmin() {
    return this.authService.isUserAdmin();
  }

  isUserSupportStaff() {
    return this.authService.isUserSupportStaff();
  }

  public openAppointmentUpdateModal(appointmentSlot, isToday, index, futureDate) {
    this.update_appointment = true;
    this.selectedColIndex = index;
    this.isToday = isToday;
    this.futureDate = futureDate;
    this.seletedPatientDetails = appointmentSlot.appointment;
    this.appointmentId = appointmentSlot.appointment.id;
  }

  onHideAppointmentModal(event) {
    this.update_appointment = false;
    this.showPatientEditBtn = true;
    $('.modal-backdrop').addClass('hide');
    if (event) {
      this.selectedAppointment = { ...this.selectedAppointment, date: this.selectedDate, dateUpdated: true };
    }
  }

  deleteAppointment(id, isToday) {
    this.confirmationPopup.confirm({ message: Dictionary.DELETE_CONFIRMATION }).subscribe(data => {
      if (data) {
        this.restapiservice.invoke<any>(APIEndPoint.DELETE_APPOINTMENT_BY_ID, {
          clinicId: this.clinicId, facilityId: this.facilityId, doctorId: this.doctorId, appointmentId: id
        }).subscribe(respone => {
          if (this.activeAppointment && (id === this.activeAppointment.id)) {
            this.activeAppointment = null;
          }
          if (isToday) {
            this.appointment$ = this.getAppointments('today', 'today');
          } else {
            this.futureAppointments$ = this.getAppointments('today+' + this.next, 'today+' + (this.next + 1));
          }
        }, err => {
          console.log('not success');
        });
      }
    });
  }

  addWalkinPatient() {
    console.log('ADD WAlkin', this.patientPhone);
    if (this.patientPhone === undefined || this.patientPhone) {
      this.patientPhone = null;
    }
    this.showBookAppointmentDialog = true;
    this.patientWalkin = true;
    this.fromAppointment = true;
    // this.searchPatient('');
  }

  addPatient() {
    if (this.patientWalkin && !(this.fromAppointment)) {
      this.router.navigate(['./clinic-view/clinics/' + this.clinicId + '/patients/add-walkin-patient'],
        {
          queryParams: {
            fromRoute: 'encounter',
            doctorId: this.doctorId,
            facilityId: this.facilityId
          }
        });
    } else if (this.patientWalkin && this.fromAppointment) {
      this.router.navigate(['./clinic-view/clinics/' + this.clinicId + '/patients/add-walkin-patient'],
        {
          queryParams: {
            fromRoute: 'appointment',
            doctorId: this.doctorId,
            facilityId: this.facilityId
          }
        });

    } else {
      this.router.navigate([`./clinic-view/clinics/${this.clinicId}/patients/add`],
        {
          queryParams: {
            next: this.next,
            slot: this.selectedSlot,
            date: this.selectedDate,
            doctorId: this.doctorId,
            facilityId: this.facilityId,
            patientFN: this.patientFN,
            patientLN: this.patientLN,
            onlineId: this.onlineId,
            patientPhone: this.patientPhone,
            patientEmail: this.patientEmail,
            appointmentType: this.appointmentType,
            from: this.from
          }
        }
      );
    }
  }

  public gotoDoctorScheduleList() {
    this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId +
      '/staffs/' + this.selectedDoc.id + '/schedules']);
  }

  public gotoDoctorScheduleAdd() {
    this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId +
      '/staffs/' + this.selectedDoc.id + '/schedules/add']);
  }

  onScrollUp() {
    console.log('scroll up', this.pageNumber++);
    this.getDoctors(this.pageNumber, this.pageSize);
  }

  checkForDoctor(slots, index) {
    let result = true;
    slots.some((element) => {
      if (element[index] !== null) {
        result = false;
        return true;
      }
    });
    return result;
  }

  refreshAppointment(updatedSlot) {
    if (updatedSlot) {
      this.futureDate = null;
      this.appointment$ = this.getAppointments('today', 'today');
      this.selectedAppointment = { ...this.selectedAppointment, slot: updatedSlot };
      this.futureAppointments$ = this.getAppointments('today+' + this.next, 'today+' + (this.next + 1));
    }

  }

  setActiveAppointmentDetails(appointment: Appointment) {
    this.isVitalButtonDisable = true;
    if (appointment.appointmentType !== AppointmentType.ONLINE) {
      this.activeAppointment = appointment;
      this.restapiservice.invoke(APIEndPoint.GET_PHYSICALEXAM_BY_APPOINTMENT_ID,
        { clinicId: this.clinicId, appointmentId: appointment.id }).takeUntil(this.unsubscribe)
        .subscribe((physicalExam: any) => {
          this.activeAppointment = { ...this.activeAppointment, physicalExam };
          this.setPhysicalExam(physicalExam);
        });
    } else {
      this.activeAppointment = null;
    }
  }

  setPhysicalExam(physicalExams) {
    if (physicalExams && physicalExams.vitals && physicalExams.vitals.length > 0) {
      this.activePhysicalExamDetails = this.createMetaVitalsList(physicalExams.vitals, 'edit');
    } else if (this.doctorDefaultPhysicalExam && this.doctorDefaultPhysicalExam.length > 0) {
      this.activePhysicalExamDetails = this.createMetaVitalsList(this.doctorDefaultPhysicalExam, 'add');
    }
  }

  getDoctorPhysicalExam() {
    this.activeAppointment = null;
    this.restapiservice
      .invoke<Doctor>(APIEndPoint.GET_DOCTOR_BY_ID, { clinicId: this.clinicId, doctorId: this.doctorId })
      .subscribe((doctor: any) => {
        if (doctor.metaVitals && doctor.metaVitals.length > 0) {
          this.activePhysicalExamDetails = this.createMetaVitalsList(doctor.metaVitals, 'add');
          this.doctorDefaultPhysicalExam = doctor.metaVitals;
          // this.doctorPhysicalExams = doctor.metaVitals.map(metaVital =>
          //   ({ observedValue: null, metaVitalUnit: { id: metaVital.id }, metaVital }));
        }
      });
  }

  createMetaVitalsList(metaVitals: any, mode?: string) {
    const examinationTime = new Date();
    let results: any;
    if (mode !== 'edit') {
      results = metaVitals.map((elem => {
        return {
          metaVital: elem, observedValue: null,
          metaVitalUnit: { id: elem.units[0].id },
          examinationTime: examinationTime,
          unit: elem.units[0]
        };
      }));
    } else {
      results = metaVitals.map((elem => {
        return {
          metaVital: elem.metaVital,
          observedValue: elem.observedValue,
          metaVitalUnit: elem.metaVitalUnit,
          examinationTime: examinationTime,
          id: elem.id,
          unit: elem.metaVital.units.find((unit) => unit.id === elem.metaVitalUnit.id)
        };
      }));
    }
    return results;
  }

  updateVitals(vitals) {
    this.isVitalButtonDisable = false;
    this.updatedPhysicalExamDetails = vitals;
  }

  updateAppointmentVitals() {
    let vitals;
    if (this.activeAppointment.physicalExam) {
      vitals = { ...this.activeAppointment.physicalExam, vitals: this.updatedPhysicalExamDetails };
    } else {
      vitals = { vitals: this.updatedPhysicalExamDetails };
    }
    this.restapiservice.invoke(APIEndPoint.UPDATE_PHYSICALEXAM_BY_APPOINTMENT_ID,
      { clinicId: this.clinicId, appointmentId: this.activeAppointment.id }, vitals)
      .takeUntil(this.unsubscribe)
      .subscribe((updatedMetalVitals: any) => {
        this.isVitalButtonDisable = true;
        this.toastrService.success('Appointment Physical Exam updated');
        this.appointment$ = this.getAppointments('today', 'today');
        this.activeAppointment = { ...this.activeAppointment, physicalExam: updatedMetalVitals };
        this.updatedPhysicalExamDetails = updatedMetalVitals.vitals;
        this.setPhysicalExam(updatedMetalVitals);
        // this.getAllAppointments().takeUntil(this.unsubscribe).subscribe(appointmentRes => {
        //   this.activeAppointment = appointmentRes.find(appointment => appointment.id === this.activeAppointment.id);


        //   console.log('hello this is the updated', this.activeAppointment);
        // });
      }, error => {
        this.toastrService.error('Unable to udpate phyiscal Exam');
      });
  }

  ngOnInit() {
    if (window.innerWidth < 768) {
      this.isResponsive = true;
    } else {
      this.isResponsive = false;
    }
    Observable.combineLatest(this.activatedRoute.parent.params,
      this.activatedRoute.params,
      this.activatedRoute.queryParams).takeUntil(this.unsubscribe).subscribe(response => {
        this.doctorList = [];
        this.clinicId = response[0]['clinicId'];
        this.facilityId = response[0]['facilityId'];
        this.doctorId = response[1]['doctorId'];
        this.mode = response[1]['action'];
        this.selectedDate = response[2]['date'];
        this.selectedSlot = response[2]['slot'];
        if (response[2]['next']) { this.next = response[2]['next']; }
        this.patientId = response[2]['patientId'];
        this.patientWalkin = response[2]['patientWalkin'];
        this.fromRoute = response[2]['fromRoute'];
        this.patientOnline = response[2]['patientOnline'];
        this.patientFN = response[2]['patientFN'];
        this.patientLN = response[2]['patientLN'];
        this.patientPhone = response[2]['patientPhone'];
        this.patientEmail = response[2]['patientEmail'];
        this.onlineId = response[2]['onlineId'];
        this.appointmentType = response[2]['appointmentType'];
        this.from = response[2]['from'];
        this.staffId = this.doctorId;
        this.staffSchedule$ = this.getSchedules(this.staffId);
        if (this.patientOnline) {
          this.searchPatient(this.patientPhone);
        } else if (this.patientWalkin) {
          if (this.patientPhone === undefined || this.patientPhone) {
            this.patientPhone = null;
          }
          this.searchPatient('');
        }
        if (this.authService.isUserDoctor() && !this.authService.isUserAdmin()) {
          this.getDoctorById(this.authService.getStaffId()).takeUntil(this.unsubscribe).subscribe(doctor => {
            this.selectedDoc = doctor;
            this.gmParams.setParam('doctor', this.selectedDoc);
            this.initAppointments();
          });
        } else {
          this.doctors$ = this.doctorList$;
          this.getDoctors(this.pageNumber, this.pageSize);
          this.restapiservice
            .invoke<Doctor[]>(APIEndPoint.GET_DOCTORS,
              { clinicId: this.clinicId, facilityId: this.facilityId }, null,
              {
                'pageNumber': this.pageNumber,
                'pageSize': this.pageSize,
                'search': this.search,
                'sort': this.sort,
                'sortOn': this.sortOn
              }).subscribe(doctors => {
                console.log('doctor listttttt', doctors);
                if (doctors.length > 0) {
                  if (this.doctorId) {
                    doctors.some(doctor => {
                      // tslint:disable-next-line:triple-equals
                      if (doctor.id == this.doctorId) {
                        this.selectedDoc = doctor;
                        return true;
                      }
                    });
                    if (!this.selectedDoc) {
                      this.selectedDoc = doctors[0];
                      this.doctorId = this.selectedDoc.id;
                    }
                  } else {
                    this.selectedDoc = doctors[0];
                  }
                  this.gmParams.setParam('doctor', this.selectedDoc);
                  this.initAppointments();
                  // if (this.mode === 'add') {
                  //   this.createAppointment(this.patientId);
                  // } else {
                  //   this.appointment$ = this.getAppointments('today', 'today');
                  //   this.futureAppointments$ = this.getAppointments('today+1', 'today+2');
                  // }
                }
              });
        }
        // this.doctors$.takeUntil(this.unsubscribe).subscribe();
      });
    this.IsSearchPatient = false;
    Observable.combineLatest(
      this.getAllAppointments(),
      this.getPatient(),
    ).takeUntil(this.unsubscribe).subscribe(responses => {
      this.totalAppointments = responses[0].length;
      this.totalConfirmAppointment = responses[0].filter(element => element.appointmentStatus === AppointmentStatus.CONFIRMED).length;
      this.totalPatients = responses[1];
    });
    // if (this.patientPhone === 'undefined') {
    //   this.patientPhone = '';
    // }
    // this.getAllAppointments();
    // // this.staffSchedule$ = this.getSchedules();

    // this.getPatient().takeUntil(this.unsubscribe).subscribe(response => {
    //   console.log('dffdfdfdfdfdf', response);
    //   this.resultLength = response;
    // });
  }

  initAppointments() {
    this.getDoctorPhysicalExam();
    try {
      this.appointment$ = this.getAppointments('today', 'today').map(resp => {
        this.totalSlotAppointmentsToday = resp.slotAppointments;
        console.log('today Appointments', resp);
        return resp;
      });
    } catch { }
    this.futureAppointments$ = this.getAppointments('today+1', 'today+2').map(res => {
      this.totalSlotAppointmentsFuture = res.slotAppointments;
      console.log('future Appointments', this.totalSlotAppointmentsFuture);
      return res;
    });
  }

  searchPatient(searchTxt: string) {
    this.patients$ = this.restapiservice
      .invoke<Patient[]>(APIEndPoint.GET_PATIENTS,
        { clinicId: this.clinicId, facilityId: this.facilityId }, null, { pageNumber: 0, pageSize: 100, search: searchTxt })
      .map(resp => {
        this.resultLength = resp;
        return resp;
      });
  }

  public closeSearchModal() {
    this.IsSearchPatient = false;
    this.patientWalkin = false;
    this.patientOnline = false;
    this.searchPatient('');
  }

  closeModalWithEscape(event) {
    if (event.keyCode === KeyType.KEY_ESCAPE) {
      this.IsSearchPatient = false;
      this.patientWalkin = false;
      this.searchPatient('');
    }
  }

  public gotoUnavailibiltySchedule() {
    // tslint:disable-next-line:max-line-length
    this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId + '/staffs/' + this.staffId + '/unavailability/']);
  }

  public attributeForSlot(appointment) {
    if (appointment) {
      if (appointment.appointmentStatus === AppointmentStatus.CLOSED) {
        return 'Encounter is done';
      } else if (appointment.appointmentStatus === AppointmentStatus.INPROGRESS) {
        return 'Encounter is in progress';
      }
      if (appointment.facility.id.toString() !== this.facilityId) {
        return `Slot is already booked for ${appointment.facility.name}`;
      }
    }
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
