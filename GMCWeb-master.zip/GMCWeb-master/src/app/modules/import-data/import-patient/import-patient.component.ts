import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { UploadFileService } from 'app/core/services/upload-file.service';
import { HttpEventType, HttpResponse } from '@angular/common/http';
import { Location } from '@angular/common';
import { ToastrService } from 'ngx-toastr';


@Component({
  selector: 'app-import-patient',
  templateUrl: './import-patient.component.html',
  styleUrls: ['./import-patient.component.css']
})
export class ImportPatientComponent implements OnInit {
  public clinicId: string;
  public patientId: string;
  public requestId: string;
  private unsubscribe = new Subject();
  public fileToUpload: File;
  public showOrientationModal = false;
  public disableProceed = true;
  public patientDetails: any[][];
  public orientation = 'HORIZONTAL';
  public isRequesting = false;
  public fromUploadPatient = false;

  constructor(
    private router: Router,
    private location: Location,
    public fileUploader: UploadFileService,
    private activatedRoute: ActivatedRoute,
    public toastrService: ToastrService,
  ) {
  }

  ngOnInit() {
    Observable.combineLatest(this.activatedRoute.parent.params, this.activatedRoute.params, this.activatedRoute.queryParams)
      .takeUntil(this.unsubscribe).subscribe(responses => {
        this.clinicId = responses[0]['clinicId'];
        this.fromUploadPatient = responses[2]['fromUploadPatient'];
        if (this.fromUploadPatient) {
          this.showOrientationModal = true;
          this.requestId = responses[2]['requestId'];
          this.orientation = responses[2]['orientation'];
          this.upload();
        }
      });
  }

  public selectFile(event) {
    this.fileToUpload = event.target.files[0];
    console.log('filetoupload', this.fileToUpload);
    this.disableProceed = false;
  }

  public uploadCsv() {
    this.isRequesting = true;
    const randomNumber = Math.floor(Math.random() * 1E16);
    this.requestId = randomNumber.toString();
    console.log('request', this.requestId);
    this.upload();
  }

  public uploadOrientation() {
    this.router.navigate([`clinic-view/clinics/${this.clinicId}/patients/patient-data/${this.requestId}/${this.orientation}`]);
    this.showOrientationModal = false;

  }

  public upload() {
    this.fileUploader.csvFileUploader(this.fileToUpload, this.clinicId,
      this.requestId).takeUntil(this.unsubscribe).subscribe(data => {
        if (data.type === HttpEventType.UploadProgress) {
          console.log('progress', Math.min(95, Math.round(100 * data.loaded / data.total)));
        } else if (data instanceof HttpResponse) {
          this.isRequesting = false;
          this.showOrientationModal = true;
          this.patientDetails = JSON.parse((data.body).toString());
        }
      }, err => {
        this.isRequesting = false;
        const error = JSON.parse((err.error).toString());
        console.log('errrr', error);
        this.toastrService.error(error.errorMessages[0]);
      });
  }

  public onClose() {
    this.showOrientationModal = false;
  }
  onBack() {
    this.location.back();
  }
}
