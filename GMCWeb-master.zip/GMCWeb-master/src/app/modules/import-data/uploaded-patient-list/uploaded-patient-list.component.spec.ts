import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadedPatientListComponent } from './uploaded-patient-list.component';

describe('UploadedPatientListComponent', () => {
  let component: UploadedPatientListComponent;
  let fixture: ComponentFixture<UploadedPatientListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UploadedPatientListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UploadedPatientListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
