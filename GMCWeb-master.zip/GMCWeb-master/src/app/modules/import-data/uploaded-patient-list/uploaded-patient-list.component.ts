import { Component, OnInit, HostListener } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RestapiService } from 'app/core/services/restapi.service';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { UploadFileService } from 'app/core/services/upload-file.service';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { ToastrService } from 'ngx-toastr';
import { Location } from '@angular/common';
import * as  _ from 'lodash';
import { Dictionary } from 'app/core/models/dictionary';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';



@Component({
  selector: 'app-uploaded-patient-list',
  templateUrl: './uploaded-patient-list.component.html',
  styleUrls: ['./uploaded-patient-list.component.css']
})
export class UploadedPatientListComponent implements OnInit {
  public clinicId: string;
  public patientId: string;
  public requestId: string;
  public orientation: string;
  public patientData: any[][];
  public patientDetails: any[];
  public fields: any[] = [];
  public headerObj = {};
  public key = '';
  public rows = [];
  public headerField: any[] = [];
  public fieldName: string;
  public errorInData = false;
  public isRequesting = true;
  private unsubscribe = new Subject();
  public showOrientationModal = false;
  public checkMainBox = false;
  public checkAll = false;

  public errorArray: { rowAndColumnId: number, issue: any[] }[] = [];


  constructor(
    private restapiservice: RestapiService,
    private router: Router,
    private location: Location,
    public fileUploader: UploadFileService,
    private activatedRoute: ActivatedRoute,
    public toastrService: ToastrService,
    public confirmationPopup: ConfirmationPopupService
  ) { }

  ngOnInit() {
    Observable.combineLatest(this.activatedRoute.parent.params, this.activatedRoute.params)
      .takeUntil(this.unsubscribe).subscribe(responses => {
        this.clinicId = responses[0]['clinicId'];
        this.requestId = responses[1]['request'];
        this.orientation = responses[1]['orientation'];
        this.restapiservice.invoke<any>(APIEndPoint.GET_IMPORT_DATA_FIELDS_NAME,
          { clinicId: this.clinicId }).subscribe(resp => {
            this.fields = resp;
          });
        this.restapiservice.invoke<any>(APIEndPoint.UPLOAD_ORIENTATION,
          { clinicId: this.clinicId }, null,
          {
            clinicId: this.clinicId, orientation: this.orientation,
            requestId: this.requestId
          }).subscribe(result => {
            this.isRequesting = false;
            this.patientData = result;
            this.patientDetails = this.patientData[0];
            if (this.patientDetails.length < 4 && this.orientation === 'HORIZONTAL') {
              this.toastrService.error(Dictionary.CHANGE_FORMAT);
            }
            if (this.patientData.length < 4 && this.orientation === 'VERTICAL') {
              this.toastrService.error(Dictionary.CHANGE_FORMAT);
            }
            this.errorInData = false;
          }, err => {
            this.isRequesting = false;
            console.log(err);
          });
      });
  }

  /*
    for selecting all patient
  */
  public onCheckAll(event) {
    this.checkAll = false;
    if (event.target.checked) {
      this.key = 'ALL';
      this.rows = [];
      this.checkMainBox = true;
      setTimeout(() => {
        this.checkAll = true;
      }, 10);
    } else {
      this.key = '';
      this.checkAll = false;
      this.checkMainBox = false;
    }
  }

  /*
    for custom selection
  */
  public onCheck(event, index) {
    if (event.target.checked) {
      if (this.checkMainBox === false) {
        this.key = 'CUSTOM';
        this.rows.push(index.toString());
      }
    } else {
      if (this.checkMainBox) {
        this.rows = this.orientation === 'VERTICAL' ? Array.from(Array(this.patientDetails.length), (elem, i) => i.toString()) :
          Array.from(Array(this.patientData.length), (elem, i) => i.toString());
        this.rows.splice(index, 1);
        this.checkMainBox = false;
        this.key = 'CUSTOM';
      } else {
        this.rows.splice(this.rows.findIndex(element => parseInt(element, 10) === index), 1);
        this.key = 'CUSTOM';
      }
    }
  }

  /*
    for field selection
  */
  public onSelectFields(event, index) {
    if (!Object.values(this.headerObj).includes(event.target.value)) {
      if (event.target.value === 'city') {
        this.fieldName = 'name';
      } else {
        this.fieldName = event.target.value;
      }
      this.headerObj = { ...this.headerObj, [index]: this.fieldName };
      if (!this.headerField.includes(event.target.value)) {
        this.headerField[index] = event.target.value;
      }
    }
  }


  /*
    for validate row or coloum has error
  */
  public checkRowColoumHasError(rowcoloumIndex) {
    const array = [...this.errorArray];
    return array.find((elem) => elem.rowAndColumnId === rowcoloumIndex);
  }

  /*
    for validate ceil has error
  */
  public cellHasError(rowcoloumIndex, cellId) {
    // tslint:disable-next-line:no-unused-expression
    _.isEmpty;
    const array = [...this.errorArray];
    const ele = array.filter((elem) => elem.rowAndColumnId === rowcoloumIndex).pop();
    return ele ? ele.issue.filter((elem) => elem === cellId).length > 0 : false;
  }


  public importData() {
    const patientHeader = {
      headers: this.headerObj,
      requestId: this.requestId,
      rowSelected: {
        key: this.key,
        rows: this.rows
      },
    };
    if ((Object.values(this.headerObj).includes('address1') || Object.values(this.headerObj).includes('name') ||
      Object.values(this.headerObj).includes('zip')) &&
      (!(Object.values(this.headerObj).includes('address1') && Object.values(this.headerObj).includes('name') &&
        Object.values(this.headerObj).includes('zip')))) {
      this.confirmationPopup.confirm({ message: Dictionary.ADDRESS_MESSAGE }).subscribe(data => {
        if (data) {
          console.log('patient header', patientHeader);
          if (this.key === '') {
            this.toastrService.error(Dictionary.IMPORT_PATIENT_SELECTION_ERROR);
          } else {
            this.restapiservice.invoke<any>(APIEndPoint.UPLOAD_HEADERS,
              { clinicId: this.clinicId }, patientHeader,
              {
                requestId: this.requestId
              }).subscribe(() => {
                this.toastrService.success(Dictionary.IMPORT_PATIENT_SUCCESS);
                this.errorInData = false;
                this.router.navigate([`/clinic-view/clinics/${this.clinicId}/patients`]);
              }, err => {
                if (err && err.error && err.error.length > 0) {
                  this.errorInData = true;
                  this.errorArray = err.error.map((elem) => {
                    const issueArray = Object.keys(elem.issue).map(key => parseInt(_.invert(this.headerObj)[key], 10));
                    return { ...elem, issue: issueArray };
                  });
                }
              });
          }
        }
      });
    } else {

      console.log('patient header', patientHeader);
      if (this.key === '') {
        this.toastrService.error(Dictionary.IMPORT_PATIENT_SELECTION_ERROR);
      } else {
        this.restapiservice.invoke<any>(APIEndPoint.UPLOAD_HEADERS,
          { clinicId: this.clinicId }, patientHeader,
          {
            requestId: this.requestId
          }).subscribe(() => {
            this.toastrService.success(Dictionary.IMPORT_PATIENT_SUCCESS);
            this.errorInData = false;
            this.router.navigate([`/clinic-view/clinics/${this.clinicId}/patients`]);
          }, err => {
            if (err && err.error && err.error.length > 0) {
              this.errorInData = true;
              this.errorArray = err.error.map((elem) => {
                const issueArray = Object.keys(elem.issue).map(key => parseInt(_.invert(this.headerObj)[key], 10));
                return { ...elem, issue: issueArray };
              });
            }
          });
      }
    }


  }

  onBack() {
    this.router.navigate([`clinic-view/clinics/${this.clinicId}/patients/import/patient/data`]);
  }

  public onChangeFormat() {
    this.router.navigate([`clinic-view/clinics/${this.clinicId}/patients/import/patient/data`], {
      queryParams: {
        requestId: this.requestId,
        fromUploadPatient: true,
        orientation: this.orientation
      }
    });
  }
}


