import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';
import { MainViewComponent } from 'app/modules/main-view/main-view.component';
import { LoginRouteGuardGuard } from 'app/core/auth/login-route-guard.guard';
import { SubscriptionRouteGuardGuard } from 'app/core/auth/subscription-route-guard.guard';
import { AgreementRouteGuardGuard } from 'app/core/auth/agreement-route-guard.guard';
import { ImportPatientComponent } from 'app/modules/import-data/import-patient/import-patient.component';
import { UploadedPatientListComponent } from 'app/modules/import-data/uploaded-patient-list/uploaded-patient-list.component';

const IMPORT_DATA: Routes = [
    {
        path: 'clinic-view/clinics/:clinicId',
        component: MainViewComponent,
        canActivate: [LoginRouteGuardGuard, SubscriptionRouteGuardGuard, AgreementRouteGuardGuard],
        children: [
            { path: 'patients/import/patient/data', component: ImportPatientComponent },
            {
                path: 'patients/patient-data/:request/:orientation',
                component: UploadedPatientListComponent
            }
        ]
    },
];

@NgModule({
    exports: [RouterModule],
    imports: [RouterModule.forChild(IMPORT_DATA)],
})

export class ImportDataRoutingModule { }
