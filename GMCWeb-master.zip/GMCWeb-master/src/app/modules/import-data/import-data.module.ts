import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ImportPatientComponent } from 'app/modules/import-data/import-patient/import-patient.component';
import { ImportDataRoutingModule } from 'app/modules/import-data/import-data.routes';
import { UploadedPatientListComponent } from './uploaded-patient-list/uploaded-patient-list.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    ImportDataRoutingModule
  ],
  declarations: [ImportPatientComponent, UploadedPatientListComponent]
})
export class ImportDataModule { }
