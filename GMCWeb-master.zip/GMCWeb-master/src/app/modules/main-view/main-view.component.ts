import { Component, OnInit } from '@angular/core';
import { RestapiService } from 'app/core/services/restapi.service';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { ClinicDetails } from 'app/core/models/clinicDetails';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Location } from '@angular/common';
import 'rxjs/add/operator/mergeMap';


@Component({
  selector: 'app-main-view',
  templateUrl: './main-view.component.html',
  styleUrls: ['./main-view.component.css']
})
export class MainViewComponent implements OnInit {

  clinic$: Observable<ClinicDetails>;
  currentView$: Observable<any>;
  facilityId: string;
  constructor(
    public api: RestapiService,
    private activatedRoute: ActivatedRoute,
    public location: Location
  ) { }
  public getCurrentView(view) {
    return view[0].path;
  }
  public getClinic(clinicId: string): Observable<ClinicDetails> {
    return this.api
      .invoke<ClinicDetails>(APIEndPoint.GET_CLINIC_BY_ID,
        { clinicId: clinicId });
  }
  ngOnInit() {
    this.clinic$ = this.activatedRoute.params.flatMap(params => {
      console.log('facility in main view');
      this.facilityId = params['facilityId'];
      return this.getClinic(params['clinicId']);
    });
    this.currentView$ = this.activatedRoute.url.map(url =>
      this.getCurrentView(url)
    );
  }

}
