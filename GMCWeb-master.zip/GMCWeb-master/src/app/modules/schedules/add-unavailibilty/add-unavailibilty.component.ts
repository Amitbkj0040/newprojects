import { Component, OnInit, OnDestroy, ViewEncapsulation } from '@angular/core';
import { AmazingTimePickerService } from 'amazing-time-picker';
import { INgxMyDpOptions, IMyDateModel } from 'ngx-mydatepicker';
import { FormGroup, FormControl, Validators, FormBuilder, FormArray, AbstractControl } from '@angular/forms';
import { RestapiService } from 'app/core/services/restapi.service';
import { Router, ActivatedRoute, NavigationExtras } from '@angular/router';
import { APIEndPoint, APIDef } from 'app/core/models/ApiEndPoint';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { ToastrService } from 'ngx-toastr';
import { Dictionary } from 'app/core/models/dictionary';
import { NonAvailability } from 'app/core/models/nonAvailability';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import * as moment from 'moment';


@Component({
  selector: 'app-add-unavailibilty',
  templateUrl: './add-unavailibilty.component.html',
  styleUrls: ['./add-unavailibilty.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class AddUnavailibiltyComponent implements OnInit {
  public isRequesting = false;
  public addMode = false;
  public editMode = false;
  public pageNumber = 0;
  public pageSize = 10;
  public search = '';
  public sort = '';
  public sortOn = '';
  unavailabilityForm: FormGroup;
  apiSD: APIDef = APIEndPoint.GET_SUBSTITUTE_DOCTOR;
  selectedDoctors: any[] = [];
  public startDate = null;
  public endDate = null;
  public clinicId: string;
  public staffId: string;
  public facilityId: string;
  public unavailId: string;
  public notify = false;
  public dateCheck = false;
  public searchText = '';
  public unavailable$: Observable<NonAvailability[]>;
  public _unavailableList = new Subject<NonAvailability[]>();
  public unavailableList$ = this._unavailableList.asObservable();
  public unavailableList: NonAvailability[] = [];
  public isOpenSearch = false;

  private unsubscribe = new Subject<void>();
  myOptions: INgxMyDpOptions = {
    // other options...
    dateFormat: 'yyyy-mm-dd',
  };


  constructor(private atp: AmazingTimePickerService,
    public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    public toastrService: ToastrService,
    private formBuilder: FormBuilder,
    public confirmationPopup: ConfirmationPopupService) { }

  ngOnInit() {
    Observable.combineLatest(this.activatedRoute.parent.params,
      this.activatedRoute.params).takeUntil(this.unsubscribe).subscribe(response => {
        this.clinicId = response[0]['clinicId'];
        this.staffId = response[1]['staffId'];
        this.facilityId = response[0]['facilityId'];
        this.unavailable$ = this.unavailableList$;
        this.pageNumber !== 0 ? this.getNonAvailibility() : this.getNonavailabilityPagination(this.pageNumber, this.pageSize);
      });
    this.createForm();

  }

  setDoctor(event) {
    console.log('event', event);
    this.selectedDoctors.push(event);
    console.log('this.selected doctors from unavail', this.selectedDoctors);

  }

  onDateChanged(event, type) {
    if (type === 'START') {
      this.startDate = event.formatted;
      console.log('startdate', this.startDate);
      this.unavailabilityForm.controls['startDate'].setValue(this.startDate);
    } else if (type === 'END') {
      const isBefore = moment(new Date(event.formatted)).isSameOrAfter(new Date(this.startDate.formatted), 'days');
      console.log('isBefore', isBefore);
      if (isBefore) {
        this.dateCheck = false;
        this.endDate = event.formatted;
        this.unavailabilityForm.controls['endDate'].setValue(this.endDate);
        console.log('enddate', this.endDate);
      } else {
        this.dateCheck = true;
        this.endDate = event.formatted;
        this.unavailabilityForm.controls['endDate'].setValue(this.endDate);
        console.log(this.startDate, this.endDate);
      }
    }
  }



  //   openStartTime() {
  //   const amazingTimePicker = this.atp.open({
  //     time: null,
  //   });
  //   amazingTimePicker.afterClose().subscribe(time => {
  //     console.log('starttime', time);
  //     this.unavailabilityForm.controls['startTime'].setValue(time);
  //   });
  // }

  getNonavailabilityPagination(pageNumber, pageSize) {
    this.isRequesting = true;
    this.restapiservice
      .invoke<NonAvailability>(APIEndPoint.GET_ALL_NON_AVAILABILITY,
        { clinicId: this.clinicId, facilityId: this.facilityId, staffId: this.staffId }, null,
        {
          'pageNumber': pageNumber,
          'pageSize': pageSize,
          'search': this.search,
          'sort': this.sort,
          'sortOn': this.sortOn
        }).subscribe((doctorRes: any) => {
          this.isRequesting = false;
          if (this.pageNumber === 0) {
            this.unavailableList = [];
          }
          doctorRes.forEach(element => {
            this.unavailableList.push(element);
          });
          this._unavailableList.next(this.unavailableList);
        });
  }
  getNonAvailibility() {
    this.isRequesting = true;
    this.unavailable$ = this.restapiservice.invoke<NonAvailability[]>(APIEndPoint.GET_ALL_NON_AVAILABILITY,
      { clinicId: this.clinicId, facilityId: this.facilityId, staffId: this.staffId }).map(res => {
        this.isRequesting = false;
        return res;
      });
  }

  onScrollUp() {
    console.log('scroll up', this.pageNumber++);
    this.getNonavailabilityPagination(this.pageNumber, this.pageSize);
  }

  delete(Id) {
    this.confirmationPopup.confirm({ message: Dictionary.DELETE_CONFIRMATION }).subscribe(data => {
      if (data) {
        this.deleteUnavailability(Id);
      }
    });
  }

  deleteUnavailability(Id) {
    this.isRequesting = true;
    this.restapiservice
      .invoke<NonAvailability>(APIEndPoint.DELETE_NON_AVAILABILITY_BY_ID,
        { clinicId: this.clinicId, facilityId: this.facilityId, staffId: this.staffId, nonAvailabilityId: Id }).subscribe(nonavailable => {
          console.log('successfully deleted', nonavailable);
          this.toastrService.success(Dictionary.ENTITY_DELETION);
          this.isRequesting = false;
          this.getNonAvailibility();
        }, err => {
          console.log(err);
          this.isRequesting = false;
        });
  }

  // openEndTime() {
  //   const amazingTimePicker = this.atp.open({
  //     time: null,
  //   });
  //   amazingTimePicker.afterClose().subscribe(time => {
  //     console.log('endtime', time);
  //     this.unavailabilityForm.controls['endTime'].setValue(time);
  //   });
  // }
  onCheck(event) {
    console.log('check', event.target.checked);
    if (event.target.checked) {
      this.notify = true;
      this.selectedDoctors = [];
    } else {
      this.notify = false;
    }

  }

  onAddAvailability() {
    this.addMode = true;
    this.dateCheck = false;
    this.unavailabilityForm.reset();
    this.selectedDoctors = [];
    this.startDate = null;
    this.endDate = null;
    this.unavailabilityForm.controls['notifyAndReplace'].setValue(false);
    this.notify = false;
    this.unavailabilityForm.controls['notifyAndCancel'].setValue(true);
  }

  saveUnavailability() {

    console.log('this.selected doctors from unavail', this.selectedDoctors);
    const formObj = this.unavailabilityForm.getRawValue();
    if (!this.notify) {
      formObj.doctorSubstituteVO = { id: null, type: null, name: null, email: null, designation: null };
    } else {
      this.selectedDoctors.forEach(element => {
        console.log('element', element);
        if (Object.keys(element).length > 1) {
          formObj.doctorSubstituteVO = element;
        } else {
          formObj.doctorSubstituteVO = { id: null, type: null, name: null, email: element.name, designation: null };
        }
      });
    }
    if (this.notify && this.selectedDoctors.length === 0) {
      this.toastrService.error('Please enter Substitute doctor details');
    }
    console.log('new form', JSON.stringify(formObj));
    if (formObj.notifyAndCancel) {
      this.confirmationPopup.confirm({ message: Dictionary.CHECK_CONFIRMATION }).subscribe(data => {
        if (data) {
          this.isRequesting = true;
          this.restapiservice.invoke<NonAvailability>(APIEndPoint.POST_NON_AVAILABLITY, {
            clinicId: this.clinicId, facilityId: this.facilityId, staffId: this.staffId
          }, formObj).subscribe(resp => {
            this.unavailabilityForm.reset();
            this.addMode = false;
            this.toastrService.success(Dictionary.SUCCESSFUL_REGISTRATION({ EntityName: 'Unavailability Schedule' }));
            this.getNonAvailibility();
          }, err => {
            console.log('err', err);
            this.addMode = true;
            this.isRequesting = false;
          }
          );
        }
      });
    } else {
      this.isRequesting = true;
      this.restapiservice.invoke<NonAvailability>(APIEndPoint.POST_NON_AVAILABLITY, {
        clinicId: this.clinicId, facilityId: this.facilityId, staffId: this.staffId
      }, formObj).subscribe(resp => {
        this.unavailabilityForm.reset();
        this.addMode = false;
        this.toastrService.success(Dictionary.SUCCESSFUL_REGISTRATION({ EntityName: 'Unavailability Schedule' }));
        this.getNonAvailibility();
      }, err => {
        console.log('err', err);
        this.addMode = true;
        this.isRequesting = false;
      }
      );
    }
  }


  onEditAvailability(id) {
    this.dateCheck = false;
    this.unavailabilityForm.reset();
    this.selectedDoctors = [];
    this.startDate = null;
    this.endDate = null;
    this.unavailId = id;
    this.editMode = true;
    this.restapiservice.invoke<NonAvailability>(APIEndPoint.GET_NON_AVAILABILITY_BY_ID,
      { nonAvailabilityId: this.unavailId, clinicId: this.clinicId, facilityId: this.facilityId, staffId: this.staffId })
      .subscribe(nonAvailability => {
        this.unavailabilityForm.patchValue(nonAvailability);
        if (nonAvailability.doctorSubstituteVO.name) {
          this.selectedDoctors.push(nonAvailability.doctorSubstituteVO);
        } else {
          const obj = { name: nonAvailability.doctorSubstituteVO.email };
          this.selectedDoctors.push(obj);
        }
        console.log('doctors', this.selectedDoctors, nonAvailability.doctorSubstituteVO);
        if (nonAvailability.notifyAndReplace) {
          this.notify = true;
        } else {
          this.notify = false;
        }
        const startDate = new Date(nonAvailability.startDate);
        this.startDate = {
          date: {
            year: startDate.getFullYear(),
            month: startDate.getMonth() + 1,
            day: startDate.getDate()
          },
          formatted: nonAvailability.startDate
        };
        const endDate = new Date(nonAvailability.endDate);
        this.endDate = {
          date: {
            year: endDate.getFullYear(),
            month: endDate.getMonth() + 1,
            day: endDate.getDate()
          },
          formatted: nonAvailability.endDate
        };
      });

  }


  updateUnavailability() {
    const formObj = this.unavailabilityForm.getRawValue();
    if (!this.notify) {
      formObj.doctorSubstituteVO = { id: null, type: null, name: null, email: null, designation: null };
    } else {
      this.selectedDoctors.forEach(element => {
        console.log('element', element);
        if (Object.keys(element).length > 1) {
          formObj.doctorSubstituteVO = element;
        } else {
          formObj.doctorSubstituteVO = { id: null, type: null, name: null, email: element.name, designation: null };
        }
      });
    }
    if (this.notify && this.selectedDoctors.length === 0) {
      this.toastrService.error('Please enter Substitute doctor details');
    }
    console.log('udated form', JSON.stringify(formObj));
    if (formObj.notifyAndCancel) {
      this.confirmationPopup.confirm({ message: Dictionary.CHECK_CONFIRMATION }).subscribe(data => {
        if (data) {
          this.isRequesting = true;
          this.restapiservice
            .invoke<NonAvailability>(APIEndPoint.UPDATE_NON_AVAILABILITY_BY_ID,
              { nonAvailabilityId: this.unavailId, clinicId: this.clinicId, facilityId: this.facilityId, staffId: this.staffId },
              formObj).subscribe(nonavail => {
                console.log('successfully edited', nonavail);
                this.unavailabilityForm.reset();
                this.editMode = false;
                this.toastrService.success(Dictionary.SUCCESSFUL_UPDATION({ EntityName: 'Unavailability Schedule' }));
                this.getNonAvailibility();
                this.isRequesting = false;
              }, error => {
                console.log('error in adding ', error);
                this.editMode = true;
                this.isRequesting = false;
              });
        }

      });
    } else {
      this.isRequesting = true;
      this.restapiservice
        .invoke<NonAvailability>(APIEndPoint.UPDATE_NON_AVAILABILITY_BY_ID,
          { nonAvailabilityId: this.unavailId, clinicId: this.clinicId, facilityId: this.facilityId, staffId: this.staffId },
          formObj).subscribe(nonavail => {
            console.log('successfully edited', nonavail);
            this.unavailabilityForm.reset();
            this.editMode = false;
            this.toastrService.success(Dictionary.SUCCESSFUL_UPDATION({ EntityName: 'Unavailability Schedule' }));
            this.getNonAvailibility();
            this.isRequesting = false;
          }, error => {
            console.log('error in udate ', error);
            this.editMode = true;
            this.isRequesting = false;
          });
    }
  }

  onClose() {
    this.addMode = false;
    this.editMode = false;
  }
  createForm() {
    this.unavailabilityForm = this.formBuilder.group({
      startDate: [null, Validators.required],
      endDate: [null, Validators.required],
      startTime: [null, Validators.required],
      endTime: [null, Validators.required],
      title: [null, Validators.required],
      notifyAndReplace: [false, Validators.required],
      notifyAndCancel: [true, Validators.required],
    });
  }

}
