import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddUnavailibiltyComponent } from './add-unavailibilty.component';

describe('AddUnavailibiltyComponent', () => {
  let component: AddUnavailibiltyComponent;
  let fixture: ComponentFixture<AddUnavailibiltyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddUnavailibiltyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddUnavailibiltyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
