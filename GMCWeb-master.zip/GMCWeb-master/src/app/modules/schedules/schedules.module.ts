import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgxMyDatePickerModule } from 'ngx-mydatepicker';
import { SharedModule } from 'app/shared/shared.module';
import { SchedulesRoutingModule } from 'app/modules/schedules/schedules.routes';
import { DoctorScheduleComponent } from 'app/modules/schedules/doctor-schedule/doctor-schedule.component';
import { AddDoctorScheduleComponent } from 'app/modules/schedules/add-doctor-schedule/add-doctor-schedule.component';
import { AddUnavailibiltyComponent } from 'app/modules/schedules/add-unavailibilty/add-unavailibilty.component';
import { AmazingTimePickerModule } from 'amazing-time-picker';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    SchedulesRoutingModule,
    NgxMyDatePickerModule.forRoot(),
    AmazingTimePickerModule,
  ],
  declarations: [
    DoctorScheduleComponent,
    AddDoctorScheduleComponent,
    AddUnavailibiltyComponent,
  ]
})
export class SchedulesModule { }
