import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RestapiService } from 'app/core/services/restapi.service';
import { FormBuilder } from '@angular/forms';
import { StaffSchedule, ScheduleTiming, DayOfWeek, WeekStatus } from 'app/core/models/app.models';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Doctor } from 'app/core/models/app.models';
import { AuthService } from 'app/core/auth/auth.service';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { Observable } from 'rxjs/Observable';
import { HTTPStaffSchedule } from 'app/core/models/app.models';
import { Subject } from 'rxjs/Subject';
import { AddStaff } from 'app/core/models/addStaff';
import { combineLatest } from 'rxjs/operator/combineLatest';
import { ToastrService } from 'ngx-toastr';
import { Dictionary } from 'app/core/models/dictionary';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { share } from 'rxjs/operators';
import { Location } from '@angular/common';

@Component({
  selector: 'app-doctor-schedule',
  templateUrl: './doctor-schedule.component.html',
  styleUrls: ['./doctor-schedule.component.css']
})
export class DoctorScheduleComponent implements OnInit, OnDestroy {
  isRequesting: false;
  public pageNumber = 0;
  public pageSize = 10;
  public search = '';
  public sort = '';
  public sortOn = '';
  public staffId: string;
  public facilityId: string;
  public clinicId: string;
  public staffSchedule$: Observable<StaffSchedule[]>;
  private unsubscribe = new Subject<void>();
  public doctors$: Observable<Doctor[]>;
  public token: any;
  public selectedDoc$: Observable<AddStaff>;
  public docSearchTxt: string;
  public _doctorList = new Subject<Doctor[]>();
  public doctorList$ = this._doctorList.asObservable();
  public doctorList: Doctor[] = [];
  constructor(
    public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    public authService: AuthService,
    public jwtHelper: JwtHelperService,
    public location: Location,
    public toaster: ToastrService,
    public confirmationPopup: ConfirmationPopupService,
  ) { }
  private getToken() {
    return this.jwtHelper.decodeToken(this.authService.getAuthToken());
  }
  getDoctors(pageNumber, pageSize) {
    this.restapiservice
      .invoke<Doctor[]>(APIEndPoint.GET_DOCTORS,
        { clinicId: this.authService.getClinicId(), facilityId: this.facilityId }, null,

        {
          'pageNumber': pageNumber,
          'pageSize': pageSize,
          'search': this.search,
          'sort': this.sort,
          'sortOn': this.sortOn
        }).subscribe((doctorRes: any) => {
          this.isRequesting = false;
          doctorRes.forEach(element => {
            this.doctorList.push(element);
          });
          this._doctorList.next(this.doctorList);
        });
  }

  getStaff(staffId) {
    // this.clinicId = '1';
    return this.restapiservice.invoke<AddStaff>(APIEndPoint.GET_STAFF_BY_ID,
      { clinicId: this.authService.getClinicId(), staffId: this.staffId });
  }
  Back() {
    this.location.back();
  }

  getSchedules(staffId: string): Observable<StaffSchedule[]> {
    console.log('staffId', this.staffId);
    return this.restapiservice
      .invoke<HTTPStaffSchedule[]>(APIEndPoint.GET_STAFF_SCHEDULES,
        { clinicId: this.authService.getClinicId(), facilityId: this.facilityId, staffId: staffId }).map(httpStaffSchedules => {
          const staffSchedules: StaffSchedule[] = [];
          httpStaffSchedules.forEach(httpStaffSchedule => {
            staffSchedules.push(StaffSchedule.fromHTTPStaffSchedule(httpStaffSchedule));
          });
          return staffSchedules;
        });
  }

  // public mockSchedules(): Observable<StaffSchedule[]> {
  //   const staffSchedule: StaffSchedule[] = [
  //     {
  //       id: '1',
  //       startDate: '2018-05-14T00:00:00.000+0000',
  //       endDate: '2018-07-30T00:00:00.000+0000',
  //       scheduleTimings:  this.mockScheduleTiming()
  //     }
  //   ];
  //   return Observable.of(staffSchedule);
  // }

  getWeekString(weekSchedule: WeekStatus): string {
    let weekString = '';
    if (weekSchedule.firstWeek) {
      weekString += 'W1, ';
    }
    if (weekSchedule.secondWeek) {
      weekString += 'W2, ';
    }
    if (weekSchedule.thirdWeek) {
      weekString += 'W3, ';
    }
    if (weekSchedule.fourthWeek) {
      weekString += 'W4, ';
    }
    if (weekSchedule.fifthWeek) {
      weekString += 'W5';
    }
    return weekString;
  }
  isUserAdmin() {
    return this.authService.isUserAdmin();
  }
  deleteStaffSchedules(scheduleId) {
    this.confirmationPopup.confirm({ message: Dictionary.DELETE_CONFIRMATION }).subscribe(data => {
      if (data) {
        this.restapiservice.invoke<HTTPStaffSchedule>(APIEndPoint.DELETE_STAFF_SCHEDULE_BY_ID,
          { clinicId: this.clinicId, facilityId: this.facilityId, staffId: this.staffId, scheduleId: scheduleId })
          .subscribe(schedule => {
            console.log('doctor schedule', schedule);
            this.staffSchedule$ = this.getSchedules(this.staffId);
            this.toaster.success(Dictionary.ENTITY_DELETION);
          }, err => {
            console.log(err);
            this.toaster.error(Dictionary.ERROR_MSG);
          });
      }
    });
  }
  onScrollUp() {
    console.log('scroll up', this.pageNumber++);
    this.getDoctors(this.pageNumber, this.pageSize);
  }
  ngOnInit() {
    Observable.combineLatest(this.activatedRoute.parent.params,
      this.activatedRoute.params).takeUntil(this.unsubscribe).subscribe(params => {
        this.doctorList = [];
        this.clinicId = params[0]['clinicId'];
        this.facilityId = params[0]['facilityId'];
        this.staffId = params[1]['staffId'];
        console.log('staffId', this.staffId);
        this.selectedDoc$ = this.getStaff(this.staffId);
        console.log('fssdf', this.selectedDoc$);
        this.doctors$ = this.doctorList$;
        this.getDoctors(this.pageNumber, this.pageSize);
        this.staffSchedule$ = this.getSchedules(this.staffId);
      });
  }

  ngOnDestroy(): void {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}


