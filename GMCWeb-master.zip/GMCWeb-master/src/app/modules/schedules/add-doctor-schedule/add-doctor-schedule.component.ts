import { Component, OnInit, OnDestroy } from '@angular/core';
import { StaffSchedule, DayOfWeek, ScheduleTiming, WeekStatus, TimingMode, HTTPStaffSchedule } from 'app/core/models/app.models';
import { RestapiService } from 'app/core/services/restapi.service';
import { Router, ActivatedRoute } from '@angular/router';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { FormGroup, FormBuilder } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { AddStaff } from 'app/core/models/app.models';
import { AuthService } from 'app/core/auth/auth.service';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Dictionary } from 'app/core/models/dictionary';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { IMyDrpOptions } from 'mydaterangepicker';
import { Location } from '@angular/common';
import { ClinicService } from 'app/core/services/clinic-service.service';


// import { NgxDateRangePickerOptions } from 'ngx-daterangepicker';

@Component({
  selector: 'app-add-doctor-schedule',
  templateUrl: './add-doctor-schedule.component.html',
  styleUrls: ['./add-doctor-schedule.component.css'],
})
export class AddDoctorScheduleComponent implements OnInit, OnDestroy {
  public todayDate: Date = new Date();
  public scheduleDateRange: any =
    {
      beginDate: { year: this.todayDate.getFullYear(), month: this.todayDate.getMonth() + 1, day: this.todayDate.getDate() },
      endDate: { year: this.todayDate.getFullYear(), month: this.todayDate.getMonth() + 1, day: this.todayDate.getDate() }
    };
  public myDateRangePickerOptions: IMyDrpOptions;
  TimingMode = TimingMode;
  toEditTimingIndex: number;
  mode: any;
  index: number;
  timingMode: TimingMode;
  minsInDay = 24 * 60;
  activeElementIndex = 0;
  public clinicId;
  public facilityId;
  public staffId;
  public isGetScheduleData = false;
  public isTimeOverlap = false;
  hideAlert = false;
  currentUser: string = Dictionary.SELECT_DATE_ALERT;
  timeOverlapMsg = '';
  scheduleId: string;
  currentDaySelection = -1;
  doctorScheduleForm: FormGroup;
  public dayOfWeek: string;
  private unsubscribe = new Subject<void>();
  public doctorSchedule$: Observable<StaffSchedule>;
  public selectedDoc$: Observable<AddStaff>;
  staffSchedule: StaffSchedule = new StaffSchedule('', '', new Map());
  staffDateArray: { startDate: string, endDate: string }[] = [];
  isDateRangeChange = false;
  public days = [
    {
      name: 'SUNDAY', timing: new ScheduleTiming('10:00', '12:00', new WeekStatus(true, true, true, true, true)),
      fromampm: 'AM', toampm: 'PM'
    },
    {
      name: 'MONDAY', timing: new ScheduleTiming('10:00', '12:00', new WeekStatus(true, true, true, true, true)),
      fromampm: 'AM', toampm: 'PM'
    },
    {
      name: 'TUESDAY', timing: new ScheduleTiming('10:00', '12:00', new WeekStatus(true, true, true, true, true)),
      fromampm: 'AM', toampm: 'PM'
    },
    {
      name: 'WEDNESDAY', timing: new ScheduleTiming('10:00', '12:00', new WeekStatus(true, true, true, true, true)),
      fromampm: 'AM', toampm: 'PM'
    },
    {
      name: 'THURSDAY', timing: new ScheduleTiming('10:00', '12:00', new WeekStatus(true, true, true, true, true)),
      fromampm: 'AM', toampm: 'PM'
    },
    {
      name: 'FRIDAY', timing: new ScheduleTiming('10:00', '12:00', new WeekStatus(true, true, true, true, true)),
      fromampm: 'AM', toampm: 'PM'
    },
    {
      name: 'SATURDAY', timing: new ScheduleTiming('10:00', '12:00', new WeekStatus(true, true, true, true, true)),
      fromampm: 'AM', toampm: 'PM'
    }
  ];

  times: string[] = [];
  // ublic array: any[] = [];
  public pr_schedule: ScheduleTiming = {
    dayOfWeek: null,
    startTime: '00:00',
    endTime: '00:00',
    monthWeekAvailablities: {
      firstWeek: true,
      secondWeek: true,
      thirdWeek: true,
      fourthWeek: true,
      fifthWeek: true
    }
  };

  public monthWeekAvailablities: WeekStatus[] = [];


  public daterange: any = {};
  public datepicker: any;



  public options: any = {
    locale: { format: 'YYYY-MM-DD' },
    alwaysShowCalendars: false,
  };





  constructor(public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    private toaster: ToastrService,
    public authService: AuthService,
    public jwtHelper: JwtHelperService,
    public location: Location,
    private fb: FormBuilder,
    public clinicService: ClinicService,
    public confirmationPopup: ConfirmationPopupService) {

  }

  changeActiveElementIndex(currentElement) {
    let element = this.convertTo12hr(currentElement);
    element = element.slice(0, element.length - 2);
    // tslint:disable-next-line:radix
    element = parseInt(element.split(':')[0]) > 9 ? element : '0' + element;
    setTimeout(() => {
      this.activeElementIndex = this.times.indexOf(element);
    }, 10);
  }

  getStaff(staffId) {
    return this.restapiservice.invoke<AddStaff>(APIEndPoint.GET_STAFF_BY_ID,
      { clinicId: this.authService.getClinicId(), staffId: this.staffId });
  }

  Back() {
    this.location.back();
  }

  getSchedules(staffId: string) {
    this.staffDateArray = [];
    this.restapiservice
      .invoke<HTTPStaffSchedule[]>(APIEndPoint.GET_STAFF_SCHEDULES,
        { clinicId: this.authService.getClinicId(), facilityId: this.facilityId, staffId: staffId }).subscribe(httpStaffSchedules => {
          httpStaffSchedules.forEach(httpStaffSchedule => {
            this.staffDateArray.push({ startDate: httpStaffSchedule.startDate, endDate: httpStaffSchedule.endDate });
            console.log('hello this is the following thing that is the call after', this.staffDateArray);
          });
        });

  }

  ngOnInit() {
    for (let hour = 1; hour < 13; hour++) {
      for (let min = 0; min < 60; min += 15) {
        this.times.push((hour < 10 ? '0' + hour : hour) + ':' + (min < 10 ? '0' + min : min));
      }
    }
    this.clinicService.changeFacility.takeUntil(this.unsubscribe).subscribe((res) => {
      if (this.mode === 'edit') {
        this.mode = '';
        // tslint:disable-next-line:max-line-length
        this.router.navigate([`clinic-view/clinics/${this.clinicId}/facilities/${res.facilityId}/doctors/${this.staffId}/appointments/view`]);
      }
    });

    Observable.combineLatest(this.activatedRoute.parent.params,
      this.activatedRoute.params,
      this.activatedRoute.queryParams).takeUntil(this.unsubscribe).subscribe(response => {
        this.facilityId = response[0]['facilityId'];
        this.clinicId = response[0]['clinicId'];
        this.staffId = response[1]['staffId'];
        this.mode = response[1]['action'];
        this.selectedDoc$ = this.getStaff(this.staffId);
        this.getSchedules(this.staffId);
        this.myDateRangePickerOptions = {
          disableUntil: { year: this.todayDate.getFullYear(), month: this.todayDate.getMonth() + 1, day: this.todayDate.getDate() - 1 },
          dateFormat: 'dd/mm/yyyy',
        };
        if (this.mode === 'edit') {
          this.scheduleId = response[1]['scheduleId'];
          this.getSchedule(this.scheduleId);
        }
      });
  }

  ngOnDestroy(): void {
    this.unsubscribe.complete();
    this.unsubscribe.unsubscribe();
  }

  deleteScheduleTiming(dayIndex: number) {
    const scheduleTimings: ScheduleTiming[] = this.staffSchedule.scheduleTimings.get(this.days[dayIndex].name);
    if (scheduleTimings && scheduleTimings.length > this.toEditTimingIndex) {
      scheduleTimings.splice(this.toEditTimingIndex, 1);
    }
    this.resetDaysAtIndex(dayIndex);
  }

  convertTo24Hour(time: string, amPM: string): string {
    const hrMinArr: string[] = time.split(':');
    const hour = parseInt(hrMinArr[0], 10);
    if (amPM === 'PM') {
      if (hrMinArr[0] >= '12') {
        return time;
      } else {
        return (hour + 12) + ':' + hrMinArr[1];
      }
    } else {
      if (hour >= 12 && hour < 22) {
        return '0' + (hour - 12) + ':' + hrMinArr[1];
      } else if (hour >= 22 && hour <= 23) {
        return (hour - 12) + ':' + hrMinArr[1];
      } else {
        return time;
      }
    }
  }

  convertTo12hr(time) {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];
    if (time.length > 1) { // If time format correct
      time = time.slice(1);  // Remove full string match value
      time[5] = +time[0] < 12 ? 'AM' : 'PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    return time.join('');
  }

  compareTime(time1: string, time2: string): number {
    let hrMinArr: string[] = time1.split(':');
    const time1InMin = parseInt(hrMinArr[0], 10) * 60 + parseInt(hrMinArr[1], 10);
    hrMinArr = time2.split(':');
    const time2InMin = parseInt(hrMinArr[0], 10) * 60 + parseInt(hrMinArr[1], 10);
    return time1InMin - time2InMin;
  }


  // checking for the time overlapping
  checkforTimeOverlapping(currentScheduleTimingArray, scheduleTimigTobeAdded) {

    const isTimeOverlap = false;
    const result = { isTimeOverlap: isTimeOverlap, startTime: scheduleTimigTobeAdded.startTime, endTime: scheduleTimigTobeAdded.endTime };
    const endTime = parseFloat(scheduleTimigTobeAdded.startTime.split(':')[0])
      + parseFloat(scheduleTimigTobeAdded.startTime.split(':')[1]) / 100;
    const startTime = parseFloat(scheduleTimigTobeAdded.endTime.split(':')[0])
      + parseFloat(scheduleTimigTobeAdded.endTime.split(':')[1]) / 100;

    if (currentScheduleTimingArray && currentScheduleTimingArray.length >= 1) {
      currentScheduleTimingArray.some(element => {
        result.isTimeOverlap = false;
        const currentStartTime = parseFloat(element.startTime.split(':')[0]) + parseFloat(element.startTime.split(':')[1]) / 100;
        const currentEndTime = parseFloat(element.endTime.split(':')[0]) + parseFloat(element.endTime.split(':')[1]) / 100;

        if (
          (startTime <= currentStartTime && currentStartTime <= endTime) ||
          (startTime <= currentEndTime && currentEndTime <= endTime) ||
          (currentStartTime <= startTime && startTime <= currentEndTime) ||
          (currentStartTime <= endTime && endTime <= currentEndTime)
        ) {
          result.isTimeOverlap = true;
          return true;
        }
      });

      return result;
    } else {
      return result;
    }
  }


  //
  checkforWeekOverlapping(currentScheduleTimingArray, scheduleTimigTobeAdded) {
    const result = { isWeekOverlapping: false, monthWeekAvailablities: scheduleTimigTobeAdded.monthWeekAvailablities };
    if (currentScheduleTimingArray && currentScheduleTimingArray.length >= 1) {
      currentScheduleTimingArray.some((element) => {
        for (const property in element.monthWeekAvailablities) {
          if ((scheduleTimigTobeAdded.monthWeekAvailablities[property] === true) && (element.monthWeekAvailablities[property] === true)) {
            result.isWeekOverlapping = true;
            return true;
          }
        }
      });
      return result;
    } else {
      return result;
    }
  }

  checkforDateRangeOverlapping(scheduleDateCollection, newStartDate, newEndDate) {
    let result = false, currentStartDate, currentEndDate;
    if (typeof (newStartDate) === 'string' && typeof (newEndDate) === 'string') {
      currentStartDate = (new Date(parseInt(newStartDate.split('-')[0], 10),
        parseInt(newStartDate.split('-')[1].replace(/^0+/, ''), 10) - 1,
        parseInt(newStartDate.split('-')[2], 10))).getTime();
      currentEndDate = (new Date(parseInt(newStartDate.split('-')[0], 10),
        parseInt(newStartDate.split('-')[1].replace(/^0+/, ''), 10) - 1,
        parseInt(newStartDate.split('-')[2], 10))).getTime();
    } else {
      currentStartDate = newStartDate.getTime();
      currentEndDate = newEndDate.getTime();
    }
    if (scheduleDateCollection && scheduleDateCollection.length >= 1) {
      scheduleDateCollection.some((element) => {
        const startDate = (new Date(parseInt(element.startDate.split('-')[0], 10),
          parseInt(element.startDate.split('-')[1].replace(/^0+/, ''), 10) - 1,
          parseInt(element.startDate.split('-')[2], 10))).getTime();
        const endDate = (new Date(parseInt(element.endDate.split('-')[0], 10),
          parseInt(element.endDate.split('-')[1].replace(/^0+/, ''), 10) - 1,
          parseInt(element.endDate.split('-')[2], 10))).getTime();
        if ((startDate <= currentStartDate && currentStartDate <= endDate) ||
          (startDate <= currentEndDate && currentEndDate <= endDate) ||
          (currentStartDate <= startDate && startDate <= currentEndDate) ||
          (currentStartDate <= endDate && endDate <= currentEndDate)) {
          console.log({ currentStartDate: currentStartDate, currentEndDate: currentEndDate, startDate: startDate, endDate: endDate });
          result = true;
          return true;
        }
      });
    }
    return (result && this.isDateRangeChange) ? true : false;
  }

  checkforOverlapping(currentScheduleTimingArray, scheduleTimigTobeAdded) {
    const timeOverlapDetails = this.checkforTimeOverlapping(currentScheduleTimingArray, scheduleTimigTobeAdded);
    const weekOverlapDetails = this.checkforWeekOverlapping(currentScheduleTimingArray, scheduleTimigTobeAdded);
    return (timeOverlapDetails.isTimeOverlap && weekOverlapDetails.isWeekOverlapping);
  }

  saveSchedule(index) {
    let scheduleTiming: ScheduleTiming[] = this.staffSchedule.scheduleTimings.get(this.days[index].name);
    this.days[index].timing.dayOfWeek = this.days[index].name;
    const isOverlap = this.checkforOverlapping(scheduleTiming, this.days[index].timing);
    const overlapInTime = false;
    if (this.timingMode === TimingMode.EDIT) {
      if (scheduleTiming && scheduleTiming.length > this.toEditTimingIndex) {
        scheduleTiming[this.toEditTimingIndex] = this.days[index].timing;
        this.resetDaysAtIndex(index);
      }
    } else if (this.timingMode === TimingMode.ADD) {
      if (!scheduleTiming) {
        scheduleTiming = [];
        this.staffSchedule.scheduleTimings.set(this.days[index].name, scheduleTiming);
        // console.log(this.staffSchedule.scheduleTimings.get());
      }
      if (!isOverlap) {
        this.isTimeOverlap = false;
        this.timeOverlapMsg = '';
        scheduleTiming.push(this.days[index].timing);
        this.resetDaysAtIndex(index);
      } else {
        this.isTimeOverlap = true;
      }
      /* console.log('fdfdgfdgfdg', scheduleTiming);
      const timingToAdd = this.days[index].timing;
      for (let timeIndex = 0; timeIndex < scheduleTiming.length; timeIndex++) {
        if ((timingToAdd.startTime >= scheduleTiming[timeIndex].startTime && timingToAdd.startTime < scheduleTiming[timeIndex].endTime) ||
          (timingToAdd.endTime > scheduleTiming[timeIndex].startTime && timingToAdd.endTime <= scheduleTiming[timeIndex].endTime) ||
          (timingToAdd.startTime <= scheduleTiming[timeIndex].startTime && timingToAdd.endTime >= scheduleTiming[timeIndex].endTime)) {
          // time overlap
          overlapInTime = true;
          const ampmCoverter = new TimeAMPMPipe();
          this.timeOverlapMsg = ampmCoverter.transform(scheduleTiming[timeIndex].startTime, []) + '-' +
            ampmCoverter.transform(scheduleTiming[timeIndex].endTime, []);
          break;
        }
      }
      if (overlapInTime) {
        // log error
        this.isTimeOverlap = true;
      } else {
        this.isTimeOverlap = false;
        this.timeOverlapMsg = '';
        scheduleTiming.push(this.days[index].timing);
      } */
    }
    // if (!overlapInTime) {
    //   this.resetDaysAtIndex(index);
    // }
  }

  cancelDaySchedule(index) {
    this.isTimeOverlap = false;
    this.timeOverlapMsg = '';
    this.currentDaySelection = -1;
  }

  cancelSchedule() {
    this.confirmationPopup.confirm({ message: Dictionary.CANCEL_CONFIRMATION }).subscribe(data => {
      if (data) {
        this.router.navigate(['clinic-view/clinics/' + this.authService.getClinicId() +
          '/facilities/' + this.facilityId + '/staffs/' + this.staffId + '/schedules']);
      }
    });
  }


  resetDaysAtIndex(index: number) {
    this.days[index].timing = new ScheduleTiming('10:00', '12:00', new WeekStatus(true, true, true, true, true));
    this.days[index].fromampm = 'AM';
    this.days[index].toampm = 'AM';
    this.currentDaySelection = -1;
  }

  getAMorPMForTime(time: string) {
    if (time.startsWith('0') || time.startsWith('10') || time.startsWith('11')) {
      return 'AM';
    } else {
      return 'PM';
    }
  }

  editSchedule(dayIndex: number, timing: ScheduleTiming, toEditTimingIndex: number) {
    this.timingMode = TimingMode.EDIT;
    this.toEditTimingIndex = toEditTimingIndex;
    const timingCopy = Object.assign({}, timing);
    timingCopy.monthWeekAvailablities = Object.assign({}, timing.monthWeekAvailablities);
    this.days[dayIndex].timing = timingCopy;
    this.days[dayIndex].toampm = this.getAMorPMForTime(timingCopy.startTime);
    this.days[dayIndex].fromampm = this.getAMorPMForTime(timingCopy.endTime);
    this.currentDaySelection = dayIndex;
  }

  addSchedule(dayIndex: number) {
    this.currentDaySelection = dayIndex;
    this.isTimeOverlap = false;
    this.timeOverlapMsg = '';
    this.timingMode = TimingMode.ADD;
  }

  addOrUpdateSchedule(mode) {
    if (mode === 'edit') {
      this.restapiservice
        .invoke<HTTPStaffSchedule>(APIEndPoint.UPDATE_STAFF_SCHEDULE_BY_ID,
          { clinicId: this.authService.getClinicId(), facilityId: this.facilityId, staffId: this.staffId, scheduleId: this.scheduleId },
          this.staffSchedule.toHTTPStaffSchedule()).takeUntil(this.unsubscribe).subscribe(schedule => {
            this.toaster.success(Dictionary.SCHEDULE_UPDATE);
            //  this.staffSchedule.scheduleTimings[index].push(schedule.scheduleTimings[0]);
            this.router.navigate(['clinic-view/clinics/' + this.authService.getClinicId() +
              '/facilities/' + this.facilityId + '/staffs/' + this.staffId + '/schedules']);
          }, err => {
            console.log(err);
            // this.router.navigate(['./clinic-view/add-doctor-schedule']);
          });
    } else {
      this.restapiservice
        .invoke<HTTPStaffSchedule>(APIEndPoint.CREATE_STAFF_SCHEDULE,
          { clinicId: this.authService.getClinicId(), facilityId: this.facilityId, staffId: this.staffId },
          this.staffSchedule.toHTTPStaffSchedule()).takeUntil(this.unsubscribe).subscribe(schedule => {
            this.toaster.success(Dictionary.SCHEDULE_ADD);
            //  this.staffSchedule.scheduleTimings[index].push(schedule.scheduleTimings[0]);
            this.router.navigate(['clinic-view/clinics/' + this.authService.getClinicId() +
              '/facilities/' + this.facilityId + '/staffs/' + this.staffId + '/schedules']);
          }, err => {
            console.log(err);
            // this.router.navigate(['./clinic-view/add-doctor-schedule']);
          });

    }
  }

  save() {
    const isOverlap = this.isDateRangeChange ?
      this.checkforDateRangeOverlapping(this.staffDateArray, this.staffSchedule.startDate, this.staffSchedule.endDate) : false;
    if (this.mode === 'edit') {
      if (isOverlap) {
        this.confirmationPopup.confirm({ message: Dictionary.OVERLAPPING_CONFIRMATION }).subscribe(data => {
          if (data) {
            this.addOrUpdateSchedule('edit');
          }
        });
      } else {
        this.addOrUpdateSchedule('edit');
      }
    } else {
      if (this.isDateRangeChange) {
        if (isOverlap) {
          this.confirmationPopup.confirm({ message: Dictionary.OVERLAPPING_CONFIRMATION }).subscribe(data => {
            if (data) {
              this.addOrUpdateSchedule('new');
            }
          });
        } else {
          this.addOrUpdateSchedule('new');
        }
      } else {
        this.hideAlert = true;
        // alert('please select the date range');
      }
    }
  }



  getSchedule(scheduleId: string) {
    try {
      this.restapiservice
        .invoke<HTTPStaffSchedule>(APIEndPoint.GET_STAFF_SCHEDULE_BY_ID,
          { clinicId: this.authService.getClinicId(), facilityId: this.facilityId, staffId: this.staffId, scheduleId: scheduleId })
        .takeUntil(this.unsubscribe).subscribe(schedule => {
          this.staffSchedule = StaffSchedule.fromHTTPStaffSchedule(schedule);
          this.isGetScheduleData = true;
          this.staffSchedule.startDate = schedule.startDate;
          this.staffSchedule.endDate = schedule.endDate;
          const startDate = schedule.startDate.split('-');
          const endDate = schedule.endDate.split('-');
          this.scheduleDateRange = {
            beginDate: { year: startDate[0], month: startDate[1].replace(/^0+/, ''), day: startDate[2].replace(/^0+/, '') },
            endDate: { year: endDate[0], month: endDate[1].replace(/^0+/, ''), day: endDate[2].replace(/^0+/, '') }
          };
        }, err => {
          console.log(err);
        });
    } catch (error) {
      console.log('gett some error', error);
    }

  }

  public onDateRangeChanged(date) {
    this.isDateRangeChange = true;
    console.log('current date', date);
    this.staffSchedule.startDate = `${date.beginDate.year}-${date.beginDate.month}-${date.beginDate.day}` ;
    this.staffSchedule.endDate = `${date.endDate.year}-${date.endDate.month}-${date.endDate.day}` ;
  }
  // ngOnInit() {
  //   for (let hour = 0; hour < 13; hour++) {
  //     for (let min = 0; min < 60; min += 15) {
  //       this.times.push((hour < 10 ? '0' + hour : hour) + ':' + (min < 10 ? '0' + min : min));
  //     }
  //   }
  //   Observable.combineLatest(this.activatedRoute.parent.params,
  //     this.activatedRoute.params,
  //     this.activatedRoute.queryParams).takeUntil(this.unsubscribe).subscribe(response => {
  //       this.facilityId = response[1]['facilityId'];
  //       this.staffId = response[1]['staffId'];
  //       this.mode = response[1]['action'];
  //       this.selectedDoc$ = this.getStaff(this.staffId);
  //       this.myDateRangePickerOptions = {
  //         disableUntil: { year: this.todayDate.getFullYear(), month: this.todayDate.getMonth() + 1, day: this.todayDate.getDate() - 1 },
  //         dateFormat: 'dd/mm/yyyy',
  //       };
  //       if (this.mode === 'edit') {
  //         this.scheduleId = response[1]['scheduleId'];
  //         this.getSchedule(this.scheduleId);
  //       }
  //     });
  // }

  // ngOnDestroy(): void {
  //   this.unsubscribe.complete();
  //   this.unsubscribe.unsubscribe();
  // }

}
