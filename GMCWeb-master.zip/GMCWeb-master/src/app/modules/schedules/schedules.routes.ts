import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainViewComponent } from 'app/modules/main-view/main-view.component';
import { LoginRouteGuardGuard } from 'app/core/auth/login-route-guard.guard';
import { SubscriptionRouteGuardGuard } from 'app/core/auth/subscription-route-guard.guard';
import { AgreementRouteGuardGuard } from 'app/core/auth/agreement-route-guard.guard';
import { DoctorScheduleComponent } from 'app/modules/schedules/doctor-schedule/doctor-schedule.component';
import { AddDoctorScheduleComponent } from 'app/modules/schedules/add-doctor-schedule/add-doctor-schedule.component';
import { AddUnavailibiltyComponent } from 'app/modules/schedules/add-unavailibilty/add-unavailibilty.component';



const SCHEDULES_ROUTES: Routes = [
    {
        path: 'clinic-view/clinics/:clinicId/facilities/:facilityId',
        component: MainViewComponent,
        canActivate: [LoginRouteGuardGuard, SubscriptionRouteGuardGuard, AgreementRouteGuardGuard],
        children: [
            { path: '', redirectTo: 'encounter/', pathMatch: 'full' },
            { path: 'staffs/:staffId/schedules', component: DoctorScheduleComponent },
            { path: 'staffs/:staffId/schedules/:action', component: AddDoctorScheduleComponent },
            { path: 'staffs/:staffId/schedules/:scheduleId/:action', component: AddDoctorScheduleComponent },
            { path: 'staffs/:staffId/unavailability', component: AddUnavailibiltyComponent }
        ]
    },

];

@NgModule({
    exports: [RouterModule],
    imports: [RouterModule.forChild(SCHEDULES_ROUTES)],
})

export class SchedulesRoutingModule { }
