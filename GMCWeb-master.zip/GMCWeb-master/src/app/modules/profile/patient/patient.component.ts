import { Component, OnInit, OnDestroy, HostListener, ViewEncapsulation } from '@angular/core';
import { RestapiService } from 'app/core/services/restapi.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Patient } from 'app/core/models/Patient';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { City } from 'app/core/models/city';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { Location, DatePipe } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { Appointment, AppointmentType } from 'app/core/models/app.models';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { Dictionary } from 'app/core/models/dictionary';
import { UtilityService } from 'app/core/services/utility.service';
import { BLOOD_GROUPS } from 'app/core/models/bloodGroup.list';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Country, DEFAULT_COUNTRY } from 'app/core/models/country';
import { DEFAULT_COUNTRY_CODE } from 'app/core/models/GlobalVariable';
import { AuthService } from 'app/core/auth/auth.service';
import { FileType } from 'app/core/models/FileType.list';
import { COUNTRY_CODE_LIST } from 'app/core/models/DialCodeList';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { PhoneValidator } from 'app/core/validators/phone.validator';
import { PostCode } from 'app/core/validators/postcode.validator';
import { Title } from 'app/core/models/Title.list';
import * as _ from 'lodash';

declare var $: any;
declare var window: any;

@Component({
  selector: 'app-patient',
  templateUrl: './patient.component.html',
  styleUrls: ['./patient.component.css'],
  providers: [DatePipe],
  encapsulation: ViewEncapsulation.None
})


export class PatientComponent implements OnInit, OnDestroy {
  next: any;
  clinicId: string;
  facilityId: string;
  doctorId: string;
  patientForm: FormGroup;
  patientAddressFormGroup: FormGroup;
  mode = 'add';
  selectedCity: City;
  selectedCountry: Country = DEFAULT_COUNTRY;
  patient$: Observable<Patient>;
  patientId: string;
  slot: string;
  date: string;
  unsubscribe = new Subject<void>();
  uploadFileSubject = new BehaviorSubject(false);
  selectedDocuments: Document[] = [];
  documentType = 'OTHERS';
  entityId: string;
  entityType = 'PATIENT';
  title = 'Mr';
  patientGetById: any;
  cities$: Observable<City>;
  countries$: Observable<Country>;
  patientFirstName: any;
  patientLastName: any;
  bloodGroups = BLOOD_GROUPS;
  isTitleChange = false;
  isAddressFilled = false;
  fromRoute: string;
  patientPhone: string;
  patientFN: string;
  patientLN: string;
  patientEmail: string;
  onlineId: string;
  appointmentType: string;
  from: string;
  pipe = new Date('en-US');
  formattedDate: any;
  countryDialCode = DEFAULT_COUNTRY_CODE;
  countryCode: any = 'in';
  isPhoneValid = false;
  validFileTypes: string[] = FileType;
  isZipCodeValid = true;
  isZipCodeRequired = true;
  dropdownOptions = {
    placeholder: 'Select City',
  };
  AUTH_TOKEN: any = '';
  postCodeValidator = new PostCode();
  TITLES = Title;
  isAddressValid: boolean;

  constructor(
    public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    private formBuilder: FormBuilder,
    public toastrService: ToastrService,
    private location: Location,
    private utilityservice: UtilityService,
    private datePipe: DatePipe,
    public confirmationPopup: ConfirmationPopupService,
    public authSerive: AuthService,
    public jwtHelperService: JwtHelperService
  ) {
    this.createForm();
  }


  @HostListener('window:beforeunload', ['$event'])
  public reloadPatient($event) {
    let hasChanges = false;
    if (this.patientForm.dirty) {
      hasChanges = true;
    }
    if (hasChanges) {
      $event.returnValue = Dictionary.LEAVE_PAGE_ALERT;
    }
  }


  ngOnInit() {
    this.setAuthToken();
    this.initComponent();
  }


  initComponent() {
    Observable.combineLatest(this.activatedRoute.parent.params,
      this.activatedRoute.params,
      this.activatedRoute.queryParams).takeUntil(this.unsubscribe).subscribe(params => {
        this.clinicId = params[0]['clinicId'];
        this.patientId = params[1]['patientId'];
        this.mode = params[1]['action'];
        this.slot = params[2]['slot'];
        this.next = params[2]['next'];
        this.date = params[2]['date'];
        this.facilityId = params[2]['facilityId'];
        this.doctorId = params[2]['doctorId'];
        this.fromRoute = params[2]['fromRoute'];
        this.patientFN = params[2]['patientFN'];
        this.patientLN = params[2]['patientLN'];
        this.patientPhone = params[2]['patientPhone'];
        this.patientEmail = params[2]['patientEmail'];
        this.onlineId = params[2]['onlineId'];
        this.appointmentType = params[2]['appointmentType'];
        this.from = params[2]['from'];
        this.formattedDate = this.datePipe.transform(this.date, 'dd-MM-yy');
        if (!this.AUTH_TOKEN.isVirtualClinic) {
          this.selectedCountry = DEFAULT_COUNTRY;
        }
        if (this.appointmentType === AppointmentType.ONLINE && this.mode === 'add') {
          this.patientForm.controls['firstName'].setValue(this.patientFN);
          this.patientForm.controls['lastName'].setValue(this.patientLN);
          this.patientForm.controls['email'].setValue(this.patientEmail);
          this.patientForm.controls['phone'].setValue(this.patientPhone);
        }
        // if (this.appointmentType === AppointmentType.ONLINE) {
        //   this.isPhoneValid = true;
        // }
        if (this.mode === 'edit') {
          this.getPatient();
        } else {
          this.getCountry();
          this.patient$ = Observable.of(<Patient>{});
        }
      });
  }


  getCountry() {
    this.restapiservice.invoke<Country>(APIEndPoint.GET_COUNTRIES).takeUntil(this.unsubscribe).subscribe((res: any) => {
      this.patientForm.controls['phone'].setValue(this.patientForm.controls['phone'].value);
      const countryCodeList = res.map(elem => elem.countryCode);
      this.getSelectedCountry(countryCodeList);
    });
  }


  getSelectedCountry(countryCodeList) {
    setTimeout(() => {
      $('#country-listbox li').each(function () {
        if (!countryCodeList.includes($(this).attr('data-dial-code'))) {
          $(this).addClass('hide');
        }
      }, 200);
    });
  }


  getPatient() {
    this.patient$ = this.restapiservice.invoke<Patient>(APIEndPoint.GET_PATIENT_BY_ID,
      { clinicId: this.clinicId, patientId: this.patientId })
      .map((patient: any) => {
        this.getCountry();
        this.isPhoneValid = true;
        if (patient.address === null) {
          patient.address = {
            address1: null,
            address2: null,
            addressType: null,
            city: null,
            zip: null
          };
        }
        this.patientForm.patchValue(patient);
        this.selectedDocuments = patient.document;
        this.patientForm.get('uhid').disable();
        this.getCountryCodeFromDialCode(patient.countryCode);
        this.selectedCountry = (patient.address && patient.address.country) ? patient.address.country : this.selectedCountry;
        return patient;
      });
  }


  getCountryCodeFromDialCode(countryCode) {
    if (countryCode) {
      const selectedCountryCode: any = COUNTRY_CODE_LIST.find(elem => elem.dialCode === countryCode);
      this.countryCode = selectedCountryCode.countryCode ? selectedCountryCode.countryCode : '91';
      this.updatePhoneValidation(this.countryCode);
    }
  }


  // formOnChanges() {
  //   this.patientForm.get('address').valueChanges.subscribe(val => {
  //     if (this.utilityservice.areAllFieldsNull(val.city)) {
  //       val.city = null;
  //     }
  //     if (this.utilityservice.areAllFieldsNull(val.country)) {
  //       val.country = null;
  //     }

  //     const ADDRESS = { ...val };
  //     delete ADDRESS.id;
  //     if (this.utilityservice.areAllFieldsNull(ADDRESS)) {
  //       this.isAddressFilled = false;
  //     } else {
  //       this.isAddressFilled = true;
  //     }
  //   });
  // }


  createForm() {
    this.patientForm = this.formBuilder.group({
      title: ['Mr', [Validators.required]],
      firstName: ['', Validators.compose([Validators.required, Validators.minLength(2), Validators.pattern('[a-zA-Z ]*')])],
      lastName: [null, Validators.compose([Validators.pattern('[a-zA-Z ]*')])],
      uhid: [null],
      age: ['',
        Validators.compose([Validators.required, Validators.pattern('^[0-9]{0,2}$|(^[1][0-5][0-9]$)')])
      ],
      email: [null, Validators.compose([Validators.pattern('[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}')])
      ],
      gender: ['M', Validators.compose([Validators.required])],
      occupation: [null, Validators.compose([Validators.pattern('[a-zA-Z ]*')])],
      bloodGroup: [null],
      passport: [null, /* this.authSerive.isVirtualClinic() ? Validators.required : null */],
      countryCode: [DEFAULT_COUNTRY_CODE, Validators.required],
      dob: ['', Validators.compose([Validators.required])],
      document: [[]],
      phone: ['', [Validators.required, PhoneValidator(this.selectedCountry.countryIATACode)]],
      alterPhone: [null, Validators.compose([PhoneValidator(this.selectedCountry.countryIATACode)])],
      address: this.formBuilder.group({
        id: null,
        address1: [null],
        address2: [null],
        city: [{
          id: null,
          name: null
        }],
        country: [{
          id: null,
          name: null,
          countryCode: null,
          countryISD: null,
        }],
        zip: [null]
      })
    });
  }


  setAuthToken() {
    this.AUTH_TOKEN = this.jwtHelperService.decodeToken(this.authSerive.getAuthToken());
  }
  setDOB(value) {
    const age = (new Date()).getFullYear() - value.data.getFullYear();
    this.patientForm.controls['dob'].setValue(value.data);
    this.patientForm.controls['age'].setValue(age);
  }

  // setCity(value) {
  //   this.patientForm.patchValue({ address: { city: value } });
  // }

  // resetCity() {
  //   this.patientForm.patchValue({ address: { city: null } });
  // }

  // setCountry(value) {
  //   this.selectedCountry = value.id ? value : null;
  //   this.resetCity();
  //   if (value.id) {
  //     this.patientForm.patchValue({ address: { country: value } });
  //     this.cities$ = this.restapiservice.invoke<City>(APIEndPoint.GET_CITIES, { countryId: this.selectedCountry.id });
  //   } else {
  //     this.patientForm.patchValue({ address: { country: null } });
  //   }
  //   if (this.selectedCountry) {
  //     this.updateZipValidation(this.selectedCountry.countryIATACode);
  //   } else {
  //     this.updateZipValidation(null);
  //   }
  // }

  setCountryCode(event) {
    this.patientForm.patchValue({ countryCode: event.dialCode });
    const selectedCountryCode: any = COUNTRY_CODE_LIST.find(elem => elem.dialCode === event.dialCode);
    this.countryCode = selectedCountryCode.countryCode ? selectedCountryCode.countryCode : 'in';
    this.updatePhoneValidation(this.countryCode.toUpperCase());
  }

  setTitle(title) {
    this.patientForm.get('title').setValue(title);
  }


  setPatientAddress(address: FormGroup) {
    this.patientAddressFormGroup = address;
  }
  updatePhoneValidation(countryIATACode) {
    const phoneControl = this.patientForm.get('phone');
    phoneControl.setValidators([Validators.required, PhoneValidator(countryIATACode)]);
    phoneControl.setValue(phoneControl.value);

    const alternatePhoneControl = this.patientForm.get('alterPhone');
    alternatePhoneControl.setValidators([PhoneValidator(countryIATACode)]);
    alternatePhoneControl.setValue(alternatePhoneControl.value);
  }

  // updateZipValidation(countryIATACode) {
  //   const zip = this.getAddress.get('zip');
  //   zip.setValidators([this.postCodeValidator.valid(countryIATACode)]);
  //   zip.setValue(zip.value);
  // }

  uploadStarted(count) {
    this.uploadFileSubject.next(true);
  }

  uploadEnded(documents: Document[]) {
    this.uploadFileSubject.next(false);
    console.log('Document', this.selectedDocuments);
  }


  createPatient(patientObj) {
    this.restapiservice
      .invoke<Patient>(APIEndPoint.CREATE_PATIENT,
        { clinicId: this.clinicId }, patientObj).subscribe(patient => {
          this.patientId = patient.id;
          this.patientFirstName = patient.firstName;
          this.patientLastName = patient.lastName;
          this.toastrService.success(Dictionary.SUCCESSFUL_REGISTRATION({ EntityName: this.patientFirstName }));
          if (this.doctorId && this.facilityId) {
            const patientAppointment = {
              appointmentDate: this.date,
              appointmentStatus: 'CONFIRMED',
              startTime: this.slot,
              patient: {
                id: this.patientId,
              },
              onlineId: this.onlineId,
            };
            if (this.mode === 'add-walkin-patient') {
              this.createWalinAppointment();
            } else {
              this.createPatientAppointment(patient, patientAppointment);
              if (this.from === 'ENCOUNTER') {
                this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId +
                  '/doctors/' + this.doctorId + '/encounters']);
              } else {
                this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId +
                  '/doctors/' + this.doctorId + '/appointments/view'], { queryParams: { patientAppointment } });
              }
            }
          } else {
            this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/patients']);
          }
        }, error => {
          this.toastrService.error('some error occured');
        }
        );
  }

  createWalinAppointment() {
    this.restapiservice.invoke<Appointment>(APIEndPoint.CREATE_WALKIN_APPOINTMENT, {
      clinicId: this.clinicId,
      facilityId: this.facilityId,
      doctorId: this.doctorId,
      patientId: this.patientId
    }).subscribe(app => {
      if (this.fromRoute === 'encounter') {
        console.log('walkin', app);
        this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId +
          '/doctors/' + this.doctorId + '/encounters']);
      } else if (this.fromRoute === 'appointment') {
        this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId +
          '/doctors/' + this.doctorId + '/appointments/view']);
      }
    });
  }

  createPatientAppointment(patientDetails: Patient, patientAppointentDetails: Appointment) {
    this.restapiservice
      .invoke<Appointment>(APIEndPoint.CREATE_APPOINTMENT,
        { clinicId: this.clinicId, facilityId: this.facilityId, doctorId: this.doctorId }, patientAppointentDetails)
      .subscribe(() => {
        if (patientDetails.lastName === null || patientDetails.lastName === '' || patientDetails.lastName === undefined) {
          this.toastrService.success(Dictionary.APPOINTMENT_CONFIRMATION({
            EntityName: patientDetails.firstName,
            Date: this.formattedDate, Slot: this.slot
          }));
        } else {
          this.toastrService.success(Dictionary.APPOINTMENT_CONFIRMATION({
            EntityName: patientDetails.firstName + patientDetails.lastName,
            Date: this.formattedDate, Slot: this.slot
          }));
        }
      });
  }

  updatePatient(patientObj) {
    this.restapiservice
      .invoke<Patient>(APIEndPoint.UPDATE_PATIENT,
        { clinicId: this.clinicId, patientId: this.patientId }, patientObj).subscribe(patient => {
          this.toastrService.success(Dictionary.SUCCESSFUL_UPDATION({ EntityName: patient.firstName }));
          // this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/profile-list/facilities/' + this.facilityId +
          //   '/patient-list'],
          if (this.doctorId && this.from === 'appointment') {
            this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId +
              '/doctors/' + this.doctorId + '/appointments/view']);
          } else if (this.doctorId && this.from === 'encounter') {
            this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId +
              '/doctors/' + this.doctorId + '/encounters']);
          } else {
            this.location.back();
          }
        }, error => {
          this.toastrService.error(error.errorMessages[0]);
        });
  }



  get getAddress() {
    return this.patientForm.controls.address as FormGroup;
  }

  get addressCountryCode() {
    return (this.getAddress.controls.country.value.countryCode);
  }

  validateAddress(address) {
    if (this.utilityservice.areAllFieldsNull(address.city)) {
      address.city = null;
    }
    if (this.utilityservice.areAllFieldsNull(address.country)) {
      address.country = null;
    }
    if (this.utilityservice.areAllFieldsNull(address.city) &&
      this.utilityservice.areAllFieldsNull(address.city) && (address.address1 === null || address.address1 === '') &&
      (address.zip === null || address.zip === '')) {
      address = null;
    }

    if (!this.AUTH_TOKEN.isVirtualClinic && this.isAddressFilled) {
      this.patientForm.patchValue({ address: { country: this.selectedCountry } });
      address.country = this.selectedCountry;
    }
    return address;
  }

  savePatient() {
    // this.patientForm.controls.address = this.patientAddressFormGroup;
    const patientDetails = this.patientForm.getRawValue();
    this.patientForm.controls['title'].setValue(this.title);
    this.patientForm.controls['document'] = new FormControl(this.selectedDocuments);
    patientDetails.address = this.validateAddress(patientDetails.address);
    patientDetails.phone = patientDetails.phone.replace(/ +/g, '');

    if (this.mode === 'add' || this.mode === 'add-walkin-patient') {
      this.createPatient(patientDetails);
    } else if (this.mode === 'edit') {
      this.updatePatient(patientDetails);
    }

  }

  cancel() {
    this.confirmationPopup.confirm({ message: Dictionary.CANCEL_CONFIRMATION }).subscribe(data => {
      if (data) {
        this.location.back();
      }
    });
  }

  goBack() {
    const confirmPopup = confirm(Dictionary.CANCEL_CONFIRMATION);
    if (confirmPopup) {
      this.location.back();
    }
  }


  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}

