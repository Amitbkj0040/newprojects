import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { Facility } from 'app/core/models/app.models';
import { RestapiService } from 'app/core/services/restapi.service';
import { Router, ActivatedRoute } from '@angular/router';
import { APIEndPoint, APIDef } from 'app/core/models/ApiEndPoint';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { AuthService } from 'app/core/auth/auth.service';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { ToastrService } from 'ngx-toastr';
import { Dictionary } from 'app/core/models/dictionary';
import { Country, DEFAULT_COUNTRY } from 'app/core/models/country';
import { UtilityService } from 'app/core/services/utility.service';
import { parsePhoneNumberFromString } from 'libphonenumber-js';
import { PhoneValidator } from 'app/core/validators/phone.validator';
import { PostCode } from 'app/core/validators/postcode.validator';
import { PostCodeValidatorService } from 'app/core/services/post-code-validator.service';
import * as _ from 'lodash';

@Component({
  selector: 'app-facility-profile',
  templateUrl: './facility-profile.component.html',
  styleUrls: ['./facility-profile.component.css']
})
export class FacilityProfileComponent implements OnInit, OnDestroy {
  clinicId: string;
  facilityId: string;
  apiSP: APIDef = APIEndPoint.GET_SPECIALITIES;
  facility$: Observable<Facility>;
  unsubscribe = new Subject<void>();
  facilityForm: FormGroup;
  selectedSpecialities: Object[] = [];
  selectedCountry: Country = DEFAULT_COUNTRY;
  AUTH_TOKEN: any = '';
  isAddressFilled = false;
  mode = 'add';
  postCodeValidator = new PostCode();
  isAddressValid: boolean;

  constructor(
    public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    public toastrService: ToastrService,
    private formBuilder: FormBuilder,
    public authService: AuthService,
    public jwtHelper: JwtHelperService,
    public confirmationPopup: ConfirmationPopupService,
    private utilityservice: UtilityService,
    private postCodeValidatorService: PostCodeValidatorService,
  ) {
    this.createForm();
  }


  ngOnInit() {
    this.AUTH_TOKEN = this.getToken();
    this.initComponent();
  }

  initComponent() {
    Observable.combineLatest(this.activatedRoute.parent.params,
      this.activatedRoute.params).takeUntil(this.unsubscribe).subscribe(response => {
        this.clinicId = response[0]['clinicId'];
        this.facilityId = response[1]['facilityId'];
        this.mode = response[1]['action'];
        if (!this.AUTH_TOKEN.isVirtualClinic) {
          this.selectedCountry = DEFAULT_COUNTRY;
        }
        if (this.mode !== 'add') {
          this.getFacilityById(this.facilityId);
        } else {
          this.facility$ = Observable.of(<Facility>{});
        }
      });
  }

  getFacilityById(facilityId) {
    this.facility$ = this.restapiservice.invoke<Facility>(APIEndPoint.GET_FACILITY_BY_ID,
      { clinicId: this.clinicId, facilityId })
      .map(facility => {
        this.facilityForm.patchValue(facility);
        this.selectedSpecialities = facility.specialities;
        if (facility.address && facility.address.country) {
          this.selectedCountry = facility.address.country;
          this.updatePhoneValidation(this.selectedCountry.countryIATACode);
        }
        return facility;
      });
  }

  getToken() {
    return this.jwtHelper.decodeToken(this.authService.getAuthToken());
  }

  onCountryChange(country) {
    this.selectedCountry = country && country.id ? country : null;
    if (country) {
      this.updatePhoneValidation(country.countryIATACode);
    }
  }

  updatePhoneValidation(countryIATACode) {
    const phoneControl = this.facilityForm.get('phone');
    phoneControl.setValidators([Validators.required, PhoneValidator(countryIATACode)]);
    phoneControl.setValue(phoneControl.value);

    const alternatePhoneControl = this.facilityForm.get('alternatephone');
    alternatePhoneControl.setValidators([PhoneValidator(countryIATACode)]);
    alternatePhoneControl.setValue(alternatePhoneControl.value);
  }

  public createFacility(facilityDetails) {
    this.restapiservice
      .invoke<Facility>(
        APIEndPoint.CREATE_FACILITY,
        { clinicId: this.clinicId }, facilityDetails).subscribe(facility => {
          const facilityName = facility.name;
          this.selectedSpecialities = facility.specialities;
          this.toastrService.success(Dictionary.SUCCESSFUL_REGISTRATION({ EntityName: facilityName }));
          this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/facilities']);
        }, error => {
          console.log('error during facility creation', error);
          this.toastrService.error(Dictionary.ERROR_MSG);
        });
  }


  public updateFacility(facilityDetails) {
    this.restapiservice
      .invoke<Facility>(
        APIEndPoint.UPDATE_FACILITY,
        { clinicId: this.clinicId, facilityId: this.facilityId }, facilityDetails).subscribe(facility => {
          this.toastrService.success(Dictionary.SUCCESSFUL_UPDATION({ EntityName: facility.name }));
          this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/facilities']);
        }, error => {
          console.log('error during facility updation', error);
          this.toastrService.error(Dictionary.ERROR_MSG);
        });
  }

  validateAddress(address) {
    if (this.utilityservice.areAllFieldsNull(address.city)) {
      address.city = null;
    }
    if (this.utilityservice.areAllFieldsNull(address.country)) {
      address.country = null;
    }
    if (this.utilityservice.areAllFieldsNull(address.city) &&
      this.utilityservice.areAllFieldsNull(address.city) && (address.address1 === null || address.address1 === '') &&
      (address.zip === null || address.zip === '')) {
      address = null;
    }

    if (!this.AUTH_TOKEN.isVirtualClinic && this.isAddressFilled) {
      this.facilityForm.patchValue({ address: { country: this.selectedCountry } });
      address.country = this.selectedCountry;
    }
    return address;
  }


  public saveFacility() {
    this.facilityForm.controls['specialities'] = new FormControl(this.selectedSpecialities);
    const facilityDetails = this.facilityForm.getRawValue();
    facilityDetails.address = this.validateAddress(facilityDetails.address);
    if (this.mode === 'add' || this.mode === 'register') {
      this.createFacility(facilityDetails);
    } else {
      this.updateFacility(facilityDetails);
    }
  }

  validateZipCode(countryCode, zipCde) {
    return this.postCodeValidatorService.validate(countryCode, zipCde);
  }

  phoneValidator(phone, countryCode: any) {
    if (phone) {
      const phoneNumber = parsePhoneNumberFromString(phone, countryCode);
      if (phoneNumber && phoneNumber.isValid()) {
        console.log('phone number is valid');
      } else {
        console.log('phone number is not valid');
      }
    }
  }

  @HostListener('window:beforeunload', ['$event'])
  public reloadFacility($event) {
    let hasChanges = false;
    if (this.facilityForm.dirty) {
      console.log('dirtyyyy');
      hasChanges = true;
    }
    if (hasChanges) {
      $event.returnValue = Dictionary.LEAVE_PAGE_ALERT;
    }
  }

  cancel() {
    this.confirmationPopup.confirm({ message: Dictionary.CANCEL_CONFIRMATION }).subscribe(data => {
      if (data) {
        this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/facilities']);
      }
    });
  }



  selectCity(data) {
    console.log(data);
  }

  createForm() {
    this.facilityForm = this.formBuilder.group({
      name: ['', Validators.compose([Validators.minLength(2), Validators.required])],
      specialities: this.formBuilder.array([this.formBuilder.group({
        id: '',
        name: '',
        description: ''
      })]),
      phone: ['', Validators.compose([Validators.required, PhoneValidator(this.selectedCountry.countryIATACode)])],
      alternatephone: [null, Validators.compose([PhoneValidator(this.selectedCountry.countryIATACode)])],
      description: ['', Validators.compose([Validators.minLength(10), Validators.maxLength(50), Validators.required])],
      email: [null, Validators.compose([Validators.pattern('[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}')])],
      document: this.formBuilder.array([]),
      address: this.formBuilder.group({
        id: '',
        address1: ['', Validators.required],
        address2: [null],
        city: [{
          id: '',
          name: ''
        }, Validators.required],
        country: [{
          id: null,
          name: null,
          countryCode: null,
          countryISD: null,
        }],
        zip: ['', Validators.compose([this.postCodeValidator.valid(this.selectedCountry.countryIATACode)])],
        locality: [null],
      })
    });
  }



  get address() {
    return this.facilityForm.controls['address'] as FormGroup;
  }


  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

}


