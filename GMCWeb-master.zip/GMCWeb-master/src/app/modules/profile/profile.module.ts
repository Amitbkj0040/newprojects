import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { PatientComponent } from 'app/modules/profile/patient/patient.component';
import { ProfileComponent } from 'app/modules/profile/profile.component';
import { FacilityProfileComponent } from 'app/modules/profile/facility-profile/facility-profile.component';
import { DoctorProfileComponent } from 'app/modules/profile/doctor-profile/doctor-profile.component';
import { StaffProfileComponent } from 'app/modules/profile/staff-profile/staff-profile.component';
import { MyProfileComponent } from 'app/modules/profile/my-profile/my-profile.component';
import { ProfileRoutingModule } from 'app/modules/profile/profile.routes';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    ProfileRoutingModule
  ],
  declarations: [
    PatientComponent,
    ProfileComponent,
    FacilityProfileComponent,
    StaffProfileComponent,
    DoctorProfileComponent,
    MyProfileComponent,
  ]
})
export class ProfileModule { }
