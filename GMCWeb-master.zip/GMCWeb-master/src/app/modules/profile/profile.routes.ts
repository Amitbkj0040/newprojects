import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainViewComponent } from 'app/modules/main-view/main-view.component';
import { LoginRouteGuardGuard } from 'app/core/auth/login-route-guard.guard';
import { SubscriptionRouteGuardGuard } from 'app/core/auth/subscription-route-guard.guard';
import { AgreementRouteGuardGuard } from 'app/core/auth/agreement-route-guard.guard';
import { MyProfileComponent } from 'app/modules/profile/my-profile/my-profile.component';
import { PatientComponent } from 'app/modules/profile/patient/patient.component';
import { FacilityProfileComponent } from 'app/modules/profile/facility-profile/facility-profile.component';
import { DoctorProfileComponent } from 'app/modules/profile/doctor-profile/doctor-profile.component';
import { StaffProfileComponent } from 'app/modules/profile/staff-profile/staff-profile.component';





const PROFILE_ROUTES: Routes = [
    {
        path: 'profile-view/clinics/:clinicId',
        component: MainViewComponent,
        canActivate: [LoginRouteGuardGuard, SubscriptionRouteGuardGuard, AgreementRouteGuardGuard],
        children: [
            { path: '', redirectTo: '', pathMatch: 'full' },
            { path: 'myprofile/:action', component: MyProfileComponent },
        ]
    },
    {
        path: 'clinic-view/clinics/:clinicId',
        component: MainViewComponent,
        canActivate: [LoginRouteGuardGuard, SubscriptionRouteGuardGuard, AgreementRouteGuardGuard],
        children: [
            { path: 'patients/:action', component: PatientComponent },
            { path: 'patients/:patientId/:action', component: PatientComponent },
        ]
    },
    {
        path: 'clinics/:clinicId/facilities/:action',
        component: FacilityProfileComponent,
        canActivate: [LoginRouteGuardGuard, SubscriptionRouteGuardGuard, AgreementRouteGuardGuard]

    },
    {
        path: 'manage-view/clinics/:clinicId',
        component: MainViewComponent,
        canActivate: [LoginRouteGuardGuard, SubscriptionRouteGuardGuard, AgreementRouteGuardGuard],
        children: [
            { path: '', redirectTo: 'facility', pathMatch: 'full' },
            { path: 'myprofile', component: MyProfileComponent },
            { path: 'facilities/:action', component: FacilityProfileComponent },
            { path: 'facilities/:facilityId/:action', component: FacilityProfileComponent },
            { path: 'staffs/:action', component: StaffProfileComponent },
            { path: 'staffs/:staffId/:action', component: StaffProfileComponent },
            { path: 'doctors/:action', component: DoctorProfileComponent },
            { path: 'doctors/:doctorId/:action', component: DoctorProfileComponent },
        ]
    },

];

@NgModule({
    exports: [RouterModule],
    imports: [RouterModule.forChild(PROFILE_ROUTES)],
})

export class ProfileRoutingModule { }
