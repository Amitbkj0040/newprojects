import { Component, OnInit, ElementRef, ViewEncapsulation } from '@angular/core';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { FormBuilder, FormGroup, Validators, FormControl, FormGroupName } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Router } from '@angular/router';
import { RestapiService } from 'app/core/services/restapi.service';
import { Observable } from 'rxjs/Observable';
import { Doctor } from 'app/core/models/app.models';
import { IMyDpOptions } from 'mydatepicker';
import { Subject } from 'rxjs/Subject';
import { APIEndPoint, APIDef } from 'app/core/models/ApiEndPoint';
import { AuthService } from 'app/core/auth/auth.service';
import { UtilityService } from 'app/core/services/utility.service';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { AddStaff } from 'app/core/models/app.models';
import { City } from 'app/core/models/city';
import { Speciality } from 'app/core/models/speciality';
import { ProfileService } from 'app/core/services/profile.service';
import { Dictionary } from 'app/core/models/dictionary';
import { Country, DEFAULT_COUNTRY } from 'app/core/models/country';
import { PostCodeValidatorService } from 'app/core/services/post-code-validator.service';
import { COUNTRY_CODE_LIST } from 'app/core/models/DialCodeList';
import { DEFAULT_COUNTRY_CODE } from 'app/core/models/GlobalVariable';
import { PhoneValidator } from 'app/core/validators/phone.validator';

declare var $: any;

@Component({
  selector: 'app-my-profile',
  templateUrl: './my-profile.component.html',
  styleUrls: ['./my-profile.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class MyProfileComponent implements OnInit {
  public doctorview = false;
  public myDatePickerOptions: IMyDpOptions = {
    // other options...
    dateFormat: 'yyyy-mm-dd',
  };
  apiPE: APIDef = APIEndPoint.GET_PHYSICALEXAMS;
  selectedPhysicalExams: any[] = [];
  public sign = 'abc';
  private unsubscribe = new Subject<void>();
  doctorForm: FormGroup;
  staffForm: FormGroup;
  mode = 'view';
  public mydate: any;
  public clinicId: string;
  public doctor$: Observable<Doctor>;
  public staff$: Observable<AddStaff>;
  public specialities$: Observable<Speciality>;
  public doctorId: string;
  public staffId: string;
  public title = 'Mr';
  public staffType: string;
  public isCalShow = false;
  public cities$: Observable<City>;
  public countries$: Observable<Country>;
  selectedCountry: Country = DEFAULT_COUNTRY;
  cityApiEndPoint = APIEndPoint.GET_CITIES;
  public defaultCityValue = '-';
  public defaultPhysicalExam = 'Select Physical Exams';
  public profileImg = 'assets/img/avatar.png';
  public uploadedProfileImage: any;
  public genderList = ['Male', 'Female', 'TG'];
  public showChangePasswordModal = false;
  public isDisable = false;
  public isRequesting = false;
  public viewemail: string;
  public isRequired = false;
  public hasProfilePicture = false;
  public isAddressFilled = false;
  public isAddRequired = false;
  public staffLoginName;
  public doctorLoginName;
  isZipCodeValid = true;
  isZipCodeRequired = true;
  AUTH_TOKEN: any = '';

  countryCode: any = 'in';
  isPhoneValid = false;
  isAddressValid: boolean;

  constructor(public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    public toastrService: ToastrService,
    private authService: AuthService,
    private jwtHelper: JwtHelperService,
    private formBuilder: FormBuilder,
    private elemRef: ElementRef,
    private utilityservice: UtilityService,
    public profileService: ProfileService,
    private postCodeValidatorService: PostCodeValidatorService,
    public confirmationPopup: ConfirmationPopupService,
    public jwtHelperService: JwtHelperService) {
    this.createStaffForm();
    this.createDoctorForm();
  }


  private setSpeciality(value) {
    console.log('speciality value', value);
    this.doctorForm.patchValue({ specialistIn: value });
  }
  setDOB(value) {
    this.staffForm.controls['dob'].setValue(value.data);
    if (value.self) {
      const age = (new Date()).getFullYear() - value.data.getFullYear();
      this.staffForm.controls['age'].setValue(age);
    }
  }
  setDoctorDOB(value) {
    this.doctorForm.controls['dob'].setValue(value.data);
    if (value.self) {
      const age = (new Date()).getFullYear() - value.data.getFullYear();
      this.doctorForm.controls['age'].setValue(age);
    }
  }

  ngOnInit() {
    this.AUTH_TOKEN = this.jwtHelperService.decodeToken(this.authService.getAuthToken());
    this.getSpeciality();
    this.initComponent();

  }

  initComponent() {
    Observable.combineLatest(this.activatedRoute.parent.params,
      this.activatedRoute.params).takeUntil(this.unsubscribe).subscribe(params => {
        this.clinicId = params[0]['clinicId'];
        this.mode = params[1]['action'];
        if (!this.AUTH_TOKEN.isVirtualClinic) {
          this.selectedCountry = DEFAULT_COUNTRY;
        }
        // const token = this.jwtHelper.decodeToken(this.authService.getAuthToken());
        if (this.authService.isUserDoctor()) {
          this.doctorId = this.authService.getStaffId();
          this.doctorview = true;
          this.getDoctor();
        } else {
          this.staffId = this.authService.getStaffId();
          this.getStaff();
        }
      });
  }

  getCountry() {
    this.restapiservice.invoke<Country>(APIEndPoint.GET_COUNTRIES).takeUntil(this.unsubscribe).subscribe((res: any) => {
      const countryCodeList = res.map(elem => elem.countryCode);
      this.doctorForm.controls['phone'].setValue(this.doctorForm.controls['phone'].value);
      this.staffForm.controls['phone'].setValue(this.staffForm.controls['phone'].value);
      this.getSelectedCountry(countryCodeList);
    });
  }

  getSpeciality() {
    this.specialities$ = this.restapiservice.invoke<Speciality>(APIEndPoint.GET_SPECIALITIES);
  }

  getDoctor() {
    this.doctor$ = this.restapiservice.invoke<Doctor>(APIEndPoint.GET_DOCTOR_BY_ID,
      { clinicId: this.clinicId, doctorId: this.doctorId })
      .map((doctor: any) => {
        this.getCountry();
        if (this.mode === 'view') {
          this.doctorForm.disable();
          this.isDisable = true;
          this.isRequired = false;
          this.defaultCityValue = '-';
          this.defaultPhysicalExam = '-';
        } else if (this.mode === 'edit') {
          this.isPhoneValid = true;
          this.doctorForm.enable();
          this.isDisable = false;
          this.defaultCityValue = 'Select City';
          this.defaultPhysicalExam = 'Select Physical Exams';
          this.isRequired = true;
        }
        if (doctor.address === null) {
          doctor.address = {
            address1: null,
            address2: null,
            country: null,
            addressType: null,
            city: null,
            zip: null
          };
        }
        this.doctorLoginName = (doctor.user && doctor.user.loginName) ? doctor.user.loginName : '';
        this.doctorForm.patchValue(doctor);
        this.viewemail = doctor.email;
        this.selectedCountry = (doctor.address && doctor.address.country) ? doctor.address.country : this.selectedCountry;
        this.selectedPhysicalExams = doctor.metaVitals;
        this.getCountryCodeFromDialCode(doctor.countryCode, true);
        if (doctor.logo) {
          this.profileImg = doctor.logo;
          this.hasProfilePicture = true;
          this.profileService.setImage(doctor.logo);
        } else {
          this.hasProfilePicture = false;
        }
        return doctor;
      });
  }

  getStaff() {
    this.staff$ = this.restapiservice.invoke<AddStaff>(APIEndPoint.GET_SUPPORT_STAFF_BY_ID,
      { clinicId: this.clinicId, staffId: this.staffId })
      .map((staff: any) => {
        this.getCountry();
        this.staffType = staff.staffType;
        if (this.mode === 'view') {
          this.staffForm.disable();
          this.defaultCityValue = '-';
          this.isDisable = true;
        } else if (this.mode === 'edit') {
          this.isPhoneValid = true;
          this.staffForm.enable();
          this.defaultCityValue = 'Select City';
          this.isDisable = false;
        }
        if (staff.address === null) {
          staff.address = {
            address1: null,
            address2: null,
            country: null,
            addressType: null,
            city: null,
            zip: null
          };
          // this.staffForm.controls['address'] = new FormControl(null);
        }
        this.staffLoginName = staff.user.loginName;
        this.staffForm.patchValue(staff);
        this.selectedCountry = (staff.address && staff.address.country) ? staff.address.country : this.selectedCountry;
        this.getCountryCodeFromDialCode(staff.countryCode, false);
        this.viewemail = staff.email;
        if (staff.logo) {
          this.profileImg = staff.logo;
          this.hasProfilePicture = true;
          this.profileService.setImage(staff.logo);
          console.log('profile staff', this.profileService.profileImg);
        } else {
          this.hasProfilePicture = false;
        }
        return staff;
      });
  }

  getCountryCodeFromDialCode(countryCode, doctorForm = true) {
    if (countryCode) {
      const selectedCountryCode: any = COUNTRY_CODE_LIST.find(elem => elem.dialCode === countryCode);
      this.countryCode = selectedCountryCode.countryCode ? selectedCountryCode.countryCode : '91';
      const formGroup: FormGroup = doctorForm ? this.doctorForm : this.staffForm;
      this.updatePhoneValidation(this.countryCode, formGroup);
    }
  }


  setCountryCode(event, doctorForm = true) {
    const selectedCountryCode: any = COUNTRY_CODE_LIST.find(elem => elem.dialCode === event.dialCode);
    this.countryCode = selectedCountryCode.countryCode ? selectedCountryCode.countryCode : 'in';
    const formGroup: FormGroup = doctorForm ? this.doctorForm : this.staffForm;
    formGroup.patchValue({ countryCode: event.dialCode });
    this.updatePhoneValidation(this.countryCode.toUpperCase(), formGroup);
  }

  updatePhoneValidation(countryIATACode, formGroup: FormGroup) {
    const phoneControl = formGroup.get('phone');
    phoneControl.setValidators([Validators.required, PhoneValidator(countryIATACode)]);
    phoneControl.setValue(phoneControl.value);

    const alternatePhoneControl = formGroup.get('alterPhone');
    alternatePhoneControl.setValidators([PhoneValidator(countryIATACode)]);
    alternatePhoneControl.setValue(alternatePhoneControl.value);
  }

  private phoneIsValid(event) {
    this.isPhoneValid = event;
  }

  getSelectedCountry(countryCodeList) {
    setTimeout(() => {
      $('#country-listbox li').each(function () {
        if (!countryCodeList.includes($(this).attr('data-dial-code'))) {
          $(this).addClass('hide');
        }
      }, 1000);
    });
  }

  changeProfileImage(event) {
    if (event.target.value) {
      this.isRequesting = true;
      this.uploadedProfileImage = event;
    }
  }

  uploadProfile(event) {
    this.isRequesting = false;
    if (event) {
      const partialText = event['partialText'];
      this.profileImg = JSON.parse(partialText)['fileDownloadUri'];
      this.profileService.setImage(this.profileImg);
    }
    // this.userForm.controls['logo'] = new FormControl(event);
  }

  editProfile() {
    this.router.navigate(['/profile-view/clinics/' + this.clinicId + '/myprofile/edit']);
  }
  cancelProfile() {
    this.router.navigate(['/profile-view/clinics/' + this.clinicId + '/myprofile/view']);
  }

  validateAddress(address, formGroup: FormGroup) {
    if (this.utilityservice.areAllFieldsNull(address.city)) {
      address.city = null;
    }
    if (this.utilityservice.areAllFieldsNull(address.country)) {
      address.country = null;
    }
    if (this.utilityservice.areAllFieldsNull(address.city) &&
      this.utilityservice.areAllFieldsNull(address.city) && (address.address1 === null || address.address1 === '') &&
      (address.zip === null || address.zip === '')) {
      address = null;
    }

    if (!this.AUTH_TOKEN.isVirtualClinic && this.isAddressFilled) {
      formGroup.patchValue({ address: { country: this.selectedCountry } });
      address.country = this.selectedCountry;
    }
    return address;
  }

  updateProfile() {
    if (this.doctorview) {
      this.updateDoctor();
    } else {
      this.updateStaff();
    }
  }

  updateDoctor() {
    this.doctorForm.controls['alterPhone']
      .setValue(this.doctorForm.getRawValue().alterPhone ? this.doctorForm.getRawValue().alterPhone : null);
    this.doctorForm.controls['logo'] = new FormControl(this.profileImg);
    this.doctorForm.controls['metaVitals'] = new FormControl(this.selectedPhysicalExams);
    const doctorDetails = this.doctorForm.getRawValue();
    doctorDetails.address = this.validateAddress(doctorDetails.address, this.doctorForm);
    doctorDetails.email = doctorDetails.email ? doctorDetails.email : null;
    doctorDetails.phone = doctorDetails.phone.replace(/ +/g, '');
    this.restapiservice
      .invoke<Doctor>(APIEndPoint.UPDATE_DOCTOR,
        { clinicId: this.clinicId, doctorId: this.doctorId }, doctorDetails).subscribe(doctor => {
          this.selectedPhysicalExams = doctor.metaVitals;
          this.toastrService.success(Dictionary.SUCCESSFUL_UPDATION({ EntityName: doctor.firstName }));
          this.router.navigate(['/profile-view/clinics/' + this.clinicId + '/myprofile/view']);
        }, error => {
          this.toastrService.error(Dictionary.ERROR_MSG);
        });
  }

  updateStaff() {
    this.staffForm.controls['alterPhone']
      .setValue(this.staffForm.getRawValue().alterPhone ? this.staffForm.getRawValue().alterPhone : null);
    this.staffForm.controls['logo'] = new FormControl(this.profileImg);
    const staffDetails = this.staffForm.getRawValue();
    staffDetails.address = this.validateAddress(staffDetails.address, this.staffForm);
    staffDetails.email = staffDetails.email ? staffDetails.email : null;
    staffDetails.phone = staffDetails.phone.replace(/ +/g, '');
    this.restapiservice
      .invoke<AddStaff>(APIEndPoint.UPDATE_SUPPORT_STAFF,
        { clinicId: this.clinicId, staffId: this.staffId }, staffDetails).subscribe(staff => {
          console.log('stafff', staff);
          this.toastrService.success(Dictionary.SUCCESSFUL_UPDATION({ EntityName: staff.firstName }));
          this.router.navigate(['/profile-view/clinics/' + this.clinicId + '/myprofile/view']);
        }, error => {
          this.toastrService.error(Dictionary.ERROR_MSG);
        });
  }
  validateZipCode(countryCode, zipCde) {
    return this.postCodeValidatorService.validate(countryCode, zipCde);
  }


  createStaffForm() {
    this.staffForm = this.formBuilder.group({
      title: [this.title, [Validators.required]],
      staffType: [this.staffType, [Validators.required]],
      firstName: ['', Validators.compose([Validators.required, Validators.minLength(2), Validators.pattern('[a-zA-Z ]*')])],
      lastName: [null, Validators.compose([Validators.pattern('[a-zA-Z ]*')])],
      email: [null, Validators.compose([Validators.pattern('[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}')])],
      gender: [null, [Validators.required]],
      occupation: [null, Validators.compose([Validators.pattern('[a-zA-Z ]*')])],
      credential: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9\s!@#$%^&*()_-]{8,20}$/)])],
      bloodGroup: [null],
      loginName: [null],
      signature: [this.sign],
      document: this.formBuilder.array([]),
      logo: [null],
      dob: ['', Validators.compose([Validators.required])],
      age: ['', Validators.compose([Validators.minLength(2), Validators.maxLength(3),
      Validators.pattern('(^[2-9][0-9]$)|(^[1][0-5][0-9]$)')])],
      phone: ['', Validators.compose([Validators.required, PhoneValidator(this.countryCode.toUpperCase())])],
      countryCode: [DEFAULT_COUNTRY_CODE, Validators.required],
      alterPhone: [null, Validators.compose([PhoneValidator(this.countryCode.toUpperCase())])],
      address: this.formBuilder.group({
        id: null,
        address1: ['', Validators.required],
        address2: [null],
        city: [{
          id: '',
          name: ''
        }, Validators.required],
        country: [{
          id: null,
          name: null,
          countryCode: null,
          countryISD: null,
        }, Validators.required],
        zip: ['', Validators.compose([Validators.required])]
      })
    });
  }

  createDoctorForm() {
    this.doctorForm = this.formBuilder.group({
      title: [''],
      staffType: ['DOCTOR', [Validators.required]],
      age: ['', Validators.compose([Validators.minLength(2), Validators.maxLength(3),
      Validators.pattern('(^[2-9][0-9]$)|(^[1][0-5][0-9]$)')])],
      firstName: ['', Validators.compose([Validators.required, Validators.minLength(2), Validators.pattern('[a-zA-Z ]*')])],
      lastName: [null, Validators.compose([Validators.pattern('[a-zA-Z ]*')])],
      email: [null, Validators.compose([Validators.pattern('[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}')])],
      gender: [null, [Validators.required]],
      practiceLicense: ['', Validators.required],
      qualification: [null],
      occupation: [null, Validators.compose([Validators.pattern('[a-zA-Z ]*')])],
      bloodGroup: [null],
      loginName: [null],
      signature: [this.sign],
      logo: [null],
      credential: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9\s!@#$%^&*()_-]{8,20}$/)])],
      specialistIn: [{
        id: '',
        name: '',
        description: ''
      }, Validators.required],
      metaVitals: this.formBuilder.array([this.formBuilder.group({
        id: '',
        name: '',
        unit: ''
      })]),
      dob: ['', Validators.compose([Validators.required])],
      document: this.formBuilder.array([]),
      phone: ['', Validators.compose([Validators.required, PhoneValidator(this.countryCode)])],
      alterPhone: [null, Validators.compose([PhoneValidator(this.countryCode)])],
      countryCode: [DEFAULT_COUNTRY_CODE, Validators.required],
      address: this.formBuilder.group({
        id: null,
        address1: [null, Validators.required],
        address2: [null],
        city: [{
          id: null,
          name: null
        }, Validators.compose([Validators.required])],
        country: [{
          id: null,
          name: null,
          countryCode: null,
          countryISD: null,
        }, Validators.required],
        zip: ['', Validators.compose([Validators.required])]
      })
    });

  }

  get AddressForm() {
    return (this.doctorForm.controls['address']) as FormGroup;
  }
  get staffAddressForm() {
    return (this.staffForm.controls['address']) as FormGroup;
  }

  isFormValid() {
    if (this.AddressForm.controls['city'].value !== null &&
      this.AddressForm.controls['address1'].value !== null &&
      this.AddressForm.controls['city'].value.id &&
      this.AddressForm.controls['city'].valid) {
      return true;
    } else {
      return false;
    }
  }


}
