import { Component, HostListener, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { IMyDpOptions } from 'mydatepicker';
import { ToastrService } from 'ngx-toastr';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { BehaviorSubject } from '../../../../../node_modules/rxjs';
import { AuthService } from 'app/core/auth/auth.service';
import { APIDef, APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Doctor, Document } from 'app/core/models/app.models';
import { City } from 'app/core/models/city';
import { Dictionary } from 'app/core/models/dictionary';
import { BLOOD_GROUPS } from 'app/core/models/bloodGroup.list';
import { Speciality } from 'app/core/models/speciality';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { RestapiService } from 'app/core/services/restapi.service';
import { UniqueNameService } from 'app/core/services/unique-name.service';
import { UtilityService } from 'app/core/services/utility.service';
import { FileType } from 'app/core/models/FileType.list';
import { Country, DEFAULT_COUNTRY } from 'app/core/models/country';
import { PostCodeValidatorService } from 'app/core/services/post-code-validator.service';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { COUNTRY_CODE_LIST } from 'app/core/models/DialCodeList';
import { DEFAULT_COUNTRY_CODE } from 'app/core/models/GlobalVariable';
import { PhoneValidator } from 'app/core/validators/phone.validator';
import { Title } from 'app/core/models/Title.list';

declare var $: any;


@Component({
  selector: 'app-doctor-profile',
  templateUrl: './doctor-profile.component.html',
  styleUrls: ['./doctor-profile.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class DoctorProfileComponent implements OnInit, OnDestroy {

  public myDatePickerOptions: IMyDpOptions = {
    // other options...
    dateFormat: 'yyyy-mm-dd',
  };
  model;
  apiPE: APIDef = APIEndPoint.GET_PHYSICALEXAMS;
  selectedPhysicalExams: Object[] = [];
  private unsubscribe = new Subject<void>();
  doctorForm: FormGroup;
  mode = 'add';
  public mydate: any;
  public facilityId: string;
  public clinicId: string;
  public specialityDefaultIndex = 0;
  public doctor$: Observable<Doctor>;
  public doctorId: string;
  public title = 'Mr';
  public isTitleChange = false;
  public isCalShow = false;
  public sign = 'abc';
  public doctorGetById: any;
  public FileToUpload: File = null;
  // public filesToUpload: string[] = [];
  public uploadedNewFile: any;
  public cities$: Observable<City>;
  cityApiEndPoint = APIEndPoint.GET_CITIES;
  public specialities$: Observable<Speciality>;
  public bloodGroups = BLOOD_GROUPS;
  // public cityList = [{id: 1, name: 'Noida'}, {id: 2, name: 'Greater Noida'},
  // {id: 3, name: 'Ghaziabad'}];
  public genderList = ['Male', 'Female', 'TG'];
  public selectedCit: object;
  public actionMode: string;
  public showChangePasswordModal = false;
  documentType = 'OTHERS';
  entityId: string;
  entityType = 'DOCTOR';
  // public fileToUpload: File = null;
  // public filesToUpload: string[] = [];
  uploadInProgress: boolean;
  uploadFileSubject = new BehaviorSubject(false);
  uploadFileObservable$ = this.uploadFileSubject.asObservable();
  saveInProgress: boolean;
  selectedDocuments: Document[] = [];
  documentId: number;
  public isRequesting = false;
  public domainName: string;
  public isAdmin = false;
  public loginNameExists: boolean;
  public validFileType = FileType;
  ispracticelicencenull = false;
  apiLN: APIDef = APIEndPoint.GET_LOGIN_NAME;
  countries$: Observable<Country>;
  selectedCountry: Country = DEFAULT_COUNTRY;
  AUTH_TOKEN: any = '';
  isZipCodeValid = true;
  isZipCodeRequired = true;
  isAddressValid: boolean;
  public isAddressFilled = false;
  TITLES = Title;

  countryCode: any = 'in';
  isPhoneValid = false;

  constructor(public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    public toastrService: ToastrService,
    private formBuilder: FormBuilder,
    private utilityservice: UtilityService,
    public confirmationPopup: ConfirmationPopupService,
    private authservice: AuthService,
    private uniqueNameService: UniqueNameService,
    private postCodeValidatorService: PostCodeValidatorService,
    public jwtHelperService: JwtHelperService
  ) {
    this.createForm();
  }
  private setSpeciality(value) {
    console.log('speciality value', value);
    this.doctorForm.patchValue({ specialistIn: value });
  }

  setTitle(title) {
    this.doctorForm.get('title').setValue(title);
  }


  uploadStarted(count) {
    this.uploadFileSubject.next(true);
    // console.log('started', count);
  }

  uploadEnded(documents: Document[]) {
    // this.selectedDocuments = documents;
    this.uploadFileSubject.next(false);
    console.log('ended', this.selectedDocuments);
  }

  getSelectedCountry(countryCodeList) {
    setTimeout(() => {
      $('#country-listbox li').each(function () {
        if (!countryCodeList.includes($(this).attr('data-dial-code'))) {
          $(this).addClass('hide');
        }
      }, 500);
    });
  }

  isUserAdmin() {
    return this.authservice.isUserAdmin();
  }
  getLoginName(userName: string): Observable<boolean> {
    return this.uniqueNameService.getDomainOrLoginName({ 'userName': userName }, this.apiLN);
  }

  ngOnInit() {
    this.AUTH_TOKEN = this.jwtHelperService.decodeToken(this.authservice.getAuthToken());
    this.domainName = this.authservice.getdomainName();
    this.getSpeciality();
    Observable.combineLatest(this.activatedRoute.parent.params,
      this.activatedRoute.params).takeUntil(this.unsubscribe).subscribe(params => {
        this.clinicId = params[0]['clinicId'];
        this.doctorId = params[1]['doctorId'];
        this.facilityId = params[1]['facilityId'];
        this.mode = params[1]['action'];
        this.entityId = '8';
        if (!this.AUTH_TOKEN.isVirtualClinic) {
          this.selectedCountry = DEFAULT_COUNTRY;
        }
        if (this.mode !== 'add') {
          this.getDoctorDetails();
        } else {
          this.getCountry();
          this.doctor$ = Observable.of(<Doctor>{});
        }
      });

    this.formOnChnages();
  }

  getDoctorDetails() {
    this.doctor$ = this.restapiservice.invoke<Doctor>(APIEndPoint.GET_DOCTOR_BY_ID,
      { clinicId: this.clinicId, doctorId: this.doctorId })
      .map((doctor: any) => {
        this.isPhoneValid = true;
        console.log('GetDoctorId in Doctor', doctor.user);
        this.getCountry();
        if (doctor.address === null) {
          doctor.address = {
            address1: null,
            address2: null,
            addressType: null,
            city: null,
            zip: null
          };
          this.isAddressFilled = false;
        }
        this.doctorForm.patchValue(doctor);
        this.selectedPhysicalExams = doctor.metaVitals;
        if (doctor.practiceLicense === null) {
          this.ispracticelicencenull = true;
        }
        this.doctorForm.controls['loginName'].setValue(doctor.user.loginName.split('@')[0]);
        this.selectedDocuments = doctor.document;
        this.doctorForm.get('loginName').disable();
        this.getCountryCodeFromDialCode(doctor.countryCode);
        this.selectedCountry = (doctor.address && doctor.address.country) ? doctor.address.country : this.selectedCountry;
        if (doctor.user.isOwner === true) {
          this.isAdmin = true;
        } else {
          this.isAdmin = false;
        }
        return doctor;
      });
  }

  getCountry() {
    this.restapiservice.invoke<Country>(APIEndPoint.GET_COUNTRIES).takeUntil(this.unsubscribe).subscribe((res: any) => {
      const countryCodeList = res.map(elem => elem.countryCode);
      this.doctorForm.controls['phone'].setValue(this.doctorForm.controls['phone'].value);
      this.getSelectedCountry(countryCodeList);
    });
  }

  getSpeciality() {
    this.specialities$ = this.restapiservice.invoke<Speciality>(APIEndPoint.GET_SPECIALITIES);
  }

  getCountryCodeFromDialCode(countryCode) {
    if (countryCode) {
      const selectedCountryCode: any = COUNTRY_CODE_LIST.find(elem => elem.dialCode === countryCode);
      this.countryCode = selectedCountryCode.countryCode ? selectedCountryCode.countryCode : '91';
      this.updatePhoneValidation(this.countryCode.toUpperCase());
    }
  }


  @HostListener('window:beforeunload', ['$event'])
  public reloadDoctor($event) {
    let hasChanges = false;
    if (this.doctorForm.dirty) {
      console.log('dirtyyyy');
      hasChanges = true;
    }
    if (hasChanges) {
      $event.returnValue = Dictionary.LEAVE_PAGE_ALERT;
    }
  }

  cancel() {
    this.confirmationPopup.confirm({ message: Dictionary.CANCEL_CONFIRMATION }).subscribe(data => {
      if (data) {
        this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/doctors']);
      }
    });
  }


  setDOB(value) {
    const age = (new Date()).getFullYear() - value.data.getFullYear();
    this.doctorForm.controls['dob'].setValue(value.data);
    if (value.self) {
      this.doctorForm.controls['age'].setValue(age);
    }
    console.log('doctor details', this.doctorForm.getRawValue());
  }

  validateAddress(address) {
    if (this.utilityservice.areAllFieldsNull(address.city)) {
      address.city = null;
    }
    if (this.utilityservice.areAllFieldsNull(address.country)) {
      address.country = null;
    }
    if (this.utilityservice.areAllFieldsNull(address.city) &&
      this.utilityservice.areAllFieldsNull(address.city) && (address.address1 === null || address.address1 === '') &&
      (address.zip === null || address.zip === '')) {
      address = null;
    }

    if (!this.AUTH_TOKEN.isVirtualClinic && this.isAddressFilled) {
      this.doctorForm.patchValue({ address: { country: this.selectedCountry } });
      address.country = this.selectedCountry;
    }
    return address;
  }

  saveDoctor() {
    console.log('selected physical exams', this.selectedPhysicalExams);
    this.doctorForm.controls['metaVitals'] = new FormControl(this.selectedPhysicalExams);
    this.saveInProgress = true;
    this.isRequesting = true;
    const doctorDetails = this.doctorForm.getRawValue();
    doctorDetails.address = this.validateAddress(doctorDetails.address);
    doctorDetails.phone = doctorDetails.phone.replace(/ +/g, '');
    this.uploadFileObservable$.subscribe(uploadInProgress => {
      if (!uploadInProgress && this.saveInProgress) {
        this.saveInProgress = false;
        this.isRequesting = false;
        if (this.mode === 'add') {
          if (doctorDetails.credential === '' || doctorDetails.credential === null || doctorDetails.credential === undefined) {
            this.toastrService.error(Dictionary.PASSWORD_REQ);
          } else {
            this.createDoctor(doctorDetails);
          }
        } else {
          this.updateDoctor(doctorDetails);
        }
      }
    });
  }


  createDoctor(doctorObj) {
    if (!this.loginNameExists) {
      this.restapiservice
        .invoke<Doctor>(APIEndPoint.CREATE_DOCTOR,
          { clinicId: this.clinicId }, doctorObj).subscribe(doctor => {
            console.log('successfully added', doctor);
            this.selectedPhysicalExams = doctor.metaVitals;
            this.toastrService.success(Dictionary.SUCCESSFUL_REGISTRATION({ EntityName: doctor.firstName }));
            this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/doctors']);
          }, error => {
            this.toastrService.error(Dictionary.ERROR_MSG);
          });
    } else {
      this.showError();
    }
  }

  showError() {
    this.toastrService.error(Dictionary.LOGIN_NAME_EXIST);
  }

  updateDoctor(doctorObj) {
    this.restapiservice
      .invoke<Doctor>(APIEndPoint.UPDATE_DOCTOR,
        { clinicId: this.clinicId, doctorId: this.doctorId }, doctorObj).subscribe(doctor => {
          console.log('successfully added', doctor);
          this.toastrService.success(Dictionary.SUCCESSFUL_UPDATION({ EntityName: doctor.firstName }));
          this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/doctors']);
        }, error => {
          this.toastrService.error('some error occured');
        });
  }

  //     NullValidator(control: AbstractControl) {
  //       debugger
  //       return control.value === '' ? null :  control.value ;
  // }
  createForm() {
    this.doctorForm = this.formBuilder.group({
      title: [this.title, [Validators.required]],
      staffType: ['DOCTOR', [Validators.required]],
      age: [null, Validators.compose([/*Validators.required  */, Validators.minLength(2), Validators.maxLength(3),
        Validators.pattern('(^[2-9][0-9]$)|(^[1][0-5][0-9]$)')])],
      firstName: ['', Validators.compose([Validators.required,
      Validators.minLength(2), Validators.pattern('[a-zA-Z ]*')])],
      lastName: [null, Validators.compose([Validators.pattern('[a-zA-Z ]*')])],
      email: [null, Validators.compose([Validators.pattern('[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}')])],
      gender: [null, Validators.required],
      practiceLicense: [null, Validators.required],
      qualification: [null],
      occupation: [null, Validators.compose([Validators.pattern('[a-zA-Z ]*')])],
      bloodGroup: [null],
      signature: [this.sign],
      loginName: [null],
      logo: [null],
      credential: ['', Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9\s!@#$%^&*()_-]{8,20}$/)])],
      specialistIn: [{
        id: '',
        name: '',
        description: ''
      }, Validators.required],
      metaVitals: this.formBuilder.array([this.formBuilder.group({
        id: '',
        name: '',
        unit: ''
      })]),
      dob: [null, Validators.compose([/*Validators.required  */])],
      document: [[]],
      phone: ['', Validators.compose([Validators.required, PhoneValidator(this.countryCode)])],
      alterPhone: [null, [PhoneValidator(this.countryCode)]],
      countryCode: [DEFAULT_COUNTRY_CODE, Validators.required],
      address: this.formBuilder.group({
        id: null,
        address1: [null, Validators.required],
        address2: [null],
        city: [{
          id: null,
          name: null
        }],
        country: [{
          id: null,
          name: null,
          countryCode: null,
          countryISD: null,
        }],
        zip: [null]
      })
    });
  }

  setCountryCode(event) {
    this.doctorForm.patchValue({ countryCode: event.dialCode });
    const selectedCountryCode: any = COUNTRY_CODE_LIST.find(elem => elem.dialCode === event.dialCode);
    this.countryCode = selectedCountryCode.countryCode ? selectedCountryCode.countryCode : 'in';
    this.updatePhoneValidation(this.countryCode.toUpperCase());
  }

  updatePhoneValidation(countryIATACode) {
    const phoneControl = this.doctorForm.get('phone');
    phoneControl.setValidators([Validators.required, PhoneValidator(countryIATACode)]);
    phoneControl.setValue(phoneControl.value);

    const alternatePhoneControl = this.doctorForm.get('alterPhone');
    alternatePhoneControl.setValidators([PhoneValidator(countryIATACode)]);
    alternatePhoneControl.setValue(alternatePhoneControl.value);
  }
  formOnChnages() {
    this.doctorForm.get('metaVitals').valueChanges.subscribe(val => {
      console.log('phyexm', val);
    });
    this.doctorForm.controls['loginName'].valueChanges.debounceTime(400)
      .switchMap(term => this.getLoginName(term)).subscribe(resp => { this.loginNameExists = resp; },
        err => { this.loginNameExists = false; });
  }

  get address() {
    return this.doctorForm.get('address') as FormGroup;
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
