import { Component, OnInit, OnDestroy, HostListener, ViewEncapsulation } from '@angular/core';
import { RestapiService } from 'app/core/services/restapi.service';
import { Router, ActivatedRoute } from '@angular/router';
import { AddStaff } from 'app/core/models/app.models';
import { APIEndPoint, APIDef } from 'app/core/models/ApiEndPoint';
import { FormGroup, Validators, FormBuilder, FormControl } from '@angular/forms';
import { City } from 'app/core/models/city';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { Dictionary } from 'app/core/models/dictionary';
import { UtilityService } from 'app/core/services/utility.service';
import { Document } from 'app/core/models/app.models';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { AuthService } from 'app/core/auth/auth.service';
import { UniqueNameService } from 'app/core/services/unique-name.service';
import { BLOOD_GROUPS } from 'app/core/models/bloodGroup.list';
import { FileType } from 'app/core/models/FileType.list';
import { Country, DEFAULT_COUNTRY } from 'app/core/models/country';
import { PostCodeValidatorService } from 'app/core/services/post-code-validator.service';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { COUNTRY_CODE_LIST } from 'app/core/models/DialCodeList';
import { DEFAULT_COUNTRY_CODE } from 'app/core/models/GlobalVariable';
import { PhoneValidator } from 'app/core/validators/phone.validator';
import { Title } from 'app/core/models/Title.list';
declare var $: any;

@Component({
  selector: 'app-staff-profile',
  templateUrl: './staff-profile.component.html',
  styleUrls: ['./staff-profile.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class StaffProfileComponent implements OnInit, OnDestroy {
  isTitleChange = false;
  staffForm: FormGroup;
  mode = 'add';
  public facilityId: string;
  clinicId: string;
  actionMode: string;
  public staff$: Observable<AddStaff>;
  public city: any = {};
  public staffId: string;
  cliniId: any;
  public title = 'Mr';
  public sign = 'abc';
  public staffGetById: any;
  public cities$: Observable<City>;
  cityApiEndPoint = APIEndPoint.GET_CITIES;
  private unsubscribe = new Subject<void>();
  public bloodGroups = BLOOD_GROUPS;
  public showChangePasswordModal = false;
  documentType = 'OTHERS';
  entityType = 'STAFF';
  uploadInProgress: boolean;
  uploadFileSubject = new BehaviorSubject(false);
  uploadFileObservable$ = this.uploadFileSubject.asObservable();
  saveInProgress: boolean;
  selectedDocuments: Document[] = [];
  public isRequesting = false;
  public isAddressFilled = false;
  public domainName: string;
  public isAdmin = false;
  public loginNameExists: boolean;
  apiLN: APIDef = APIEndPoint.GET_LOGIN_NAME;
  public validFileType = FileType;
  countries$: Observable<Country>;
  selectedCountry: Country;
  isZipCodeValid = true;
  isZipCodeRequired = true;
  AUTH_TOKEN: any = '';
  isAddressValid: boolean;
  TITLES = Title;

  countryCode: any = 'in';
  isPhoneValid = false;


  constructor(public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    public toastrService: ToastrService,
    private formBuilder: FormBuilder,
    private utilityservice: UtilityService,
    private authservice: AuthService,
    public confirmationPopup: ConfirmationPopupService,
    private uniqueNameService: UniqueNameService,
    private postCodeValidatorService: PostCodeValidatorService,
    public jwtHelperService: JwtHelperService) {
    this.createForm();
  }

  uploadStarted(count) {
    this.uploadFileSubject.next(true);
  }

  uploadEnded(documents: Document[]) {
    this.uploadFileSubject.next(false);
  }

  setDOB(value) {
    const age = (new Date()).getFullYear() - value.data.getFullYear();
    this.staffForm.controls['dob'].setValue(value.data);
    if (value.self) {
      this.staffForm.controls['age'].setValue(age);
    }
  }




  getLoginName(userName: string): Observable<boolean> {
    return this.uniqueNameService.getDomainOrLoginName({ 'userName': userName }, this.apiLN);
  }

  ngOnInit() {
    this.domainName = this.authservice.getdomainName();
    this.getAuthToken();
    Observable.combineLatest(this.activatedRoute.parent.params,
      this.activatedRoute.params).takeUntil(this.unsubscribe).subscribe(response => {
        this.clinicId = response[0]['clinicId'];
        this.staffId = response[1]['staffId'];
        this.facilityId = response[1]['facilityId'];
        this.mode = response[1]['action'];
        if (!this.AUTH_TOKEN.isVirtualClinic) {
          this.selectedCountry = DEFAULT_COUNTRY;
        }
        if (this.mode !== 'add') {
          this.getStaff();
        } else {
          this.getCountry();
          this.staff$ = Observable.of(<AddStaff>{});
        }
      });
    this.formOnChanges();
  }

  getAuthToken() {
    this.AUTH_TOKEN = this.jwtHelperService.decodeToken(this.authservice.getAuthToken());
  }

  getCountry() {
    this.restapiservice.invoke<Country>(APIEndPoint.GET_COUNTRIES).takeUntil(this.unsubscribe).subscribe((res: any) => {
      this.staffForm.controls['phone'].setValue(this.staffForm.controls['phone'].value);
      const countryCodeList = res.map(elem => elem.countryCode);
      this.getSelectedCountry(countryCodeList);
    });
  }

  getStaff() {
    this.staff$ = this.restapiservice.invoke<AddStaff>(APIEndPoint.GET_SUPPORT_STAFF_BY_ID,
      { clinicId: this.clinicId, staffId: this.staffId })
      .map((staff: any) => {
        this.isPhoneValid = true;
        if (staff.address === null) {
          staff.address = {
            address1: null,
            address2: null,
            addressType: null,
            city: null,
            zip: null
          };
        }
        this.staffForm.patchValue(staff);
        this.getCountryCodeFromDialCode(staff.countryCode);
        this.staffForm.controls['loginName'].setValue(staff.user.loginName.split('@')[0]);
        this.selectedDocuments = staff.document;
        this.selectedCountry = (staff.address && staff.address.country) ? staff.address.country : this.selectedCountry;
        this.staffForm.get('loginName').disable();
        this.getCountry();
        if (staff.user.isOwner === true) {
          this.isAdmin = true;
        } else {
          this.isAdmin = false;
        }
        return staff;
      });
  }

  getSelectedCountry(countryCodeList) {
    setTimeout(() => {
      $('#country-listbox li').each(function () {
        if (!countryCodeList.includes($(this).attr('data-dial-code'))) {
          $(this).addClass('hide');
        }
      }, 200);
    });
  }

  getCountryCodeFromDialCode(countryCode) {
    if (countryCode) {
      const selectedCountryCode: any = COUNTRY_CODE_LIST.find(elem => elem.dialCode === countryCode);
      this.countryCode = selectedCountryCode.countryCode ? selectedCountryCode.countryCode : '91';
      this.updatePhoneValidation(this.countryCode.toUpperCase());
    }
  }

  setTitle(title) {
    this.staffForm.get('title').setValue(title);
  }

  validateZipCode(countryCode, zipCde) {
    return this.postCodeValidatorService.validate(countryCode, zipCde);
  }

  setCountryCode(event) {
    this.staffForm.patchValue({ countryCode: event.dialCode });
    const selectedCountryCode: any = COUNTRY_CODE_LIST.find(elem => elem.dialCode === event.dialCode);
    this.countryCode = selectedCountryCode.countryCode ? selectedCountryCode.countryCode : 'in';
    this.updatePhoneValidation(this.countryCode.toUpperCase());
  }

  updatePhoneValidation(countryIATACode) {

    const phoneControl = this.staffForm.get('phone');
    phoneControl.setValidators([Validators.required, PhoneValidator(countryIATACode)]);
    phoneControl.setValue(phoneControl.value);

    const alternatePhoneControl = this.staffForm.get('alterPhone');
    alternatePhoneControl.setValidators([PhoneValidator(countryIATACode)]);
    alternatePhoneControl.setValue(alternatePhoneControl.value);
  }

  formOnChanges() {
    this.staffForm.controls['loginName'].valueChanges.debounceTime(400)
      .switchMap(term => this.getLoginName(term)).subscribe(resp => { this.loginNameExists = resp; },
        err => { this.loginNameExists = false; });
  }

  @HostListener('window:beforeunload', ['$event'])
  public reloadStaff($event) {
    if (this.staffForm.dirty) {
      $event.returnValue = true;
    }
  }

  cancel() {
    this.confirmationPopup.confirm({ message: Dictionary.CANCEL_CONFIRMATION }).subscribe(data => {
      if (data) {
        this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/staffs']);
      }
    });
  }

  validateAddress(address) {
    if (this.utilityservice.areAllFieldsNull(address.city)) {
      address.city = null;
    }
    if (this.utilityservice.areAllFieldsNull(address.country)) {
      address.country = null;
    }
    if (this.utilityservice.areAllFieldsNull(address.city) &&
      this.utilityservice.areAllFieldsNull(address.city) && (address.address1 === null || address.address1 === '') &&
      (address.zip === null || address.zip === '')) {
      address = null;
    }
    if (!this.AUTH_TOKEN.isVirtualClinic && this.isAddressFilled) {
      this.staffForm.patchValue({ address: { country: this.selectedCountry } });
      address.country = this.selectedCountry;
    }
    return address;
  }

  saveStaff() {
    this.saveInProgress = true;
    this.isRequesting = true;
    this.uploadFileObservable$.subscribe(uploadInProgress => {
      if (!uploadInProgress && this.saveInProgress) {
        this.saveInProgress = false;
        this.isRequesting = false;
        const staffDetails = this.staffForm.getRawValue();
        staffDetails.address = this.validateAddress(staffDetails.address);
        staffDetails.phone = staffDetails.phone.replace(/ +/g, '');
        if (this.mode === 'add') {
          if (staffDetails.credential === '' || staffDetails.credential === null || staffDetails.credential === undefined) {
            this.toastrService.error(Dictionary.PASSWORD_REQ);
          } else {
            this.createStaff(staffDetails);
          }
        } else {
          this.updateStaff(staffDetails);
        }
      }
    });
  }



  createStaff(staffObject) {
    if (staffObject.credential === '' || staffObject.credential === undefined || staffObject.credential === null) {
      this.toastrService.error(Dictionary.PASSWORD_REQ);
    }
    if (!this.loginNameExists) {
      this.restapiservice
        .invoke<AddStaff>(APIEndPoint.CREATE_SUPPORT_STAFF,
          { clinicId: this.clinicId }, staffObject).subscribe(staff => {
            console.log('dsfdsdfsdfd', staff.document);
            this.toastrService.success(Dictionary.SUCCESSFUL_REGISTRATION({ EntityName: staff.firstName }));
            this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/staffs']);
          }, error => {
            this.toastrService.error(Dictionary.ERROR_MSG);
          });
    } else {
      this.showError();
    }
  }
  showError() {
    this.toastrService.error(Dictionary.LOGIN_NAME_EXIST);
  }

  updateStaff(staffObject) {
    this.staffForm.get('loginName').disable();
    this.isAddressFilled = false;
    this.restapiservice
      .invoke<AddStaff>(APIEndPoint.UPDATE_SUPPORT_STAFF,
        { clinicId: this.clinicId, staffId: this.staffId }, staffObject).subscribe(staff => {
          this.toastrService.success(Dictionary.SUCCESSFUL_UPDATION({ EntityName: staff.firstName }));
          this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/staffs']);
        }, error => {
          this.toastrService.error(Dictionary.ERROR_MSG);
        });

  }



  createForm() {
    this.staffForm = this.formBuilder.group({
      title: [this.title, [Validators.required]],
      staffType: [null, [Validators.required]],
      firstName: ['',
        Validators.compose([Validators.required, Validators.minLength(2), Validators.pattern('[a-zA-Z ]*')])],
      lastName: [null, Validators.compose([Validators.pattern('[a-zA-Z ]*')])],
      email: [null,
        Validators.compose([Validators.pattern('[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}')])],
      gender: ['M', [Validators.required]],
      occupation: [null, Validators.compose([Validators.pattern('[a-zA-Z ]*')])],
      credential: ['',
        Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9\s!@#$%^&*()_-]{8,20}$/)])],
      bloodGroup: [null],
      loginName: [null],
      logo: [null],
      signature: [this.sign],
      dob: [null],
      age: [null, Validators.compose([Validators.minLength(2), Validators.maxLength(3),
      Validators.pattern('(^[2-9][0-9]$)|(^[1][0-5][0-9]$)')])],
      phone: ['', Validators.compose([Validators.required, PhoneValidator(this.countryCode)])],
      alterPhone: [null, PhoneValidator(this.countryCode)],
      countryCode: [DEFAULT_COUNTRY_CODE, Validators.required],
      address: this.formBuilder.group({
        id: null,
        address1: [null],
        address2: [null],
        city: [{
          id: null,
          name: null
        }],
        country: [{
          id: null,
          name: null,
          countryCode: null,
          countryISD: null,
        }],
        zip: [null]
      }),
      document: this.formBuilder.array([]),
    });
  }

  get address() {
    return this.staffForm.get('address') as FormGroup;
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
