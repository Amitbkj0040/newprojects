import { Component, OnInit, OnDestroy, HostListener } from '@angular/core';
import { RestapiService } from 'app/core/services/restapi.service';
import { Router, ActivatedRoute } from '@angular/router';
import { restapiUrl } from 'app/core/services/rest-api-variable';
import { APIEndPoint, APIDef } from 'app/core/models/ApiEndPoint';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { Observable } from 'rxjs/Observable';
import { tap } from 'rxjs/operators';
import { Subject } from 'rxjs/Subject';
import { AuthService } from 'app/core/auth/auth.service';
import { ToastrService } from 'ngx-toastr';
import { Dictionary } from 'app/core/models/dictionary';
import { ClinicAgreement } from 'app/core/models/clinicAgreement';

@Component({
  selector: 'app-registration-agreement',
  templateUrl: './registration-agreement.component.html',
  styleUrls: ['./registration-agreement.component.css']
})
export class RegistrationAgreementComponent implements OnInit {

  private unsubscribe = new Subject<void>();
  public isUnsigned: false;
  public clinicId: string;
  public staffId: string;
  public clinicAgreement: ClinicAgreement = {
    isAgreementSigned: false
  };


  constructor(public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    public toastrService: ToastrService,
    private formBuilder: FormBuilder,
    public authService: AuthService) { }

  ngOnInit() {
    this.clinicId = this.authService.getClinicId();
    this.staffId = this.authService.getStaffId();
    Observable.combineLatest(this.activatedRoute.params,
      this.activatedRoute.queryParams).takeUntil(this.unsubscribe).subscribe(response => {
        this.isUnsigned = response[1]['isUnsigned'];
      });
  }

  onAgreement() {
    console.log('isagreement', this.clinicAgreement);
    this.restapiservice
      .invoke<ClinicAgreement>(APIEndPoint.UPDATE_CLINIC_AGREEMENT,
        { clinicId: this.clinicId }, this.clinicAgreement).subscribe(resp => {
          console.log('successfully updated clinic agreement', resp);
          this.toastrService.success(Dictionary.SUCCESSFUL_UPDATION({ EntityName: 'Your clinic Agreement' }));
          if (this.authService.getFacilityId() === null) {
            this.router.navigate(['./clinic-view/' + this.clinicId + '/facility-registration']);
          } else if (this.authService.getFacilityId() !== null) {
            this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/facilities']);
          }
        }, error => {
          this.toastrService.error('some error occured');
        });
  }


}
