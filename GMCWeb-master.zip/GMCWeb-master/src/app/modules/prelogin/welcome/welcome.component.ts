import { Component, OnInit, OnDestroy } from '@angular/core';
import { AuthService } from 'app/core/auth/auth.service';
import { KeyType, StaffType } from 'app/core/models/app.models';
import { Router } from '@angular/router';
import { Subject } from 'rxjs/Subject';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { ToastrService } from 'ngx-toastr';
import { RestapiService } from 'app/core/services/restapi.service';
import { Dictionary } from 'app/core/models/dictionary';
import { Doctor } from 'app/core/models/app.models';
import 'rxjs/add/observable/forkJoin';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent implements OnInit, OnDestroy {
  public isLoginActive = true;
  public doctorId: string;
  private unsubscribe: Subject<void> = new Subject();
  login = {
    phone: null,
    password: null,
  };
  loginFailed = false;
  userProfile: object;
  isLoading = false;

  constructor(private authService: AuthService,
    private router: Router,
    private toasterService: ToastrService,
    private restapiservice: RestapiService,
    private jwtHelper: JwtHelperService) {
    // Tweak config for password flow
    // This is just needed b/c this demo uses both,
    // implicit flow as well as password flow
    // this.authService.configure(authPasswordFlowConfig);
    // this.authService.loadDiscoveryDocument();
  }



  userLogin() {
    console.log('Login', this.login);

  }

  get access_token() {
    return this.authService.getAuthToken();
  }

  get access_token_expiration() {
    return this.authService.getTokenExpirationDate();
  }

  //   get givenName() {
  //       const claims = this.authService.getIdentityClaims();
  //       if (!claims) { return null; }
  //       return claims['given_name'];
  //   }

  //   get familyName() {
  //       const claims = this.authService.getIdentityClaims();
  //       if (!claims) { return null; }
  //       return claims['family_name'];
  //   }

  public loginWithPassword() {
    this.isLoading = true;
    if (this.login.password === '' || this.login.password === null || this.login.password === undefined) {
      this.toasterService.error(Dictionary.PASSWORD_REQ);
    }
    if (this.login.phone === '' || this.login.phone === null || this.login.phone === undefined) {
      this.toasterService.error(Dictionary.PHONE_REQ);
    }
    this.authService.loginAndSetTokens(this.login.phone, this.login.password)
      .subscribe(
        data => {
          const token = this.jwtHelper.decodeToken(this.authService.getAuthToken());
          // this.router.navigate(['./clinic-view/' + token.clinic + '/facility-registration']);
          if (token.roles.includes(StaffType.ADMIN)) {
            if (!token.clinic) {
              this.router.navigate(['/clinics/add']);
            } else {
              if (!token.facilities) {
                this.router.navigate(['./clinic-view/' + token.clinic + '/facility-registration']);
              } else if (token.facilities) {
                this.router.navigate(['./manage-view/clinics/' + token.clinic + '/facilities']);
              } else {
                this.router.navigate(['/manage-view/clinics/' + token.clinic + '/facilities/add']);
              }
            }
          } else if (token.roles.includes(StaffType.DOCTOR)) {
            this.router.navigate(['/clinic-view/clinics/' + token.clinic + '/facilities/' + token.facilities[0] + '/doctors/'
              + token.staff + '/encounters']);
          } else if (token.roles.includes(StaffType.SUPPORT_STAFF)) {
            this.restapiservice.invoke<Doctor[]>(APIEndPoint.GET_DOCTORS,
              { clinicId: token.clinic, facilityId: token.facilities[0] }).takeUntil(this.unsubscribe).subscribe(resp => {
                console.log(resp);
                this.doctorId = resp[0].id;
                console.log(this.doctorId);
                this.router.navigate(['/clinic-view/clinics/' + token.clinic + '/facilities/' +
                  token.facilities[0] + '/doctors/' + this.doctorId + '/appointments/view']);
              });
          }
          this.isLoading = false;
        },
        err => {
          this.isLoading = false;
          if (err.error.error_description === 'Bad credentials') {
            this.toasterService.error(Dictionary.CREDENTIAL_ERROR);
          } else {
            this.toasterService.error(Dictionary.LOGIN_ERROR);
          }
        }
      );
  }

  public loginWithPasswordWithEnter(event) {
    if (event.keyCode === KeyType.KEY_ENTER) {
      this.loginWithPassword();
    }
  }

  initiateRegister() {
    this.isLoginActive = false;
  }
  forgotPassword() {
    this.router.navigate(['/prelogin/forgot-password']);
  }
  logout() {
    this.authService.logoutUser();
  }
  ngOnInit() {
  }
  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}

