import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Register } from 'app/core/models/register';
import { Otp } from 'app/core/models/otp';
import { RestapiService } from 'app/core/services/restapi.service';
import { AuthService } from 'app/core/auth/auth.service';
import { restapiUrl } from 'app/core/services/rest-api-variable';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { APIDef, APIInput } from 'app/core/models/ApiEndPoint';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Subject } from 'rxjs/Subject';
import { ToastrService } from 'ngx-toastr';
import { Dictionary } from 'app/core/models/dictionary';
import { PasswordValidation } from './passwordValidation';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
  forgotPasswordForm: FormGroup;
  public phonenumber: string;
  otpForm: FormGroup;
  private unsubscribe = new Subject<void>();
  isOtpSent = false;
  public otp: Otp = {
    otpFor: null
  };
  public register: Register = {
    isDoctor: false,
    id: null,
    phone: null,
    loginName: null,
    password: null,
    confirmPassword: null,
    otp: null,
    specialistIn: {
      name: null,
      description: null,
      id: null
    },
  };
  constructor(private router: Router,
    public restapiService: RestapiService,
    public toastrService: ToastrService,
    private formBuilder: FormBuilder,
    private toasterService: ToastrService,
    private restapiservice: RestapiService,
    private jwtHelper: JwtHelperService,
    private authService: AuthService) {
  }

  ngOnInit() {
    this.forgotPasswordForm = this.formBuilder.group({
      loginName: [this.phonenumber, Validators.compose([Validators.required, Validators.pattern('^[1-9][0-9]{9}$')])],
      otp: [this.register.otp, Validators.compose([Validators.required, Validators.pattern('[0-9]*')])],
      password: [this.register.password, Validators.compose([Validators.required,
      Validators.pattern(/^[a-zA-Z0-9\s!@#$%^&*()_-]{8,20}$/)])],
      confirmPassword: [this.register.confirmPassword, Validators.required],
    },
      {
        validator: PasswordValidation.MatchPassword
      });
    this.otpForm = this.formBuilder.group({
      otpFor: [this.otp.otpFor, [Validators.required]]
    });
  }

  sendOTP() {
    const formObj1 = this.otpForm.getRawValue();
    console.log('hello', formObj1);
    this.phonenumber = formObj1.otpFor;
    console.log(this.phonenumber);
    this.restapiService.invoke<Otp>(APIEndPoint.FORGET_PASSWORD, null, formObj1).subscribe(resp => {
      this.toastrService.success(Dictionary.OTP_SUCCESS);
      console.log('otp created successfully', resp);
      this.isOtpSent = true;
    }, (err) => {
      if (err.status === 404) {
        this.toastrService.error(Dictionary.UNREGISTERED_USER);
      }
    });
  }
  onSubmit() {
    if (this.isOtpSent) {
      this.forgotPasswordForm.controls['loginName'].setValue(this.phonenumber);
      const formObj = this.forgotPasswordForm.getRawValue();
      console.log('password', formObj);
      this.restapiService.invoke<Register>(APIEndPoint.RESET_PASSWORD, null, formObj).subscribe(response => {
        console.log('password-reset successful', response);
        this.toastrService.success(Dictionary.SUCCESSFUL_PASSWORD_RESET);
        this.router.navigate(['/prelogin/welcome']);
      });
    }
    // else {
    //   this.sendOTP();
    // }
  }

  public registerWithOtpWithEnter(event) {
    if (event.keyCode === 13) {
      this.sendOTP();
      console.log('loginName', event);
    }
  }
  registerWithPassword(event) {
    if (event.keyCode === 13) {
      this.onSubmit();
      console.log('phone', event);
    }
  }
  returnToLogin() {
    this.router.navigate(['/prelogin/welcome']);
  }
}
