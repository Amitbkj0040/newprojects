import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from 'app/modules/prelogin/login/login.component';
import { MainComponent } from 'app/modules/prelogin/main/main.component';
import { WelcomeComponent } from 'app/modules/prelogin/welcome/welcome.component';
import { OtpComponent } from 'app/modules/prelogin/otp/otp.component';
import { ForgotpasswordComponent } from 'app/modules/prelogin/forgotpassword/forgotpassword.component';
import { RegistrationAgreementComponent } from 'app/modules/prelogin/registration-agreement/registration-agreement.component';


const PRELOGIN_ROUTES: Routes = [
    {
        path: '',
        redirectTo: 'prelogin',
        pathMatch: 'full'
    },
    {
        path: 'prelogin',
        component: MainComponent,
        children: [
            { path: '', redirectTo: 'welcome', pathMatch: 'full' },
            { path: 'welcome', component: WelcomeComponent },
            { path: 'login', component: LoginComponent },
            { path: 'otp', component: OtpComponent },
            { path: 'forgot-password', component: ForgotpasswordComponent },
        ]
    },
    {
        path: 'agreement',
        component: RegistrationAgreementComponent
    },
];

@NgModule({
    exports: [RouterModule],
    imports: [RouterModule.forChild(PRELOGIN_ROUTES)],
})

export class PreloginRoutingModule { }
