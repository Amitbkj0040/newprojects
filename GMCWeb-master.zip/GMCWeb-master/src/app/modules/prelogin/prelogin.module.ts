import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PreloginRoutingModule } from 'app/modules/prelogin/prelogin.routes';
import { LoginComponent } from 'app/modules/prelogin/login/login.component';
import { MainComponent } from 'app/modules/prelogin/main/main.component';
import { WelcomeComponent } from 'app/modules/prelogin/welcome/welcome.component';
import { OtpComponent } from 'app/modules/prelogin/otp/otp.component';
import { ForgotpasswordComponent } from 'app/modules/prelogin/forgotpassword/forgotpassword.component';
import { RegistrationAgreementComponent } from 'app/modules/prelogin/registration-agreement/registration-agreement.component';
import { SharedModule } from 'app/shared/shared.module';



@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    PreloginRoutingModule,
    SharedModule
  ],
  declarations: [LoginComponent,
    MainComponent,
    WelcomeComponent,
    ForgotpasswordComponent,
    OtpComponent,
    RegistrationAgreementComponent,

  ]
})
export class PreloginModule { }
