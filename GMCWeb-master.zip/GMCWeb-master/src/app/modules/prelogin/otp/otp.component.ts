import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { Otp } from 'app/core/models/otp';
import { Register } from 'app/core/models/register';
import { RestapiService } from 'app/core/services/restapi.service';
import { AuthService } from 'app/core/auth/auth.service';
import { restapiUrl } from 'app/core/services/rest-api-variable';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { KeyType, StaffType } from 'app/core/models/app.models';
import { APIDef, APIInput } from 'app/core/models/ApiEndPoint';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { Subject } from 'rxjs/Subject';
import { ToastrService } from 'ngx-toastr';
import { Dictionary } from 'app/core/models/dictionary';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { Observable } from 'rxjs/Observable';
import { Speciality } from 'app/core/models/speciality';
import { THROW_IF_NOT_FOUND } from '@angular/core/src/di/injector';

@Component({
  selector: 'app-otp',
  templateUrl: './otp.component.html',
  styleUrls: ['./otp.component.css']
})
export class OtpComponent implements OnInit, OnDestroy {
  userForm: FormGroup;
  otpForm: FormGroup;
  public phonenumber: string;
  private unsubscribe = new Subject<void>();
  isOtpSent = false;
  public specialities$: Observable<Speciality>;
  public otp: Otp = {
    otpFor: null
  };
  public register: Register = {
    isDoctor: false,
    id: null,
    phone: null,
    loginName: null,
    password: null,
    confirmPassword: null,
    otp: null,
    specialistIn: {
      name: null,
      description: null,
      id: null
    },
  };
  login = {
    phone: null,
    password: null,
  };
  isMandatory = true;
  isPhoneNumber = true;
  apiEndPointSpeicality = APIEndPoint.GET_SPECIALITIES;

  constructor(private router: Router,
    public restapiService: RestapiService,
    public toastrService: ToastrService,
    private formBuilder: FormBuilder,
    private toasterService: ToastrService,
    private restapiservice: RestapiService,
    private jwtHelper: JwtHelperService,
    private authService: AuthService
  ) { }

  ngOnInit() {
    this.specialities$ = this.restapiservice.invoke<Speciality>(APIEndPoint.GET_SPECIALITIES);
    this.userForm = this.formBuilder.group({
      phone: [this.register.phone, Validators.compose([Validators.required, Validators.pattern(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/)])],
      // tslint:disable-next-line:max-line-length
      password: [this.register.password, Validators.compose([Validators.required, Validators.pattern(/^[a-zA-Z0-9\s!@#$%^&*()_-]{8,20}$/)])],
      otp: [this.register.otp, Validators.compose([Validators.required, Validators.pattern('[0-9]*')])],
      isDoctor: [this.register.isDoctor],
      countryCode: ['91'],
      specialistIn: [{
        id: this.register.specialistIn.id,
        name: this.register.specialistIn.name,
        description: this.register.specialistIn.description
      }, Validators.required],
    });
    this.otpForm = this.formBuilder.group({
      otpFor: [this.otp.otpFor, Validators.compose([Validators.required, Validators.pattern(/^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/)])]
    });
  }


  public loginWithPassword(phone, password) {
    if (password === '' || password === null || password === undefined) {
      this.toasterService.error(Dictionary.PASSWORD_REQ);
    }
    if (phone === '' || phone === null || phone === undefined) {
      this.toasterService.error(Dictionary.PHONE_REQ);
    }
    this.authService.loginAndSetTokens(phone, password)
      .subscribe(
        data => {
          const token = this.jwtHelper.decodeToken(this.authService.getAuthToken());
          if (token.roles.includes(StaffType.ADMIN)) {
            if (!token.clinic) {
              this.router.navigate(['/clinics/add']);
            } else {
              if (token.facilities) {
                this.router.navigate(['./manage-view/clinics/' + token.clinic + '/facilities']);
              } else {
                this.router.navigate(['/manage-view/clinics/' + token.clinic + '/facilities/add']);
              }
            }
          } else if (token.roles.includes(StaffType.DOCTOR)) {
            this.router.navigate(['/clinic-view/clinics/' + token.clinic + '/facilities/' + token.facilities[0] + '/doctors/'
              + token.staff + '/encounters']);
          } else if (token.roles.includes(StaffType.SUPPORT_STAFF)) {
            this.router.navigate(['/clinic-view/clinics/' + token.clinic + '/facilities/' + token.facilities[0] + '/appointments/view']);
          }
        },
        err => { this.toasterService.error('', Dictionary.LOGIN_ERROR); });
  }

  sendOTP() {
    const formObj1 = this.otpForm.getRawValue();
    console.log('hello', formObj1);
    this.phonenumber = formObj1.otpFor;
    !this.phonenumber ? this.isPhoneNumber = false : this.isPhoneNumber = true;
    console.log('number is', this.phonenumber);
    this.restapiService.invoke<Otp>(APIEndPoint.CREATE_OTP, null, formObj1).subscribe(resp => {
      this.toastrService.success(Dictionary.OTP_SUCCESS);
      console.log('otp created successfully', resp);
      this.isOtpSent = true;
    });

  }

  public registerWithOtpWithEnter(event) {
    if (event.keyCode === KeyType.KEY_ENTER) {
      this.sendOTP();
      console.log('phone', event);
    }
  }


  private selectSpeciality(value) {
    console.log('speciality value', value);
    this.userForm.patchValue({ specialistIn: value });
  }

  resetSpeciality() {
    this.userForm.patchValue({ specialistIn: null });
  }
  // onCheck(value) {
  //   this.otpDetails.agreement = value;
  // }
  onSubmit() {
    if (this.isOtpSent) {
      if (!this.userForm.controls['isDoctor'].value) {
        this.userForm.patchValue({ specialistIn: null });
      }
      this.userForm.controls['phone'].setValue(this.phonenumber);
      const formObj = this.userForm.getRawValue();
      console.log('otpppp', JSON.stringify(formObj));
      console.log('heloooooo', formObj.isDoctor);
      this.restapiService.invoke<Register>(APIEndPoint.CREATE_USER, null, formObj).subscribe(resp => {
        console.log('User registered successfully', formObj.phone, formObj.password);
        this.loginWithPassword(formObj.phone, formObj.password);
        this.toastrService.success(Dictionary.SUCCESSFUL_REGISTRATION({ EntityName: formObj.phone }));
      });
    }
    // else {
    //   this.sendOTP();
    // }
  }

  registerWithPassword(event) {
    if (event.keyCode === KeyType.KEY_ENTER) {
      this.onSubmit();
      console.log('phone', event);
    }
  }
  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
  returnToLogin() {
    this.router.navigate(['/prelogin/welcome']);
  }
}

