
import { Component, OnInit } from '@angular/core';
import { AuthService } from 'app/core/auth/auth.service';
import { Router } from '@angular/router';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  login = {
    phone: null,
    password: null,
  };
  loginFailed = false;
  userProfile: object;

  constructor(private authService: AuthService,
    private router: Router,
    private toasterService: ToastrService,
    private jwtHelper: JwtHelperService) {
    // Tweak config for password flow
    // This is just needed b/c this demo uses both,
    // implicit flow as well as password flow
    // this.authService.configure(authPasswordFlowConfig);
    // this.authService.loadDiscoveryDocument();
  }

  ngOnInit() {
  }

  userLogin() {
    console.log('Login', this.login);

  }

  get access_token() {
    return this.authService.getAuthToken();
  }

  get access_token_expiration() {
    return this.authService.getTokenExpirationDate();
  }

  //   get givenName() {
  //       const claims = this.authService.getIdentityClaims();
  //       if (!claims) { return null; }
  //       return claims['given_name'];
  //   }

  //   get familyName() {
  //       const claims = this.authService.getIdentityClaims();
  //       if (!claims) { return null; }
  //       return claims['family_name'];
  //   }

  loginWithPassword() {
    this.authService.loginAndSetTokens(this.login.phone, this.login.password)
      .subscribe(
        data => {
          const token = this.jwtHelper.decodeToken(this.authService.getAuthToken());
          if (token.roles.includes('ADMIN') && !token.clinic) {
            this.router.navigate(['clinic-registeration']);
          } else if (token.roles.includes('ADMIN') && !token.facilities) {

          } else {
            this.router.navigate([token.clinic, 'dashboard', 'encounter']);
          }
        },
        err => { this.toasterService.error('', 'Couldn\'t login now. Please try later.'); }
      );
    // .then(() => {
    //     console.debug('successfully logged in');
    //     this.loginFailed = false;
    // })
    // .catch((err) => {
    //     console.error('error logging in', err);
    //     this.loginFailed = true;
    // });
  }

  logout() {
    this.authService.logoutUser();
  }
}
