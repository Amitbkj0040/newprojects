import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { SubscriptionRoutingModule } from 'app/modules/subscription/subscription.routes';
import { SubscriptionDetailsComponent } from 'app/modules/subscription/subscription-details/subscription-details.component';
import { SubscriptionExpiredComponent } from 'app/modules/subscription/subscription-expired/subscription-expired.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    SubscriptionRoutingModule
  ],
  declarations: [SubscriptionDetailsComponent, SubscriptionExpiredComponent]
})
export class SubscriptionModule { }
