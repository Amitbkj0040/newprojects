import { Component, OnInit, OnDestroy } from '@angular/core';
import { RestapiService } from 'app/core/services/restapi.service';
import { Router, ActivatedRoute } from '@angular/router';
import { APIEndPoint, APIDef } from 'app/core/models/ApiEndPoint';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { AuthService } from 'app/core/auth/auth.service';
import { Subscription } from 'app/core/models/subscription';
import { ToastrService } from 'ngx-toastr';
import { Dictionary } from 'app/core/models/dictionary';


@Component({
  selector: 'app-subscription-expired',
  templateUrl: './subscription-expired.component.html',
  styleUrls: ['./subscription-expired.component.css']
})
export class SubscriptionExpiredComponent implements OnInit, OnDestroy {

  public clinicId: string;
  public subscriptions$: Observable<Subscription[]>;
  private unsubscribe = new Subject<void>();

  constructor(public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    public toastrService: ToastrService,
    public authService: AuthService) { }

  ngOnInit() {

    this.clinicId = this.authService.getClinicId();
    this.subscriptions$ = this.restapiservice.invoke<Subscription[]>(
      APIEndPoint.GET_ALL_SUBSCRIPTIONS,
      { clinicId: this.clinicId }, null, { isActive: 'false' }).map(resp => {
        console.log('resp from subscriptions', resp);
        return resp;
      });

  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

}
