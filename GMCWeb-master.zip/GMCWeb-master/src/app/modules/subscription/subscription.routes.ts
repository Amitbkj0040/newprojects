import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainViewComponent } from 'app/modules/main-view/main-view.component';
import { LoginRouteGuardGuard } from 'app/core/auth/login-route-guard.guard';
import { SubscriptionRouteGuardGuard } from 'app/core/auth/subscription-route-guard.guard';
import { AgreementRouteGuardGuard } from 'app/core/auth/agreement-route-guard.guard';
import { SubscriptionDetailsComponent } from 'app/modules/subscription/subscription-details/subscription-details.component';
import { SubscriptionExpiredComponent } from 'app/modules/subscription/subscription-expired/subscription-expired.component';



const SUBSCRIPTION_ROUTES: Routes = [
    {
        path: 'profile-view/clinics/:clinicId',
        component: MainViewComponent,
        canActivate: [LoginRouteGuardGuard, SubscriptionRouteGuardGuard, AgreementRouteGuardGuard],
        children: [
            { path: '', redirectTo: '', pathMatch: 'full' },
            { path: 'subscription-details', component: SubscriptionDetailsComponent },
        ]
    },
    {
        path: 'subscription',
        component: SubscriptionExpiredComponent,
    },
];

@NgModule({
    exports: [RouterModule],
    imports: [RouterModule.forChild(SUBSCRIPTION_ROUTES)],
})

export class SubscriptionRoutingModule { }
