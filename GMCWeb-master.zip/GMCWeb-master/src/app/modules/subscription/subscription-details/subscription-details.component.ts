import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RestapiService } from 'app/core/services/restapi.service';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'app/core/models/subscription';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';



@Component({
  selector: 'app-subscription-details',
  templateUrl: './subscription-details.component.html',
  styleUrls: ['./subscription-details.component.css']
})
export class SubscriptionDetailsComponent implements OnInit, OnDestroy {
  public clinicId: string;
  public subscriptions$: Observable<Subscription[]>;
  private unsubscribe = new Subject<void>();

  constructor(public router: Router,
    private restapiservice: RestapiService,
    public confirmationPopup: ConfirmationPopupService,
    private activatedRoute: ActivatedRoute) { }


  ngOnInit() {

    this.activatedRoute.parent.params.takeUntil(this.unsubscribe).subscribe(response => {
      console.log('hello', response);
      this.clinicId = response['clinicId'];
      this.subscriptions$ = this.restapiservice.invoke<Subscription[]>(
        APIEndPoint.GET_ALL_SUBSCRIPTIONS,
        { clinicId: this.clinicId }, null, { isActive: 'true' }).map(resp => {
          console.log('resp from subscriptions', resp);
          return resp;
        });

    });
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

}
