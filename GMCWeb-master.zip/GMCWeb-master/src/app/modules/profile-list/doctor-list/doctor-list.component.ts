import { Component, OnInit, OnDestroy } from '@angular/core';
import { Doctor } from 'app/core/models/app.models';
import { RestapiService } from 'app/core/services/restapi.service';
import { Router, ActivatedRoute } from '@angular/router';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { Dictionary } from 'app/core/models/dictionary';
import { ToastrService } from 'ngx-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';

@Component({
  selector: 'app-doctor-list',
  templateUrl: './doctor-list.component.html',
  styleUrls: ['./doctor-list.component.css']
})
export class DoctorListComponent implements OnInit, OnDestroy {
  public isRequesting = false;
  public searchText = '';
  public pageNumber = 0;
  public pageSize = 10;
  public search = '';
  public sort = 'DESC';
  public sortOn = 'id';
  public doctors$: Observable<Doctor[]>;
  public clinicId: string;
  public facilityId: string;
  public doctorId: string;
  public tempDoctor: any;
  private unsubscribe = new Subject<void>();
  public showChangePasswordModal = false;
  public loginName = '';
  public _doctorList = new Subject<Doctor[]>();
  public doctorList$ = this._doctorList.asObservable();
  public doctorList: Doctor[] = [];

  constructor(public router: Router,
    private restapiservice: RestapiService,
    private activatedRouter: ActivatedRoute,
    private toastrService: ToastrService,
    public confirmationPopup: ConfirmationPopupService,
  ) { }

  getDoctor(pageNumber, pageSize) {
    this.isRequesting = true;
    this.restapiservice
      .invoke<Doctor>(APIEndPoint.GET_DOCTORS,
        { clinicId: this.clinicId }, null,
        {
          'pageNumber': pageNumber,
          'pageSize': pageSize,
          'search': this.search,
          'sort': this.sort,
          'sortOn': this.sortOn
        }).subscribe((doctorRes: any) => {
          this.isRequesting = false;
          doctorRes.forEach(element => {
            this.doctorList.push(element);
          });
          this._doctorList.next(this.doctorList);
        });
  }

  getDoctors() {
    this.doctors$ = this.restapiservice.invoke<Doctor[]>(APIEndPoint.GET_DOCTORS, { clinicId: this.clinicId }, null, {
      'sort': this.sort,
      'sortOn': this.sortOn
    }).map(res => {
      return res;
    });
  }

  public addDoctor() {
    this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/doctors/add']);
  }

  private editDoctor(doctorId) {
    console.log('doctorId', doctorId);
    this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/doctors/' + doctorId + '/edit']);
  }

  delete(doctorId, index) {
    this.confirmationPopup.confirm({ message: Dictionary.DELETE_CONFIRMATION }).subscribe(data => {
      if (data) {
        this.deleteDoctor(doctorId, index);
        this.searchText = '';
        this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/doctors']);
      }
    });
  }

  deleteDoctor(doctorId, index) {
    this.restapiservice
      .invoke<Doctor>(APIEndPoint.DELETE_DOCTOR_BY_ID,
        { clinicId: this.clinicId, doctorId: doctorId }).subscribe(doctor => {
          this.getDoctors();
          this.toastrService.success(Dictionary.ENTITY_DELETION);
        }, err => {
          console.log(err);
        });
  }

  changePassword(loginName) {
    this.loginName = loginName;
    this.showChangePasswordModal = true;
  }

  // call when you scroll down and up 300 unit from the bottom
  onScrollUp() {
    this.pageNumber++;
    this.getDoctor(this.pageNumber, this.pageSize);
  }
  // onScrollDown() {
  //   console.log('scroll down', this.pageNumber--);
  //   this.getDoctor(this.pageNumber,this.pageSize);
  // }
  // call when you scroll down and up 300 unit from the bottom
  ngOnInit() {
    Observable.combineLatest(this.activatedRouter.parent.params,
      this.activatedRouter.params).takeUntil(this.unsubscribe).subscribe(response => {
        this.clinicId = response[0]['clinicId'];
        this.facilityId = response[1]['facilityId'];
        this.doctors$ = this.doctorList$;
        this.pageNumber !== 0 ? this.getDoctors() : this.getDoctor(this.pageNumber, this.pageSize);
      });
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}


