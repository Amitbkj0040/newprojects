import { Component, OnInit, OnDestroy } from '@angular/core';
import { AddStaff } from 'app/core/models/addStaff';
import { RestapiService } from 'app/core/services/restapi.service';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { Dictionary } from 'app/core/models/dictionary';

@Component({
  selector: 'app-staff-list',
  templateUrl: './staff-list.component.html',
  styleUrls: ['./staff-list.component.css']
})
export class StaffListComponent implements OnInit, OnDestroy {
  public searchText = '';
  public pageNumber = 0;
  public pageSize = 10;
  public search = '';
  public sort = 'DESC';
  public sortOn = 'id';
  public staffId: string;
  public staff$: Observable<AddStaff[]>;
  public facilityId: string;
  public clinicId: string;
  private unsubscribe = new Subject<void>();
  public showChangePasswordModal = false;
  public loginName = '';
  public isRequesting = false;
  public _staffList = new Subject<AddStaff[]>();
  public staffList$ = this._staffList.asObservable();
  public staffList: AddStaff[] = [];

  constructor(private router: Router,
    private restapiservice: RestapiService,
    public toastrService: ToastrService,
    public confirmationPopup: ConfirmationPopupService,
    private activatedRouter: ActivatedRoute
  ) { }

  getStaff(pageNumber, pageSize) {
    this.isRequesting = true;
    this.restapiservice
      .invoke<AddStaff>(APIEndPoint.GET_SUPPORT_STAFF,
        { clinicId: this.clinicId }, null,
        {
          'pageNumber': pageNumber,
          'pageSize': pageSize,
          'search': this.search,
          'sort': this.sort,
          'sortOn': this.sortOn
        }).subscribe((staffRes: any) => {
          this.isRequesting = false;
          staffRes.forEach(element => {
            this.staffList.push(element);
          });
          this._staffList.next(this.staffList);
        });
  }

  getstaffs() {
    this.staff$ = this.restapiservice.invoke<AddStaff[]>(APIEndPoint.GET_SUPPORT_STAFF, { clinicId: this.clinicId }, null).map(res => {
      return res;
    });
  }

  public addStaff() {
    this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/staffs/add']);
  }

  // deletesStaffById(id, index) {
  //   this.restapiservice
  //     .invoke<AddStaff>(
  //       APIEndPoint.DELETE_STAFF_BY_ID,
  //       {
  //         clinicId: this.clinicId, staffId: this.staffId
  //       }).subscribe(satff => {
  //         console.log('successfully delete by id ', staff);
  //         this.dummyStaff.splice(index, 1);
  //         console.log(this.dummyStaff);
  //       });
  //       this.router.navigate(['./profile-list/staff-list/' ]);
  // }

  delete(staffId, index) {
    this.confirmationPopup.confirm({ message: Dictionary.DELETE_CONFIRMATION }).subscribe(data => {
      if (data) {
        this.deleteStaff(staffId, index);
        this.searchText = '';
        this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/staffs']);
      }
    });
  }


  deleteStaff(staffId, index) {
    this.staffList.splice(index, 1);
    this.restapiservice
      .invoke<AddStaff>(APIEndPoint.DELETE_SUPPORT_STAFF_BY_ID,
        { clinicId: this.clinicId, staffId: staffId }).subscribe(staff => {
          console.log('successfully deleted staff', staff);
          this.toastrService.success(Dictionary.ENTITY_DELETION);
        }, err => {
          console.log(err);
        });
  }

  public editStaff(staffid) {
    this.router.navigate(['/manage-view/clinics/' + this.clinicId + '/staffs/' + staffid + '/edit']);
  }

  changePassword(loginName) {
    this.loginName = loginName;
    this.showChangePasswordModal = true;
  }
  onScrollUp() {
    console.log('scroll up', this.pageNumber++);
    this.getStaff(this.pageNumber, this.pageSize);
  }



  ngOnInit() {
    Observable.combineLatest(this.activatedRouter.parent.params,
      this.activatedRouter.params).takeUntil(this.unsubscribe).subscribe(response => {
        this.clinicId = response[0]['clinicId'];
        this.facilityId = response[1]['facilityId'];
        this.staff$ = this.staffList$;
        this.pageNumber !== 0 ? this.getstaffs() : this.getStaff(this.pageNumber, this.pageSize);
      });
  }

  // getStaffById() {
  //   this.staffId = '1';
  //   // this.restapiservice.invoke<AddStaff>(APIEndPoint.GET_STAFF_BY_ID, { staffId: this.staffId }).subscribe(staff => {
  //   //   console.log('successfully added', staff);
  //   // }, err => {
  //   //   console.log(err);
  //   // });
  // }
  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

}

