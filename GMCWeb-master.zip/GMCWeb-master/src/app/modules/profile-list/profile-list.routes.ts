import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainViewComponent } from 'app/modules/main-view/main-view.component';
import { LoginRouteGuardGuard } from 'app/core/auth/login-route-guard.guard';
import { SubscriptionRouteGuardGuard } from 'app/core/auth/subscription-route-guard.guard';
import { AgreementRouteGuardGuard } from 'app/core/auth/agreement-route-guard.guard';
import { DoctorListComponent } from 'app/modules/profile-list/doctor-list/doctor-list.component';
import { FacilityListComponent } from 'app/modules/profile-list/facility-list/facility-list.component';
import { StaffListComponent } from 'app/modules/profile-list/staff-list/staff-list.component';
import { PatientListComponent } from 'app/modules/profile-list/patient-list/patient-list.component';



const PROFILE_LIST_ROUTES: Routes = [
    {
        path: 'clinic-view/clinics/:clinicId',
        component: MainViewComponent,
        canActivate: [LoginRouteGuardGuard, SubscriptionRouteGuardGuard, AgreementRouteGuardGuard],
        children: [
            { path: 'patients', component: PatientListComponent },
        ]
    },
    {
        path: 'manage-view/clinics/:clinicId',
        component: MainViewComponent,
        canActivate: [LoginRouteGuardGuard, SubscriptionRouteGuardGuard, AgreementRouteGuardGuard],
        children: [
            { path: '', redirectTo: 'facility', pathMatch: 'full' },
            { path: 'facilities', component: FacilityListComponent },
            { path: 'staffs', component: StaffListComponent },
            { path: 'doctors', component: DoctorListComponent }
        ]
    },
];

@NgModule({
    exports: [RouterModule],
    imports: [RouterModule.forChild(PROFILE_LIST_ROUTES)],
})

export class ProfileListRoutingModule { }
