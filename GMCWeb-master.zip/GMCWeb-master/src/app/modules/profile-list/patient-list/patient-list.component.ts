import { Component, OnInit, OnDestroy } from '@angular/core';
import { Patient } from 'app/core/models/Patient';
import { RestapiService } from 'app/core/services/restapi.service';
import { Router, ActivatedRoute } from '@angular/router';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { Subject } from 'rxjs/Subject';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { Dictionary } from 'app/core/models/dictionary';
import { ToastrService } from 'ngx-toastr';
import { AuthService } from 'app/core/auth/auth.service';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';

declare var $: any;

@Component({
  selector: 'app-patient-list',
  templateUrl: './patient-list.component.html',
  styleUrls: ['./patient-list.component.css']
})
export class PatientListComponent implements OnInit, OnDestroy {
  public searchText = '';
  public pageNumber = 0;
  public pageSize = 10;
  public search = '';
  public sort = 'DESC';
  public sortOn = 'id';
  public patients$: Observable<Patient[]>;
  public clinicId: string;
  public patientId: string;
  public doctorId: string;
  public tempDoctor: any;
  public facilityId: string;
  private unsubscribe = new Subject<void>();
  public isRequesting = false;
  public searchPatientSubject = new Subject<string>();
  public _patientList = new Subject<Patient[]>();
  public patientList$ = this._patientList.asObservable();
  public patientList: Patient[] = [];
  public token: any;


  constructor(
    public router: Router,
    private restapiservice: RestapiService,
    public activateRoute: ActivatedRoute,
    private toastrService: ToastrService,
    public confirmationPopup: ConfirmationPopupService,
    public jwtHelper: JwtHelperService,
    private authService: AuthService
  ) { }

  getPatient() {
    this.isRequesting = true;
    this.restapiservice
      .invoke<Patient>(APIEndPoint.GET_PATIENTS,
        { clinicId: this.clinicId }, null,
        {
          'search': this.searchText,
          'sort': this.sort,
          'sortOn': this.sortOn,
          pageNumber: this.pageNumber,
          pageSize: this.pageSize
        }).subscribe((patientRes: any) => {
          this.isRequesting = false;
          patientRes.forEach(element => {
            this.patientList.push(element);
          });
          this._patientList.next(this.patientList);
        });
  }

  public addPatient() {
    this.router.navigate(['./clinic-view/clinics/' + this.clinicId + '/patients/add']);
  }
  public editPatient(patientId) {
    console.log('patientId', patientId);
    this.router.navigate(['./clinic-view/clinics/' + this.clinicId + '/patients/' + patientId + '/edit']);
  }

  delete(patientId, index) {
    this.confirmationPopup.confirm({ message: Dictionary.DELETE_CONFIRMATION }).subscribe(data => {
      if (data) {
        this.deletePatient(patientId, index);
        this.searchText = '';
      }
    });
  }

  deletePatient(patientId, index) {
    console.log('patientId', patientId);
    this.restapiservice
      .invoke<Patient>(APIEndPoint.DELETE_PATIENT_BY_ID,
        { clinicId: this.clinicId, patientId: patientId }).subscribe(patient => {
          this.patientList.splice(index, 1);
          // this.getPatient(this.pageNumber, this.pageSize);
          console.log('successfully deleted patient', patient);
          this.toastrService.success(Dictionary.ENTITY_DELETION);
        }, err => {
          console.log(err);
        });

  }

  patientHistory(patientId) {
    this.router.navigate([`clinic-view/clinics/${this.clinicId}/doctors/${this.doctorId}/patients/${patientId}/encounters-full-history`]);
  }
  onScrollUp() {
    console.log('scroll up', this.pageNumber++);
    this.getPatient();
  }

  goToImport() {
    this.router.navigate([`clinic-view/clinics/${this.clinicId}/patients/import/patient/data`]);
  }

  ngOnInit() {
    Observable.combineLatest(this.activateRoute.parent.params,
      this.activateRoute.params).takeUntil(this.unsubscribe).subscribe(response => {
        this.clinicId = response[0]['clinicId'];
        this.facilityId = response[0]['facilityId'];
        this.doctorId = this.authService.getStaffId();
        this.patients$ = this.patientList$;
        this.getPatient();
      });
    this.token = this.jwtHelper.decodeToken(this.authService.getAuthToken());
    this.onSearch();
  }

  onSearch() {
    this.searchPatientSubject
      .debounceTime(400)
      .distinctUntilChanged()
      .subscribe(searchterm => {
        this.searchText = searchterm;
        this.pageNumber = 0;
        this.patientList = [];
        $('#scrollElement').scrollTop(0);
        this.getPatient();
      });
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

}
