import { Component, OnInit, OnDestroy } from '@angular/core';
import { AddFacility } from 'app/core/models/addFacility';
import { Dictionary } from 'app/core/models/dictionary';
import { Router, ActivatedRoute } from '@angular/router';
import { RestapiService } from 'app/core/services/restapi.service';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { ToastrService } from 'ngx-toastr';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { Facility } from 'app/core/models/app.models';


@Component({
  selector: 'app-facility-list',
  templateUrl: './facility-list.component.html',
  styleUrls: ['./facility-list.component.css']
})
export class FacilityListComponent implements OnInit, OnDestroy {
  public facilityId: any;
  public facilities$: Observable<AddFacility[]>;
  public _facilityList = new Subject<AddFacility[]>();
  public facilityList$ = this._facilityList.asObservable();
  public facilityList: AddFacility[] = [];
  public unsubscribe = new Subject<void>();
  public searchText = '';
  public pageNumber = 0;
  public pageSize = 10;
  public search = '';
  public sort = 'DESC';
  public sortOn = 'id';
  private alertDialog;
  clinicId: any;
  hideAlert = false;
  public isRequesting = false;
  // tslint:disable-next-line:no-inferrable-types
  currentUser: string = Dictionary.DELETE_LIST_ALERT;


  constructor(
    private router: Router,
    private restapiservice: RestapiService,
    private activatedRouter: ActivatedRoute,
    public confirmationPopup: ConfirmationPopupService,
    public toastrService: ToastrService
  ) { }

  getFacility(pageNumber, pageSize) {
    this.isRequesting = true;
    this.restapiservice
      .invoke<AddFacility[]>(
        APIEndPoint.GET_FACILITIES,
        { clinicId: this.clinicId }, null,
        {
          'pageNumber': pageNumber,
          'pageSize': pageSize,
          'search': this.search,
          'sort': this.sort,
          'sortOn': this.sortOn
        })
      .takeUntil(this.unsubscribe)
      .subscribe(facliltyRes => {
        this.isRequesting = false;
        facliltyRes.forEach(element => {
          this.facilityList.push(element);
        });
        this._facilityList.next(this.facilityList);
      });
  }

  delete(facilityId, index) {
    this.confirmationPopup.confirm({ message: Dictionary.DELETE_CONFIRMATION }).subscribe(data => {
      if (data) {
        this.deleteFacility(facilityId);
        this.searchText = '';
        this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/facilities']);
      }
    });
  }

  deleteFacility(facilityId) {
    this.restapiservice
      .invoke<AddFacility>(APIEndPoint.DELETE_FACILITY_BY_ID,
        { clinicId: this.clinicId, facilityId }).subscribe(() => {
          this.facilityList = [];
          this._facilityList.next([]);
          this.getFacilities();
          this.toastrService.success(Dictionary.ENTITY_DELETION);
        }, err => {
          console.log(err);
        });
  }

  public editFacility(id) {
    this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/facilities/' + id + '/edit']);
  }

  public addFacility() {
    this.router.navigate(['./manage-view/clinics/' + this.clinicId + '/facilities/add']);
  }

  getFacilities() {
    this.facilities$ = this.restapiservice.invoke<AddFacility[]>(APIEndPoint.GET_FACILITIES, { clinicId: this.clinicId }, null, {
      'sort': this.sort,
      'sortOn': this.sortOn
    }).map(res => {
      return res;
    });
  }

  onScrollUp() {
    this.pageNumber++;
    this.getFacility(this.pageNumber, this.pageSize);
  }

  ngOnInit() {
    Observable.combineLatest(this.activatedRouter.parent.params,
      this.activatedRouter.params).takeUntil(this.unsubscribe).subscribe(response => {
        this.clinicId = response[0]['clinicId'];
        this.facilities$ = this.facilityList$;
        this.pageNumber !== 0 ? this.getFacilities() : this.getFacility(this.pageNumber, this.pageSize);
      });
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}


