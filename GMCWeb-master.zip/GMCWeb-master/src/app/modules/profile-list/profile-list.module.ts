import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { ProfileListComponent } from 'app/modules/profile-list/profile-list.component';
import { DoctorListComponent } from 'app/modules/profile-list/doctor-list/doctor-list.component';
import { FacilityListComponent } from 'app/modules/profile-list/facility-list/facility-list.component';
import { StaffListComponent } from 'app/modules/profile-list/staff-list/staff-list.component';
import { PatientListComponent } from 'app/modules/profile-list/patient-list/patient-list.component';
import { ProfileListRoutingModule } from 'app/modules/profile-list/profile-list.routes';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    ProfileListRoutingModule
  ],
  declarations: [
    ProfileListComponent,
    DoctorListComponent,
    FacilityListComponent,
    StaffListComponent,
    PatientListComponent,
  ]
})
export class ProfileListModule { }
