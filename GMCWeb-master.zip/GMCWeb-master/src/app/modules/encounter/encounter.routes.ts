import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MainViewComponent } from 'app/modules/main-view/main-view.component';
import { LoginRouteGuardGuard } from 'app/core/auth/login-route-guard.guard';
import { SubscriptionRouteGuardGuard } from 'app/core/auth/subscription-route-guard.guard';
import { AgreementRouteGuardGuard } from 'app/core/auth/agreement-route-guard.guard';
import { EncounterComponent } from 'app/modules/encounter/encounter.component';
import { PatientEncounterComponent } from 'app/modules/encounter/patient-encounter/patient-encounter.component';
import { EncounterFullHistoryComponent } from 'app/modules/encounter/encounter-full-history/encounter-full-history.component';
import { PatientEncouterViewComponent } from 'app/modules/encounter/patient-encouter-view/patient-encouter-view.component';
// import { EncounterMedicinesComponent } from 'app/modules/encounter/encounter-medicines/encounter-medicines.component';
import { EditEncounterDetailsComponent } from 'app/modules/encounter/edit-encounter-details/edit-encounter-details.component';
import { DoctorEncountersComponent } from './doctor-encounters/doctor-encounters.component';




const ENCOUNTER_ROUTES: Routes = [

    {
        path: 'clinic-view/clinics/:clinicId/facilities/:facilityId',
        component: MainViewComponent,
        canActivate: [LoginRouteGuardGuard, SubscriptionRouteGuardGuard, AgreementRouteGuardGuard],
        children: [
            { path: '', redirectTo: 'encounter/', pathMatch: 'full' },
            {
                path: 'doctors/:doctorId',
                component: EncounterComponent,
                children: [
                    {
                        path: 'encounters',
                        component: PatientEncounterComponent
                    },
                    {
                        path: 'patients/:patientId/encounters/:encounterId/:mode',
                        component: PatientEncounterComponent
                    }
                ]
            },
            {
                path: 'doctors/:doctorId/patients/:patientId/encounters/:encounterId',
                component: PatientEncouterViewComponent
            },
            {
                path: 'doctors/:doctorId/patients/:patientId/encounters-full-history',
                component: EncounterFullHistoryComponent
            },
            {
                path: 'doctors/:doctorId/encounter-history',
                component: DoctorEncountersComponent
            }
            // { path: 'medicines', component: EncounterMedicinesComponent },
        ]
    },
    {
        path: 'clinic-view/clinics/:clinicId',
        component: MainViewComponent,
        canActivate: [LoginRouteGuardGuard, SubscriptionRouteGuardGuard, AgreementRouteGuardGuard],
        children: [
            {
                path: 'doctors/:doctorId/patients/:patientId/encounters-full-history',
                component: EncounterFullHistoryComponent
            },
        ]
    },

];

@NgModule({
    exports: [RouterModule],
    imports: [RouterModule.forChild(ENCOUNTER_ROUTES)],
})

export class EncounterRoutingModule { }
