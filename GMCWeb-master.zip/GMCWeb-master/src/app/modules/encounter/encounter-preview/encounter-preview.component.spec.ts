import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EncounterPreviewComponent } from './encounter-preview.component';

describe('EncounterPreviewComponent', () => {
  let component: EncounterPreviewComponent;
  let fixture: ComponentFixture<EncounterPreviewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EncounterPreviewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EncounterPreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
