import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';
import { AppointmentStatus, Appointment, Document } from 'app/core/models/app.models';
import { RestapiService } from 'app/core/services/restapi.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { DownloadFileService } from 'app/core/services/download-file.service';
import { APIDef, APIEndPoint } from 'app/core/models/ApiEndPoint';
declare var $: any;

@Component({
  selector: 'app-encounter-preview',
  templateUrl: './encounter-preview.component.html',
  styleUrls: ['./encounter-preview.component.css']
})
export class EncounterPreviewComponent implements OnInit {
  AppointmentStatus = AppointmentStatus;
  @Input() appointment: Appointment;
  // @Input() options: {showEdit, showNext} = {showEdit: true, showNext: true};
  @Output() nextEncounter = new EventEmitter();
  @Output() editEvent = new EventEmitter();
  private unsubscribe = new Subject<void>();
  clinicId: string;
  facilityId: string;
  doctorId: string;
  apiDE: APIDef = APIEndPoint.GET_DOCTORS;
  selectedDoctors: Object[] = [];
  public showPresShare = false;
  public myurl: any;

  constructor(private restService: RestapiService,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    private downloadFileService: DownloadFileService) { }

  ngOnInit() {
    console.log('appointment haha', this.appointment.encounter.followUp);
    Observable.combineLatest(this.activatedRoute.parent.parent.params,
      this.activatedRoute.parent.params,
      this.activatedRoute.params).takeUntil(this.unsubscribe).subscribe(response => {
        this.clinicId = response[0]['clinicId'];
        this.facilityId = response[0]['facilityId'];
        this.doctorId = response[1]['doctorId'];
      });
  }

  getNativeWindow() {
    return window;
  }
  printPrescription() {
    // tslint:disable-next-line:max-line-length
    this.router.navigate(['/print'], {
      queryParams:
      {
        clinicId: this.clinicId,
        facilityId: this.facilityId,
        doctorId: this.doctorId,
        patientId: this.appointment.patient.id,
        encounterId: this.appointment.encounter.id
      }
    });
    // tslint:disable-next-line:max-line-length
    // this.restService.printHTML(`/api/clinics/${this.clinicId}/facilities/${this.facilityId}/patients/${this.appointment.patient.id}/encounter/${this.appointment.encounter.id}/viewHTML`)
    //   .subscribe(data => {
    //     //   const pdfFile = new Blob([ data ], {
    //     //     type : 'application/pdf'
    //     // });
    //     // const pdfUrl = URL.createObjectURL(pdfFile);
    //     console.log('hadfasdfsafdsaf', data);
    //     const h = window.innerHeight * 0.9;
    //     const w = window.innerWidth * 0.8;
    //     const printwWindow = window.open('', '_blank', 'toolbar=no,scrollbars=yes,resizable=yes,location=no,top=100,left=100,width='
    //       + w + ',height=' + h);
    //     if (!printwWindow) {
    //       alert('Please allow pop-ups on this site!');
    //     }
    //     printwWindow.document.write(data.body.toString());
    //     setInterval(() => {
    //       printwWindow.print();
    //     }, 100);
    //     //  printwWindow.document.close();
    //   });
  }

  downloadDocument(fileUploadId, fileName) {
    this.downloadFileService.downloadDocument(fileUploadId).subscribe(resp => {
      console.log('respsdfdf', resp);
      this.saveFile(resp, fileName);
    });
  }

  saveFile(resp, fileName) {
    // window.URL = window.URL || window.webkitURL;
    const a = document.createElement('a');
    const blob = new Blob([resp], { type: 'octet/stream' });
    const url = window.URL.createObjectURL(blob);
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    console.log('dddddd', a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  }

  onModalClose() {
    this.selectedDoctors = [];
  }
  onShare() {

  }

  viewDocument(fileUploadId) {
    this.downloadFileService.downloadDocument(fileUploadId).subscribe(resp => {
      const type = resp.type;
      this.viewFile(resp, type);
      // const blob = resp.blob();
      // const file = new Blob([blob], {});
      // const filename = 'document-' + Date.now() + '.pdf';
      //  FileSaver.saveAs(file, filename);
    });
  }
  viewFile(resp, type) {
    console.log('document response', resp);
    const blob = new Blob([resp], { type: type });
    this.myurl = blob;
    const url = window.URL.createObjectURL(blob);
    console.log('blob url', url);

    const newWindow = window.open(url, '_blank', 'width=1000,height=1000');
    if (!newWindow) {
      alert('Please allow pop-ups on this site!');
    }
    // tslint:disable-next-line:max-line-length
    //  win.document.write('<iframe src="' + fileURL + '" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen></iframe>')

    // const img =  document.getElementById('image');
    // img.src = url;
    // const reader = new FileReader();
    //     reader.readAsDataURL(blob);
    //     reader.onloadend = function () {
    //        const base64data = reader.result;
    //        console.log(base64data);
    //        const doc = base64data.toString().split(',')[1];
    //         console.log(doc);
    // document.getElementById('pres1').innerHTML = doc;
    // $('#myModal').modal('show');


  }
}



