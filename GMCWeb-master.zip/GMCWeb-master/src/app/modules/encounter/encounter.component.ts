import { Component, OnInit, OnDestroy, HostListener, Output, EventEmitter } from '@angular/core';
import { RestapiService } from 'app/core/services/restapi.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { AppointmentEncounterService } from 'app/core/services/patient-encounter.service';

@Component({
  selector: 'app-encounter',
  templateUrl: './encounter.component.html',
  styleUrls: ['./encounter.component.css']
})
export class EncounterComponent implements OnInit, OnDestroy {
  clinicId: string;
  facilityId: string;
  doctorId: string;
  private unsubscribe = new Subject<void>();
  public patientSearchTxt: string;
  public isMobileView: boolean;
  public _encounterToggle = new Subject<boolean>();
  public encounterToggle = this._encounterToggle.asObservable();
  public showBookAppointmentDialog = false;


  constructor(public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    private patientEncounterService: AppointmentEncounterService) { }

  @HostListener('window:resize', ['$event']) onresize(event) {
    this.detectMobileView();
  }

  detectMobileView() {
    if (window.innerWidth <= 768) {
      this.isMobileView = true;
    } else {
      this.isMobileView = false;
    }
  }
  toggleHistoryModal() {
    this._encounterToggle.next(true);
  }
  ngOnInit() {
    this.detectMobileView();
    Observable.combineLatest(this.activatedRoute.parent.params,
      this.activatedRoute.params).takeUntil(this.unsubscribe).subscribe(response => {
        this.clinicId = response[0]['clinicId'];
        this.facilityId = response[0]['facilityId'];
        this.doctorId = response[1]['doctorId'];
      });
  }


  addWalkinPatient() {
    this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId +
      '/doctors/' + this.doctorId + '/appointments/view'],
      {
        queryParams: {
          patientWalkin: true,
          fromRoute: 'encounter',
          doctorId: this.doctorId,
          facilityId: this.facilityId
        }

      });
  }

  watchDoctorEncounters() {
    this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId + '/doctors/' + this.doctorId + '/encounter-history']);
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

}
