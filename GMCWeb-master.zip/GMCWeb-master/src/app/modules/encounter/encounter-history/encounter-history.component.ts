import { Component, OnInit, Input, OnChanges, SimpleChanges, HostListener } from '@angular/core';
import { Encounter, AppointmentStatus, Appointment } from 'app/core/models/app.models';
import { RestapiService } from 'app/core/services/restapi.service';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Observable } from 'rxjs/Observable';
import { Router } from '@angular/router';
import { EncounterComponent } from '../encounter.component';


@Component({
  selector: 'app-encounter-history',
  templateUrl: './encounter-history.component.html',
  styleUrls: ['./encounter-history.component.css']
})
export class EncounterHistoryComponent implements OnInit, OnChanges {
  encounters$: Observable<Encounter[]>;
  AppointmentStatus = AppointmentStatus;
  public encounterToggle$ = new Observable<boolean>();
  @Input() appointment: Appointment;
  @Input() clinicId: string;
  @Input() facilityId: string;
  @Input() doctorId: string;
  pastEncounterIndex = 0;
  public isMobileView: boolean;

  constructor(
    private restapiservice: RestapiService,
    private router: Router,
    public encounterComponent: EncounterComponent
  ) {
    this.detectMobileView();
  }

  @HostListener('window:resize', ['$event']) onresize(event) {
    this.detectMobileView();
  }

  detectMobileView() {
    if (window.innerWidth < 768) {
      this.isMobileView = true;
    } else {
      this.isMobileView = false;
    }
  }

  hideModalInParent() {
    this.encounterComponent._encounterToggle.next(false);
  }

  ngOnInit() {
    this.encounterToggle$ = this.encounterComponent.encounterToggle.map(resp => {
      return resp;
    });
    console.log('fgdfgd', this.appointment);
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes && changes.appointment && changes.appointment.currentValue) {
      this.pastEncounterIndex = 0;
      this.getPatientHistory();
    } else {
      this.encounters$ = Observable.of([]);
    }
  }

  getPatientHistory() {
    this.encounters$ = this.restapiservice.invoke<Encounter[]>(APIEndPoint.GET_ENCOUNTERS_WITH_DOC,
      { clinicId: this.clinicId, facilityId: this.facilityId, patientId: this.appointment.patient.id, doctorId: this.doctorId });
  }

  nextPastEncounter(max: number) {
    if (this.pastEncounterIndex < max) {
      this.pastEncounterIndex++;
    }
  }

  prevPastEncounter() {
    if (this.pastEncounterIndex > 0) {
      this.pastEncounterIndex--;
    }
  }

  veiwFullHistory() {
    this.router.navigate(['/clinic-view/clinics/' +
      this.clinicId + '/facilities/' + this.facilityId + '/doctors/' + this.doctorId + '/patients/' +
      this.appointment.patient.id + '/encounters-full-history']);
  }

}
