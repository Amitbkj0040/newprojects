import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DoctorEncountersComponent } from './doctor-encounters.component';

describe('DoctorEncountersComponent', () => {
  let component: DoctorEncountersComponent;
  let fixture: ComponentFixture<DoctorEncountersComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DoctorEncountersComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DoctorEncountersComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
