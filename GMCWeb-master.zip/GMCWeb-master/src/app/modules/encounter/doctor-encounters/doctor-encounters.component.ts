import { Component, OnInit, OnDestroy } from '@angular/core';
import { DoctorEncounters } from 'app/core/models/DoctorEncounters';
import { RestapiService } from 'app/core/services/restapi.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Encounter } from 'app/core/models/app.models';





@Component({
  selector: 'app-doctor-encounters',
  templateUrl: './doctor-encounters.component.html',
  styleUrls: ['./doctor-encounters.component.css']
})
export class DoctorEncountersComponent implements OnInit, OnDestroy {

  // pagination 

  searchText = '';
  search = '';
  pageNumber = 0;
  pageSize = 10;
  sort = 'DESC';
  sortOn = 'id';
  filterParamerters = {
    startDate: '',
    endDate: '',
    patientName: '',
    uhid: '',
    email: '',
    phone: ''
  };
  appliedFilter: any;
  isFilterApplied: boolean;


  clinicId: string;
  facilityId: string;
  doctorId: string;


  doctorEncounters: DoctorEncounters[] = [];
  unsubscribe = new Subject();
  encounterView: boolean;
  patientEncounterDetails: Encounter;
  searchDoctoryEncounterSubject = new Subject<string>();


  isLoading: boolean;
  showFilterModal: boolean;
  showAccessModal: boolean;
  showPresscriptionShareModal: boolean;




  constructor(
    private restApiServices: RestapiService,
    private activatedRoute: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.isLoading = true;
    Observable.combineLatest(this.activatedRoute.parent.params, this.activatedRoute.params)
      .takeUntil(this.unsubscribe)
      .subscribe((params) => {
        this.clinicId = params[0].clinicId;
        this.facilityId = params[0].facilityId;
        this.doctorId = params[1].doctorId;
        this.getDoctorEncounters(this.clinicId, this.facilityId, this.doctorId, this.pageNumber, this.pageSize);
        // this.onSearch();
      });
  }

  getDoctorEncounters(clinicId: string, facilityId: string, doctorId: string, pageNumber, pageSize) {
    this.isLoading = true;
    this.restApiServices.invoke(APIEndPoint.GET_DOCTOR_ENCOUNTERS,
      { clinicId, facilityId, doctorId }, null, {
      ...this.appliedFilter,
      'pageNumber': pageNumber,
      'pageSize': pageSize,
      'search': this.search,
      'sort': this.sort,
      'sortOn': this.sortOn
    })
      .subscribe((doctorEncounterRes: any) => {
        this.isLoading = false;
        doctorEncounterRes.forEach(element => {
          this.doctorEncounters.push(element);
        });
      });
  }



  getEncounterDetails(encounterId) {
    this.encounterView = true;
    this.isLoading = true;
    this.restApiServices.invoke<Encounter>(APIEndPoint.GET_SHARED_ENCOUNTER_BY_ID,
      {
        clinicId: this.clinicId, staffId: this.doctorId,
        encounterId: encounterId
      }).takeUntil(this.unsubscribe).subscribe(res => {
        this.patientEncounterDetails = res;
        console.log('patient-encounter', this.patientEncounterDetails);
        this.isLoading = false;
      }, error => {
        this.isLoading = false;
      });
  }

  onBack() {
    this.encounterView = false;
    this.patientEncounterDetails = null;
  }

  printPrescription(event) {
    if (event) {
      this.router.navigate(['/print'], {
        queryParams:
        {
          clinicId: this.clinicId,
          facilityId: this.facilityId,
          doctorId: this.doctorId,
          staffId: this.doctorId,
          encounterId: this.patientEncounterDetails.id,
          from: 'sharedDocument',
          emrType: this.patientEncounterDetails.emrType
        }
      });
    }
  }

  onScrollUp() {
    this.pageNumber++;
    this.getDoctorEncounters(this.clinicId, this.facilityId, this.doctorId, this.pageNumber, this.pageSize);
  }

  onFilterData(queryString) {
    this.isFilterApplied = true;
    this.pageNumber = 0;
    const { startDate, endDate, patientName, uhid, email, phone } = queryString;
    const query = { startDate, endDate, patientName, uhid, email, phone };
    this.appliedFilter = query;
    this.filterParamerters = queryString;
    this.doctorEncounters = [];
    this.getDoctorEncounters(this.clinicId, this.facilityId, this.doctorId, this.pageNumber, this.pageSize);
    this.showFilterModal = false;
  }

  shareEncounter(encounter) {
    this.patientEncounterDetails = encounter;
    this.showPresscriptionShareModal = true;
  }

  showEncounterAccessors(encounter) {
    this.patientEncounterDetails = encounter;
    this.showAccessModal = true;
  }

  showPateintDetails(patientId) {
    this.router.navigate(['./clinic-view/clinics/' + this.clinicId + '/patients/' + patientId + '/edit']);
  }

  changeDate(dateFormate) {
    return new Date(dateFormate);
  }

  restFilter() {
    this.doctorEncounters = [];
    this.isFilterApplied = false;
    this.appliedFilter = {
      startDate: '',
      endDate: '',
      patientName: '',
      uhid: '',
      email: '',
      phone: ''
    };
    this.filterParamerters = {
      startDate: '',
      endDate: '',
      patientName: '',
      uhid: '',
      email: '',
      phone: ''
    };
    this.pageNumber = 0;
    this.getDoctorEncounters(this.clinicId, this.facilityId, this.doctorId, this.pageNumber, this.pageSize);
  }

  ngOnDestroy() {
    this.unsubscribe.next('');
    this.unsubscribe.complete();
  }
}
