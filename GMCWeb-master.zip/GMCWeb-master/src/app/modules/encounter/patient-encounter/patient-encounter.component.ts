import { Component, OnInit, HostListener, OnDestroy } from '@angular/core';
import { RestapiService } from 'app/core/services/restapi.service';
import { Router, ActivatedRoute } from '@angular/router';
import { APIEndPoint, APIDef } from 'app/core/models/ApiEndPoint';
import { Observable } from 'rxjs/Observable';
import { FormGroup } from '@angular/forms';
import { Subject } from 'rxjs/Subject';
import {
  Medicine, Encounter, MedQuantity, MedSchedule,
  MedTime, MedFrequency, MedDuration, Doctor, Appointment, AppointmentStatus, DocumentType, Document, MedRoute, FollowUp, AppointmentType
} from 'app/core/models/app.models';
import { AppointmentEncounterService } from 'app/core/services/patient-encounter.service';
import { AuthService } from 'app/core/auth/auth.service';
import { ToastrService } from 'ngx-toastr';
import { Dictionary } from 'app/core/models/dictionary';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { UploadFileService } from 'app/core/services/upload-file.service';
import { BehaviorSubject } from '../../../../../node_modules/rxjs';
import { Ng4LoadingSpinnerService } from 'ng4-loading-spinner';
import { DoctorPhysicalExam } from 'app/core/models/DoctorPhysicalExam';

@Component({
  selector: 'app-patient-encounter',
  templateUrl: './patient-encounter.component.html',
  styleUrls: ['./patient-encounter.component.css']
})
export class PatientEncounterComponent implements OnInit, OnDestroy {
  noAppointment: boolean;
  doctor$: Observable<Doctor>;
  notes: any;
  complaintAPI: APIDef = APIEndPoint.GET_COMPLAINTS;
  observationAPI: APIDef = APIEndPoint.GET_OBSERVATIONS;
  medicinesAPI: APIDef = APIEndPoint.GET_MEDICINES;
  diagonsisAPI: APIDef = APIEndPoint.GET_DIAGNOSIS;
  diagnosticTestsAPI: APIDef = APIEndPoint.GET_INVESTIGATIONS;
  selectedComplaints: string[] = [];
  selectedMedicines: Medicine[] = [];
  selectedObservations: string[] = [];
  selectedDiagnosis: string[] = [];
  selectedDiagnosticTests: string[] = [];
  selectedTimes: string[] = [];
  selectedDuration: string;
  selectedShedules: string[] = [];
  selectedFrequency: string;
  selectedQuantity: string;
  selectedRoute: string;
  selectedAppointmentIndex: number;
  totalEncounter: number;
  pageNumber = 0;
  pageSize = 0;
  name = 'ABC';
  sort = 'ASC';
  sortOn = 'name';
  encounterForm: FormGroup;
  IsSearchPatient: boolean;
  getEncounter: any;
  firstName: any;
  lastName: any;
  mode = 'add';
  medQuantities$: Observable<MedQuantity[]>;
  medFrequencies$: Observable<MedFrequency[]>;
  medRoutes$: Observable<MedRoute[]>;
  medSchedules$: Observable<MedSchedule[]>;
  medTimings$: Observable<MedTime[]>;
  medDurations$: Observable<MedDuration[]>;
  medicines: Medicine[];
  physicalExams = {};
  doctorPhysicalExams: any[] = [];
  masterPhysicalExams: any[] = [];
  encounterId: string;
  clinicId: string;
  facilityId: string;
  patientId: string;
  doctorId: string;
  encounters$: Observable<Encounter[]>;
  isClose: boolean;
  isPreview = false;
  appointment: Appointment;
  unsubscribe = new Subject<void>();
  fileToUpload: File = null;
  filesToUpload: string[] = [];
  documentType = 'OTHERS';
  entityId: string;
  entityType = 'PERSON';
  uploadedNewFile: any;
  startcount: number;
  uploadInProgress: boolean;
  uploadFileSubject = new BehaviorSubject(false);
  uploadFileObservable$ = this.uploadFileSubject.asObservable();
  saveInProgress: boolean;
  selectedDocuments: Document[] = [];
  documentId: number;
  isMobileView: boolean;
  isRequesting = false;
  isValid = true;
  isFollowUp = false;
  showFollowUp = false;
  dayValue = null;
  weekValue = null;
  monthValue = null;
  followUp: FollowUp = {
    days: null,
    weeks: null,
    months: null,
  };
  vitals: any[] = [];
  updatedVitals: any;
  physicalExam: any;
  defaultDoctorPhysicalExam: DoctorPhysicalExam[];
  isPhysicalExamChange = false;

  constructor(
    public router: Router,
    private restapiservice: RestapiService,
    private activatedRoute: ActivatedRoute,
    private appointmentEncounterService: AppointmentEncounterService,
    private authService: AuthService,
    public toastrSrvice: ToastrService,
    public confirmationPopup: ConfirmationPopupService,
    private spinnerService: Ng4LoadingSpinnerService,
    public fileUploader: UploadFileService) {
    this.detectMobileView();
  }

  @HostListener('window:resize', ['$event']) onresize(event) {
    this.detectMobileView();
  }

  detectMobileView() {
    if (window.innerWidth < 768) {
      this.isMobileView = true;
    } else {
      this.isMobileView = false;
    }
  }

  saveEncounter() {
    this.isPreview = false;
  }

  setComplaints(event) {
    this.selectedComplaints = event;
  }

  setMedicines(event) {
    this.selectedMedicines = event;
  }

  uploadStarted() {
    this.uploadFileSubject.next(true);
  }

  uploadEnded() {
    this.uploadFileSubject.next(false);
  }

  onCheck(event) {
    if (event.target.checked) {
      this.isFollowUp = true;
      this.showFollowUp = true;
      this.followUp = {
        days: null,
        weeks: null,
        months: null
      };
    } else {
      this.showFollowUp = false;
      this.followUp = null;
      this.isFollowUp = false;
    }
  }

  onKey(event, type) {
    const value = event.target.value;
    if (type === 'DAY') {
      this.followUp.weeks = null;
      this.followUp.months = null;
    } else if (type === 'WEEK') {
      this.followUp.days = null;
      this.followUp.months = null;

    } else if (type === 'MONTH') {
      this.followUp.weeks = null;
      this.followUp.days = null;
    }
  }

  createMetaVitalsList(metaVitals: any, mode?: string) {
    const examinationTime = new Date();
    if (typeof metaVitals !== 'undefined') {
      let results: any;
      if (mode !== 'edit') {
        results = metaVitals.map((elem => {
          return {
            metaVital: elem, observedValue: null,
            examinationTime: new Date(),
            metaVitalUnit: elem.units[0].id ? { id: elem.units[0].id } : null,
            unit: elem.units[0]
          };
        }));
      } else {
        results = metaVitals.map((elem => {
          return {
            metaVital: elem.metaVital,
            observedValue: elem.observedValue,
            metaVitalUnit: elem.metaVitalUnit,
            id: elem.id,
            examinationTime: examinationTime,
            unit: elem.metaVital.units.find((unit) => unit.id === elem.metaVitalUnit.id)
          };
        }));
      }
      return results;
    } else {
      return [];
    }
  }

  updateVitals(vitals) {
    this.updatedVitals = vitals;
    this.isPhysicalExamChange = true;
  }

  suffleElementsByKeyName(array: any[], keyName: string, value) {
    const item = array.find(elem => elem[keyName] === value);
    const itemIndex = array.indexOf(item);
    array.splice(itemIndex, 1);
    return array.unshift(item);
  }

  createEncounter() {
    this.physicalExam = this.updatedVitals ? { ...this.physicalExam, vitals: this.updatedVitals } : this.physicalExam;
    if (this.isFollowUp && (this.followUp.days === null && this.followUp.months === null && this.followUp.weeks === null)) {
      this.toastrSrvice.error('Please enter followup');
    } else {
      this.saveInProgress = true;
      this.isRequesting = true;
      this.uploadFileObservable$.subscribe(uploadInProgress => {
        if (!uploadInProgress && this.saveInProgress) {
          this.saveInProgress = false;
          const encounter: any = {
            complaints: this.selectedComplaints,
            doctor: {
              id: this.doctorId
            },
            diagnosis: this.selectedDiagnosis,
            notes: this.notes,
            medicines: this.selectedMedicines,
            observations: this.selectedObservations,
            investigations: this.selectedDiagnosticTests,
            physicalExam: this.physicalExam,
            followUp: this.followUp,
            document: this.selectedDocuments,
            emrType: 'GMC_EMR'
          };
          if (this.mode === 'add') {
            this.appointment.encounter = encounter;
            this.appointment.appointmentStatus = AppointmentStatus.INPROGRESS;
            const apiEndPoint = this.appointment.appointmentType !== AppointmentType.VIRTUAL ?
              APIEndPoint.UPDATE_APPOINTMENT : APIEndPoint.UPDATE_VIRTUAL_APPOINTMENT;
            this.restapiservice
              .invoke<Appointment>(apiEndPoint,
                { clinicId: this.clinicId, facilityId: this.facilityId, doctorId: this.doctorId, appointmentId: this.appointment.id },
                this.appointment)
              .takeUntil(this.unsubscribe).finally(() => {
                this.isRequesting = false;
              })
              .subscribe(appointment => {
                this.isRequesting = false;
                this.appointment.encounter = appointment.encounter;
                this.selectedDocuments = appointment.encounter.document;
                this.followUp = appointment.encounter.followUp;
                this.physicalExam = appointment.encounter.physicalExam;
                if (this.physicalExam && this.physicalExam.vitals) {
                  this.vitals = this.createMetaVitalsList(this.physicalExam.vitals, 'edit');
                }
                this.isPreview = true;
              });
          } else {
            this.restapiservice
              .invoke<Encounter>(APIEndPoint.UPDATE_ENCOUNTER,
                {
                  clinicId: this.clinicId, facilityId: this.facilityId, patientId: this.appointment.patient.id,
                  encounterId: this.appointment.encounter.id
                },
                encounter)
              .takeUntil(this.unsubscribe).finally(() => {
                this.isRequesting = false;
              })
              .subscribe(enc => {
                this.appointment = { ...this.appointment, encounter: enc };
                this.selectedDocuments = enc.document;
                this.followUp = enc.followUp;
                this.isPreview = true;
              });
          }
        }
      });
    }
  }

  bookAppointment() {
    this.router.navigate(['/clinic-view/clinics/' + this.clinicId + '/facilities/' + this.facilityId +
      '/doctors/' + this.doctorId + '/appointments/view']);
  }

  ngOnInit() {
    if (this.authService.isUserDoctor) {
      this.doctorId = this.authService.getStaffId();
      this.entityId = this.doctorId;
      Observable.combineLatest(this.activatedRoute.parent.parent.params,
        this.activatedRoute.parent.params).takeUntil(this.unsubscribe).subscribe(response => {
          this.clinicId = response[0]['clinicId'];
          this.facilityId = response[0]['facilityId'];
          this.restapiservice
            .invoke<Doctor>(APIEndPoint.GET_DOCTOR_BY_ID, { clinicId: this.clinicId, doctorId: this.doctorId })
            .subscribe((doctor: any) => {
              if (doctor.metaVitals && doctor.metaVitals.length > 0) {
                this.vitals = this.createMetaVitalsList(doctor.metaVitals, 'add');
                this.defaultDoctorPhysicalExam = doctor.metaVitals;
              }
              this.appointmentEncounterService.getNextAppointment().takeUntil(this.unsubscribe).subscribe((appointmentData: any) => {
                this.startEncouterForAppointment(appointmentData.appointment, appointmentData.appointmentIndex);
                this.isClose = appointmentData.isClose;
              });
              this.appointmentEncounterService
                .getselectedAppointmentIndexAndTotalEncounter().takeUntil(this.unsubscribe)
                .subscribe(index => {
                  this.selectedAppointmentIndex = index.selectedAppointementIndex;
                  this.totalEncounter = index.totalEncounter;
                });
            });
        });
    }
  }

  initPhysicalExams() {
    if (this.appointment && this.appointment.physicalExam) {
      this.physicalExam = this.appointment.physicalExam;
      this.updatedVitals = this.appointment.physicalExam.vitals;
      this.vitals = this.createMetaVitalsList(this.appointment.physicalExam.vitals, 'edit');
    } else {
      this.vitals = this.createMetaVitalsList(this.defaultDoctorPhysicalExam, 'add');
    }
    setTimeout(() => {
      this.isPhysicalExamChange = false;
    }, 100);
  }

  initPhysicalExamsWitValues(physicalExams: any) {
    if (physicalExams) {
      this.vitals = physicalExams.vitals;
    }
  }

  public editEncounter() {
    this.mode = 'edit';
    this.isPreview = false;
  }

  public cancelEncounterEdit() {
    this.isPreview = true;
  }

  public initAddEncounter() {
    this.mode = 'add';
    this.notes = '';
    this.followUp = null;
    this.selectedComplaints = [];
    this.selectedMedicines = [];
    this.selectedObservations = [];
    this.selectedDiagnosis = [];
    this.selectedDiagnosticTests = [];
    this.selectedTimes = [];
    this.selectedDocuments = [];
    this.selectedDuration = null;
    this.selectedShedules = null;
    this.selectedFrequency = null;
    this.selectedQuantity = null;
    this.selectedRoute = null;
    this.physicalExams = {};
    this.initPhysicalExams();
    this.isPreview = false;
    this.isPhysicalExamChange = false;
  }

  closeFolloUp(closeFolloup) {
    if (closeFolloup) {
      this.showFollowUp = false;
      this.isFollowUp = false;
    } else {
      this.isFollowUp = this.isFollowUp;
      this.showFollowUp = this.showFollowUp;
    }
  }

  public nextEncounter() {
    const prevAppointmentStatus = this.appointment.appointmentStatus;
    this.appointment.appointmentStatus = AppointmentStatus.CLOSED;
    const apiEndPoint = this.appointment.appointmentType !== AppointmentType.VIRTUAL ?
      APIEndPoint.UPDATE_APPOINTMENT : APIEndPoint.UPDATE_VIRTUAL_APPOINTMENT;
    if (this.appointment.physicalExam &&
      (this.appointment.physicalExam.vitals === null || this.appointment.physicalExam.vitals.length === 0)) {
      delete this.appointment.physicalExam;
    }
    this.restapiservice.invoke<Appointment>(apiEndPoint,
      { clinicId: this.clinicId, facilityId: this.facilityId, doctorId: this.doctorId, appointmentId: this.appointment.id },
      this.appointment).subscribe(appointment => {
        this.appointment = appointment;
        this.appointmentEncounterService.closeAppointment(this.appointment);
      },
        err => {
          this.appointment.appointmentStatus = prevAppointmentStatus;
        });
  }

  public skipEncounter() {
    this.appointmentEncounterService.skipAppointment(this.appointment);
  }

  public startEncouterForAppointment(appointment: Appointment, appointmentIndex: number) {
    if (this.isDirty()) {
      this.confirmationPopup.confirm({ message: Dictionary.PATIENT_CARD_CONFIRMATION }).subscribe(data => {
        if (data) {
          this.isPhysicalExamChange = false;
          this.closeFolloUp(true);
          this.encounterStarted(appointment, appointmentIndex);
        }
      });
    } else {
      this.isPhysicalExamChange = false;
      this.closeFolloUp(true);
      this.encounterStarted(appointment, appointmentIndex);
    }
  }

  private encounterStarted(appointment: any, appointmentIndex: number) {
    this.appointmentEncounterService.appointmentStarted(appointment, appointmentIndex);
    try {
      if (appointment === null) {
        this.appointment = null;
        this.noAppointment = true;
      } else {
        this.appointment = appointment;
        if (appointment.encounter) {
          if (appointment.encounter.physicalExam && appointment.encounter.physicalExam.vitals.length > 0) {
            this.vitals = this.createMetaVitalsList(appointment.encounter.physicalExam.vitals, 'edit');
          } else {
            this.vitals = this.createMetaVitalsList(this.defaultDoctorPhysicalExam, 'add');
          }
        } else if (appointment.physicalExam) {
          this.physicalExam = appointment.physicalExam;
          this.vitals = this.createMetaVitalsList(appointment.physicalExam.vitals, 'edit');
        } else if (appointment.physicalExam === null) {
          this.physicalExam = appointment.physicalExam;
        }
        this.noAppointment = false;
        if (appointment.appointmentStatus === AppointmentStatus.CLOSED ||
          appointment.appointmentStatus === AppointmentStatus.INPROGRESS) {
          this.previewAppointment();
        } else if (appointment.appointmentStatus === AppointmentStatus.WAIITNG) {
          this.editEncounter();
        } else {
          this.initAddEncounter();
        }
      }
    } catch (e) {
      console.error('error starting encounter', e);
    }
  }


  isDirty() {
    return (this.selectedComplaints.length > 0 ||
      this.selectedDocuments.length > 0 ||
      this.selectedMedicines.length > 0 ||
      this.selectedObservations.length > 0 ||
      this.selectedDiagnosis.length > 0 ||
      this.selectedDiagnosticTests.length > 0 ||
      this.selectedTimes.length > 0 ||
      this.selectedDuration ||
      this.selectedRoute ||
      (this.selectedShedules && this.selectedShedules.length > 0) ||
      this.selectedFrequency || this.notes ||
      // this.isPhysicalExamDirty() ||
      this.isPhysicalExamChange ||
      this.selectedQuantity) && !this.isPreview;
  }



  public previewAppointment() {
    this.isPreview = true;
    this.selectedComplaints = this.appointment.encounter.complaints ? this.appointment.encounter.complaints : [];
    this.selectedDiagnosis = this.appointment.encounter.diagnosis ? this.appointment.encounter.diagnosis : [];
    this.notes = this.appointment.encounter.notes;
    this.selectedObservations = this.appointment.encounter.observations ? this.appointment.encounter.observations : [];
    this.selectedDiagnosticTests = this.appointment.encounter.investigations ? this.appointment.encounter.investigations : [];
    this.selectedMedicines = this.appointment.encounter.medicines ? this.appointment.encounter.medicines : [];
    this.selectedDocuments = this.appointment.encounter.document ? this.appointment.encounter.document : [];
    this.followUp = this.appointment.encounter.followUp ? this.appointment.encounter.followUp : null;
    // this.initPhysicalExamsWitValues(this.appointment.encounter.physicalExam);
  }

  ngOnDestroy() {
    this.initAddEncounter();
  }

}
