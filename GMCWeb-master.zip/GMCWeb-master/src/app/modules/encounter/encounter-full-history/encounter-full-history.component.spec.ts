import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EncounterFullHistoryComponent } from './encounter-full-history.component';

describe('EncounterFullHistoryComponent', () => {
  let component: EncounterFullHistoryComponent;
  let fixture: ComponentFixture<EncounterFullHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EncounterFullHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EncounterFullHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
