import { Component, OnInit, OnDestroy } from '@angular/core';
import { Appointment, Encounter, Patient } from 'app/core/models/app.models';
import { RestapiService } from 'app/core/services/restapi.service';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Observable } from 'rxjs/Observable';
import { ConfirmationPopupService } from 'app/core/services/confirmation-popup.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Subject } from 'rxjs/Subject';
import { Location } from '@angular/common';
import { AuthService } from 'app/core/auth/auth.service';
import { Dictionary } from 'app/core/models/dictionary';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-encounter-full-history',
  templateUrl: './encounter-full-history.component.html',
  styleUrls: ['./encounter-full-history.component.css']
})
export class EncounterFullHistoryComponent implements OnInit, OnDestroy {
  public encounters$: Observable<Encounter[]>;
  public clinicId: string;
  public facilityId: string;
  public patientId: string;
  public doctorId: string;
  public doctorID: string;
  public encounterId: string;
  private unsubscribe = new Subject();
  patient$: Observable<Patient>;
  public showPresShare = false;
  public showAccess = false;
  public _patientList = new Subject<Patient[]>();
  public patientList$ = this._patientList.asObservable();
  public patientList: Patient[] = [];



  constructor(
    private restapiservice: RestapiService,
    public confirmationPopup: ConfirmationPopupService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private authService: AuthService,
    private toastrService: ToastrService,
    private location: Location
  ) { }

  public getPatientHistory() {
    return this.restapiservice.invoke<Encounter[]>(APIEndPoint.GET_ENCOUNTERS_WITH_DOC,
      { clinicId: this.clinicId, facilityId: this.facilityId, patientId: this.patientId, doctorId: this.doctorId });
  }

  public getPatientHistoryByPatients() {
    return this.restapiservice.invoke<Encounter[]>(APIEndPoint.GET_ENCOUNTERS_BY_PATIENT_ID,
      { clinicId: this.clinicId, doctorId: this.doctorId, patientId: this.patientId });
  }


  public getPatientDetails(): Observable<Patient> {
    return this.restapiservice.invoke<Patient>(APIEndPoint.GET_PATIENT_BY_ID, { clinicId: this.clinicId, patientId: this.patientId });
  }

  Back() {
    this.location.back();
  }

  onShare(encounterid) {
    this.showPresShare = !this.showPresShare;
    this.encounterId = encounterid;

  }
  onAccess(encounterid) {
    console.log('hello');
    this.showAccess = !this.showAccess;
    console.log('hello', this.showAccess);
    this.encounterId = encounterid;
  }
  viewEncounter(encounterid, facilityId?) {
    if (this.facilityId) {
      this.router.navigate(['./clinic-view/clinics/' + this.clinicId + '/facilities/' +
        this.facilityId + '/doctors/' + this.doctorId +
        '/patients/' + this.patientId + '/encounters/' + encounterid]);
    } else {
      this.router.navigate(['./clinic-view/clinics/' + this.clinicId + '/facilities/' +
        facilityId + '/doctors/' + this.doctorId +
        '/patients/' + this.patientId + '/encounters/' + encounterid]);
    }


  }
  ngOnInit() {
    Observable.combineLatest(this.activatedRoute.parent.params, this.activatedRoute.params)
      .takeUntil(this.unsubscribe).subscribe(responses => {
        this.clinicId = responses[0].clinicId;
        this.facilityId = responses[0].facilityId;
        this.doctorId = responses[1].doctorId;
        this.patientId = responses[1].patientId;
        console.log('clinicid', this.clinicId);
        this.getPatientHistory();
        this.patient$ = this.getPatientDetails();
        if (this.facilityId) {
          this.encounters$ = this.getPatientHistory();
        } else {
          this.encounters$ = this.getPatientHistoryByPatients();
          this.encounters$.subscribe(res => {
            console.log('patienthistory', res);
          });
        }
      });
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  public editPatient(patientId) {
    console.log('patientId', patientId);
    this.router.navigate(['./clinic-view/clinics/' + this.clinicId + '/patients/' + patientId + '/edit']);
  }

}
