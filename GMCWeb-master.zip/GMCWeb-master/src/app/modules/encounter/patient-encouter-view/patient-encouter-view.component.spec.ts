import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PatientEncouterViewComponent } from './patient-encouter-view.component';

describe('PatientEncouterViewComponent', () => {
  let component: PatientEncouterViewComponent;
  let fixture: ComponentFixture<PatientEncouterViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PatientEncouterViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PatientEncouterViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
