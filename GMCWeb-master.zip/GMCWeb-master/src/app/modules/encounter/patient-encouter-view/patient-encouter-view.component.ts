import { Component, OnInit, OnDestroy, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { RestapiService } from 'app/core/services/restapi.service';
import { Encounter, Document } from 'app/core/models/app.models';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';
import { Response } from '@angular/http';
import { Location } from '@angular/common';
import { DownloadFileService } from 'app/core/services/download-file.service';


@Component({
  selector: 'app-patient-encouter-view',
  templateUrl: './patient-encouter-view.component.html',
  styleUrls: ['./patient-encouter-view.component.css'],
  encapsulation: ViewEncapsulation.None
})
export class PatientEncouterViewComponent implements OnInit, OnDestroy {
  public clinicId: string;
  public facilityId: string;
  public patientId: string;
  public doctorId: string;
  public encounterId: string;
  public patientEncounterView: Encounter;
  private unsubscribe = new Subject();
  public selectedDocuments: Document[];
  public searchText;

  constructor(
    private restapiservice: RestapiService,
    private router: Router,
    public downloadFileService: DownloadFileService,
    private location: Location,
    private activatedRoute: ActivatedRoute) { }

  getPatientDetails() {
    this.restapiservice.invoke<Encounter>(APIEndPoint.GET_ENCOUNTER_BY_ID,
      {
        clinicId: this.clinicId, facilityId: this.facilityId, patientId: this.patientId,
        encounterId: this.encounterId
      }).takeUntil(this.unsubscribe).subscribe(res => {
        console.log('sdfsdfsdf', res);
        this.patientEncounterView = res;
        this.selectedDocuments = res.document;
      });
  }


  printPrescription(event) {
    console.log('event', event);
    // tslint:disable-next-line:max-line-length
    // this.restapiservice.printHTML(`/api/clinics/1/facilities/1/patients/${this.patientId}/encounter/${this.patientEncounterView.id}/viewHTML`)
    // .subscribe(data => {
    // //   const pdfFile = new Blob([ data ], {
    // //     type : 'application/pdf'
    // // });
    // // const pdfUrl = URL.createObjectURL(pdfFile);
    // const h = window.innerHeight * 0.9;
    // const w = window.innerWidth * 0.8;
    // const printwWindow = window.open('', '_blank', 'toolbar=no,scrollbars=yes,resizable=yes,location=no,top=100,left=100,width='
    // + w + ',height=' + h);
    // if (!printwWindow) {
    //   alert('Please allow pop-ups on this site!');
    // }
    // printwWindow.document.write(data.body.toString());
    // printwWindow.print();
    // });
    if (event) {
      this.router.navigate(['/print'], {
        queryParams:
        {
          clinicId: this.clinicId,
          facilityId: this.facilityId,
          doctorId: this.doctorId,
          patientId: this.patientId,
          encounterId: this.encounterId,
          emrType: this.patientEncounterView.emrType,
          from: 'patientEncounter'
        }
      });
    }
  }
  ngOnInit() {
    Observable.combineLatest(this.activatedRoute.parent.params, this.activatedRoute.params)
      .takeUntil(this.unsubscribe).subscribe(responses => {
        console.log(responses);
        this.clinicId = responses[0]['clinicId'];
        this.facilityId = responses[0]['facilityId'];
        this.doctorId = responses[1]['doctorId'];
        this.patientId = responses[1]['patientId'];
        this.encounterId = responses[1]['encounterId'];
        this.getPatientDetails();
      });
  }
  goBack() {
    this.location.back();
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
