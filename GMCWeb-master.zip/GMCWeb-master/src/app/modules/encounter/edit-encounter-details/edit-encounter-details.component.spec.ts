import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EditEncounterDetailsComponent } from './edit-encounter-details.component';

describe('EditEncounterDetailsComponent', () => {
  let component: EditEncounterDetailsComponent;
  let fixture: ComponentFixture<EditEncounterDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EditEncounterDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EditEncounterDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
