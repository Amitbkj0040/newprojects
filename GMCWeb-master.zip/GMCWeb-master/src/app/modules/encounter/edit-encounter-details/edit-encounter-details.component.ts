import { Component, OnInit, Input, OnDestroy, ViewChild, HostListener } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as _ from 'lodash';
import { APIDef } from 'app/core/models/ApiEndPoint';
import { RestapiService } from 'app/core/services/restapi.service';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
declare var document: any;
@Component({
  selector: 'app-edit-encounter-details',
  templateUrl: './edit-encounter-details.component.html',
  styleUrls: ['./edit-encounter-details.component.css']
})
export class EditEncounterDetailsComponent implements OnInit, OnDestroy {
  @ViewChild('fullScreen') divRef;
  @Input() api: APIDef;
  @Input() options: { placeholder?: string, required?: boolean, disable?: boolean };
  @Input() keyName: any = null;
  @Input() selectedData: string[] = [];

  public suggestions$: Observable<any>;
  public selectedDataValue: any = [];
  private unsubscribe = new Subject<void>();
  public draggable = {
    data: 'myDragData',
    effectAllowed: 'all',
    disable: false,
    handle: false
  };
  public isFullScreen = false;

  public isEditEncounter = false;

  constructor(
    public activatedRoute: ActivatedRoute,
    public router: Router,
    public restApiService: RestapiService
  ) { }

  ngOnInit() {

  }

  @HostListener('document:fullscreenchange', ['$event'])
  public fullScreen(event) {
    if (this.divRef) {
      if (!document.fullscreen) {
        this.isFullScreen = false;
      }
    }
  }

  public openEditEncounterField() {
    this.suggestions$ = this.restApiService
      .invoke<any>(this.api, null, null, { search: 'cough' });
    this.isEditEncounter = true;
  }

  public onDrop(event, from?) {
    if (from === 'FROM_DROP') {
      event = event.data;
    }
    if (event.name) {
      if (!this.selectedData.includes(event.name)) {
        this.selectedData.push(event.name);
      }
    }
  }

  public closeEncounter() {
    this.isEditEncounter = false;
    this.isFullScreen = false;
  }

  public resetSelectedData() {
    this.selectedData = [];
  }

  removeDataFromSelectedData(data) {
    this.selectedData.splice(this.selectedData.findIndex(element => element === data), 1);
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }

  openFullscreen() {
    if (!this.isFullScreen) {
      this.isFullScreen = true;
      if (this.divRef.nativeElement.requestFullscreen) {
        this.divRef.nativeElement.requestFullscreen();
      } else if (this.divRef.nativeElement.mozRequestFullScreen) {
        /* Firefox */
        this.divRef.nativeElement.mozRequestFullScreen();
      } else if (this.divRef.nativeElement.webkitRequestFullscreen) {
        /* Chrome, Safari and Opera */
        this.divRef.nativeElement.webkitRequestFullscreen();
      } else if (this.divRef.nativeElement.msRequestFullscreen) {
        /* IE/Edge */
        this.divRef.nativeElement.msRequestFullscreen();
      }
    } else {
      document.exitFullscreen();
      this.isFullScreen = false;
    }
  }
}
