import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from 'app/shared/shared.module';
import { DndModule } from 'ngx-drag-drop';
import { EncounterComponent } from 'app/modules/encounter/encounter.component';
import { EncounterPreviewComponent } from 'app/modules/encounter/encounter-preview/encounter-preview.component';
import { PatientEncounterComponent } from 'app/modules/encounter/patient-encounter/patient-encounter.component';
import { EncounterHistoryComponent } from 'app/modules/encounter/encounter-history/encounter-history.component';
import { EncounterFullHistoryComponent } from 'app/modules/encounter/encounter-full-history/encounter-full-history.component';
import { PatientEncouterViewComponent } from 'app/modules/encounter/patient-encouter-view/patient-encouter-view.component';
import { EncounterRoutingModule } from 'app/modules/encounter/encounter.routes';
// import { EncounterMedicinesComponent } from 'app/modules/encounter/encounter-medicines/encounter-medicines.component';
import { EditEncounterDetailsComponent } from 'app/modules/encounter/edit-encounter-details/edit-encounter-details.component';
import { DoctorEncountersComponent } from './doctor-encounters/doctor-encounters.component';


@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    EncounterRoutingModule,
    DndModule
  ],
  declarations: [
    EncounterComponent,
    EncounterPreviewComponent,
    PatientEncounterComponent,
    EncounterHistoryComponent,
    EncounterFullHistoryComponent,
    PatientEncouterViewComponent,
    // EncounterMedicinesComponent,
    EditEncounterDetailsComponent,
    DoctorEncountersComponent
  ]
})
export class EncounterModule { }
