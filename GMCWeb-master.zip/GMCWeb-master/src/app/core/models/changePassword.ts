export interface ChangePassword {
    loginName: string;
    oldPassword: string;
    confirmNewPassword: string;
    newPassword: string;
}
