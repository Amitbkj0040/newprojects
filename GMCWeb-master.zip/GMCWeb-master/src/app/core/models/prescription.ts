export interface Prescription {
id: number;
name: string;
emr: object;
dose: string;
frequency: string;
form: string;
duration: string;
}

