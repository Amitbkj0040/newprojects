export interface MedicineTagInstruction {
    tagId: string;
    tagName: string;
    isInstruction: boolean;
    schedule: string[];
    time: string[];
    duration: string;
    frequency: string;
    quantity: string;
    route: string;
}