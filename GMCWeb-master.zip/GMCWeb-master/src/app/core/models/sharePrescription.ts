export interface SharePrescription {
    emrId: string;
    isExpiration?: boolean;
    expirationDay?: string;
    message?: string;
    prescriptionwrapper: [
        {
            email: string;
            id: string;
        }
    ];
}
