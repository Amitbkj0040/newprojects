export interface AuthToken {
    access_token: string;
    expires_in: number;
    refresh_token: string;
}

export interface Doctor {
    id: string;
    practiceLicense: string;
    qualification?: string;
    specialistIn: {
        name?: string;
        id: number;
    };
    staffType: string;
    clinic: {
        id: string;
    };
    signature: string;
    title: string;
    firstName: string;
    lastName?: string;
    phone: string;
    alterPhone?: string;
    address: {
        address1: string,
        address2?: string,
        addressType: string,
        city: {
            id: number,
            // state: {
            // country: {
            // id: number
            // },
            // id: number
            // }
        },
        zip: string,
        country?: Country;
    };
    user: {
        loginName: string;
        isOwner: boolean;
    };
    dob: string;
    age: string;
    gender: string;
    document?: Document[];
    bloodGroup?: string;
    email?: string;
    occupation?: string;
    logo?: string;
    loginName?: string;
    metaVitals?: [{
        id?: string;
        name?: string;
        unit?: string;
    }];
}

export interface Country {
    countryCode?: string;
    countryIATACode?: string;
    id: string;
    name: string;
    pinCodeLength: number;
}

export interface Document {
    id?: string;
    documentType?: string;
    documentName?: string;
    entityType: string;
    URI?: string;
    fileName: string;
    fileUploadId?: number;
}

export interface UploadDocumentResponse {
    fileName: string;
    fileUploadId: number;
    fileDownloadUri: string;
    fileType: string;
    size: number;
}


export interface PhysicalExam {
    id?: number;
    name?: string;
    unit?: string;
    vitals?: any[];
    metaPhysicalExam?: {
        id?: string;
        name?: string;
        unit?: string;
    };
    observedValue?: string;
    observedImage?: string;
    Observation?: string;
    Impression?: string;
}

export interface DocumentType {
    id?: number;
    name?: string;
}


export interface Facility {
    id: string;
    address: {
        address1: string,
        address2?: string,
        addressType: string;
        city: {
            id: number
            // state: {
            //     country: {
            //         id: number
            //     },
            //     id: number
            // }
        },
        country: Country
        zip: string;
        locality?: string;
    };
    announcement?: string;
    clinic: {
        id: string
    };
    description: string;
    email?: string;
    name: string;
    // area: string;
    phone?: number;
    alternatephone?: number;
    specialities: [{
        id: number;
    }];
}

export interface AddStaff {
    staffType: string;
    clinic: {
        id: number
    };
    signature: string;
    title: string;
    firstName: string;
    lastName: string;
    phone: number;
    alterPhone: number;
    address?: {
        address1: string;
        address2: string;
        addressType: string;
        city: {
            name: string;
            id: number;
        },
        country: {
            id: any;
        }
        zip: number
    };
    user: {
        loginName: string;
        isOwner: boolean;
    };
    dob: string;
    gender: string;
    email: string;
    bloodGroup: string;
    occupation: string;
    logo?: string;
    document?: Document[];
}


export class StaffSchedule {
    constructor(public startDate: string,
        public endDate: string,
        // public scheduleTimings: Map<'MONDAY' | 'TUESDAY' | 'WEDNESDAY'
        // | 'THURSDAY' | 'FRIDAY' |'SATURDAY' | 'SUNDAY', ScheduleTiming[]>,
        public scheduleTimings: Map<string, ScheduleTiming[]>,
        public id?: string) {

    }

    public static fromHTTPStaffSchedule(httpStaffSchedule: HTTPStaffSchedule): StaffSchedule {
        return new StaffSchedule(httpStaffSchedule.startDate,
            httpStaffSchedule.endDate,
            this.objectToMap(httpStaffSchedule.scheduleTimings),
            httpStaffSchedule.id);
    }

    private static objectToMap(obj): Map<string, ScheduleTiming[]> {
        const map = new Map();
        for (const property in obj) {
            if (obj.hasOwnProperty(property)) {
                map.set(property, obj[property]);
            }
        }
        return map;
    }

    toHTTPStaffSchedule(): HTTPStaffSchedule {
        return new HTTPStaffSchedule(this.startDate, this.endDate, this.mapToObject(this.scheduleTimings));
    }

    private mapToObject(map): Map<any, any> {
        const obj = Object.create(null);
        map.forEach((value, key) => {
            if (value instanceof Map) {
                obj[key] = this.mapToObject(value);
            } else {
                obj[key] = value;
            }
        });
        return obj;
    }
}

export class ScheduleTiming {
    id?: string;
    dayOfWeek: string;
    startTime: string;
    endTime: string;
    monthWeekAvailablities: WeekStatus;
    constructor(startTime: string, endTime: string, monthWeekAvailablities: WeekStatus) {
        this.startTime = startTime;
        this.endTime = endTime;
        this.monthWeekAvailablities = monthWeekAvailablities;
    }
}

export class WeekStatus {
    constructor(public firstWeek: boolean,
        public secondWeek: boolean,
        public thirdWeek: boolean,
        public fourthWeek: boolean,
        public fifthWeek: boolean) { }
}

export enum DayOfWeek {
    SUNDAY = 'SUNDAY',
    MONDAY = 'MONDAY',
    TUESDAY = 'TUESDAY',
    WEDNESDAY = 'TUESDAY',
    THURSDAY = 'THURSDAY',
    FRIDAY = 'FRIDAY',
    SATURDAY = 'SATURDAY'
}

export enum DayOfWeekIndex {
    SUNDAY = 0,
    MONDAY,
    TUESDAY,
    WEDNESDAY,
    THURSDAY,
    FRIDAY,
    SATURDAY
}

export enum TimingMode {
    EDIT,
    ADD
}

export class HTTPStaffSchedule {
    constructor(public startDate: string,
        public endDate: string,
        public scheduleTimings: {},
        public id?: string) {

    }
}

export interface Appointment {
    appointmentDate: string;
    appointmentStatus: string;
    appointmentType?: string;
    startTime: string;
    patient: Patient;
    id?: string;
    onlineId?: string;
    encounter?: Encounter;
    physicalExam?: any;
}

export interface AppointmentSlotForDates {
    dates: string[];
    slotAppointments: AppointmentSlot[];
}


export interface AppointmentSlot {
    appointment: Appointment;
    slot: string;
}

export interface Patient {
    id?: string;
    uhid?: string;
    title?: string;
    firstName?: string;
    lastName?: string;
    phone?: string;
    alterPhone?: string;
    address?: {
        address1?: string;
        address2?: string;
        addressType?: string;
        city?: {
            id: number
        };
        zip?: string
    };
    dob?: Date;
    document?: Document[];
    age?: string;
    gender?: string;
    email?: string;
    bloodGroup?: string;
    occupation?: string;
}

export interface Encounter {
    complaints: string[];
    doctor: {
        id: string
        physicalExam?: string[];
    };
    // facility: {
    //     id?: string;
    // };
    physicalExam?: PhysicalExam;
    diagnosis: string[];
    notes: string;
    followUp?: FollowUp;
    medicines: Medicine[];
    observations: string[];
    investigations: string[];
    creationDate?: string;
    patient?: Patient;
    id?: string;
    appointment?: Appointment;
    document?: Document[];
    emrType?: string;
}

export interface Staff {
    staffType: string;
    clinic: {
        id: number
    };
    signature: string;
    title: string;
    firstName: string;
    lastName: string;
    phone: number;
    alterPhone: number;
    address: {
        address1: string;
        address2: string;
        addressType: string;
        city: {
            name: string;
            id: number;
        },
        zip: number
    };
    dob: string;
    gender: string;
    email: string;
    bloodGroup: string;
    occupation: string;
}

export interface FollowUp {
    days?: number;
    weeks?: number;
    months?: number;
}

export interface Medicine {
    medicineId?: string;
    highlightedName?: string;
    name: string;
    quantity: string;
    frequency: string;
    route: string;
    time: string[];
    duration: string;
    schedule: string[];
    tagList: any[];
    activeTag: any;
}

export interface Complaint {
    name: string;
}

export interface MedQuantity {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedRoute {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedTime {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedSchedule {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedQuantity {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedDuration {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedFrequency {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedName {
    name: string;
}

export interface Domain {
    name: string;
}

export interface GMParam {
    doctor?: Doctor;
    facility?: Facility;
    staff?: Staff;
}

export enum AppointmentStatus {
    CONFIRMED = 'CONFIRMED',
    CLOSED = 'CLOSED',
    CANCEL = 'CANCEL',
    WAIITNG = 'WAIITNG',
    INQUEUE = 'INQUEUE',
    INPROGRESS = 'INPROGRESS'
}

export enum AppointmentType {
    ONLINE = 'ONLINE',
    OFFLINE = 'OFFLINE',
    VIRTUAL = 'VIRTUAL'
}
export enum StaffType {
    DOCTOR = 'DOCTOR',
    SUPPORT_STAFF = 'SUPPORT_STAFF',
    ADMIN = 'ADMIN'
}

export enum KeyType {
    KEY_ARROW_DOWN = 40,
    KEY_ARROW_UP = 38,
    KEY_ENTER = 13,
    KEY_ESCAPE = 27
}

export interface UploadFile {
    documentType: string;
    entityType: string;
    URI: string;
    fileName: string;
}

export interface Event {
    id: number;
    eventName: string;
}
