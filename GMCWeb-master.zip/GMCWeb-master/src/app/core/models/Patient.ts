export interface Patient {
    id?: string;
    title: string;
    firstName: string;
    lastName: string;
    phone: string;
    alterPhone?: string;
    address: {
    address1: string;
    address2?: string;
    addressType: string;
    city: {
    id: number
    };
    zip: string
    };
    dob: Date;
    document?: Document[];
    age: string;
    gender: string;
    email?: string;
    bloodGroup?: string;
    occupation?: string;
    uhid?: string;
}


