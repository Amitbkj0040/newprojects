export interface Speciality {
    id: string;
    name: string;
}

