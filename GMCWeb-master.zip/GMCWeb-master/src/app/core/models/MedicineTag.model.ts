import { MedicineTagInstruction } from './MedicineTagInstruction.model'
export interface MedicineTag {
    medicineId: string;
    medicineName: string;
    tagList: MedicineTagInstruction[];
}