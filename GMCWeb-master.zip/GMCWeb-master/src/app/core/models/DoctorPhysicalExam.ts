export interface DoctorPhysicalExam {
    id: number;
    name: string;
    units: Unit[];
}

interface Unit {
    id: number;
    name: string;
    lowerBound: string;
    upperBound: string;
    description: string;
    defaultValue?: any;
}