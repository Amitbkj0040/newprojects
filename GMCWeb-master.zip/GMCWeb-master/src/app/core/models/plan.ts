export interface Plan {
id: number;
name: string;
description: string;
rate: number;
startDate: Date;
duration: number;
durationUnit: string;
offer: string;
isActive: boolean;
isApproved: string;
approvedBy: string;
termsConditions: string;
}
