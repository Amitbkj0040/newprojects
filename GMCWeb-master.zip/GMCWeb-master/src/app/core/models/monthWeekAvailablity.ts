export interface MonthWeekAvailablity {
id: number;
staffSchedule: object;
firstWeek: boolean;
secondWeek: boolean;
thirdWeek: boolean;
fourthWeek: boolean;
fifthWeek: boolean;

}




