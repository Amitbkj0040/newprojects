export interface Subscription {
    id?: string;
    isSubscriptionActive: Boolean;
    startDate?: Date;
    endDate?: Date;
    subscribedPlan?: {
        id: string;
        name: string;
        description?: string;
        rate: string;
        startDate?: Date;
        duration: string;
        features: string[
        ]
    };
    clinic?: {
        name?: string;
    };
}

