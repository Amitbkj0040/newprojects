export interface EMR {
id: number;
patient: object;
doctor: object;
facility: object;
complaint: string;
startTime: Date;
endTime: Date;
physicalExams: string;
assessments: string;
emrSuggestion: Array<object>;
prescription: Array<object>;

}




