export interface CurrentDate {
    dateString?: Date;
    year?: number;
    month?: number;
    day?: number;
    date?: number;
}
