export interface State {
    cities: Array<object>;
    country: object;
    id: number;
    name: string;
}

