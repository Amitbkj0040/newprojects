export interface City {
        id: number;
        name: string;
        // state: {
        //   id: number;
        //   name: string;
        //   country: {
        //     id: number;
        //     name: string;
        //   }
        // };
      }
