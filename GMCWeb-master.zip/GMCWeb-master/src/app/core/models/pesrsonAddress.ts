

export interface PersonAddress {
id: number;
addressType: string;
address1: string;
address2?: string;
city: object;
State: object;
country: object;
zip: string;
person: object;
}
