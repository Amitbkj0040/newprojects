export interface EncounterInstruction {
    id: string;
    name: string;
    description: string;
  }