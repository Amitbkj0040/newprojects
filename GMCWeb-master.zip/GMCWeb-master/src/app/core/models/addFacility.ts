

export interface AddFacility {
    address: {
        address1: string,
        address2?: string,
        addressType: string;
        city: {
            id: number
            // state: {
            //     country: {
            //         id: number
            //     },
            //     id: number
            // }
        },
        zip: string
    };
    announcement?: string;
    clinic: {
        id: string
    };
    description: string;
    email?: string;
    name: string;
    // area: string;
    phone?: number;
    alternatephone?: number;
    specialities: [{
        id: number;
    }];
}
