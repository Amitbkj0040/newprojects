export interface Education {
    id: number;
    doctor: object;
    degreeName: string;
    specialization: string;
    collegeName: string;
    universityName: string;
    graduationYear: number;
    marks: number;
    marksType: object;
}





