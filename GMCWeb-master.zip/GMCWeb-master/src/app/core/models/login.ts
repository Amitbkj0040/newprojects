export interface Login {
phone: string;
password: string;

}
