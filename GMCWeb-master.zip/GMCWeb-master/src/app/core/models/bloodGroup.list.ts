export const BLOOD_GROUPS = [
    { value: 'A_POS', label: 'A+' }, { value: 'A_NEG', label: 'A-' },
    { value: 'B_POS', label: 'B+' }, { value: 'B_NEG', label: 'B-' },
    { value: 'O_POS', label: 'O+' }, { value: 'O_NEG', label: 'O-' },
    { value: 'AB_POS', label: 'AB+' }, { value: 'AB_NEG', label: 'AB-' }
];
