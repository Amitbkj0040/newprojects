export interface Register {
    id?: number;
    phone: string;
    loginName: string;
    password: string;
    confirmPassword: string;
    otp: number;
    isDoctor: boolean;
    specialistIn: {
        name?: string;
        description?: string;
        id: number;
    };
}
