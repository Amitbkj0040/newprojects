export interface ForgetPassword {
    loginName: string;
    oldPassword: string;
    confirmNewPassword: string;
    newPassword: string;
}
