export interface Country {
    id?: string;
    name?: string;
    countryCode?: string;
    countryIATACode?: string;
    pinCodeLength?: number;
}
export const DEFAULT_COUNTRY = { id: '1', name: 'India', countryCode: '91', countryIATACode: 'IN', pinCodeLength: 6};





