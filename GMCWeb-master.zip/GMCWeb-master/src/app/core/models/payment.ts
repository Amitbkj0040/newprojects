export interface Payment {
id: number;
paidOn: Date;
paymentReference: string;
amount: number;
subscribedPlan: object;
clinic: object;
}
