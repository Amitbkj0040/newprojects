export interface Otp {
    otpFor: string;
}
