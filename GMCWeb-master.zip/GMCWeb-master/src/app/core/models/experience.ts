export interface Experience {
id: number;
doctor: object;
orgName: string;
designation:  string;
startDate: Date;
endDate: Date;
workDetails: string;
}

