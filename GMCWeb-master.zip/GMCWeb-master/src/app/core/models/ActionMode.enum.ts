export enum Mode {
    ADD = 'add',
    EDIT = 'edit'
}