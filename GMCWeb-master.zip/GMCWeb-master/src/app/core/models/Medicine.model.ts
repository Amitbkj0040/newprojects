export interface Medicine {
    medicineId?: string;
    highlightedName?: string;
    name: string;
    quantity: string;
    frequency: string;
    route: string;
    time: string[];
    duration: string;
    schedule: string[];
    tagList: any[];
    activeTag: any;
}


export interface MedQuantity {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedSchedule {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedTime {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedFrequency {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedDuration {
    name: string;
    id: string;
    isSelected: boolean;
}

export interface MedRoute {
    name: string;
    id: string;
    isSelected: boolean;
}