export interface AddStaff {
    staffType: string;
    clinic: {
        id: number
    };
    signature: string;
    title: string;
    firstName: string;
    lastName: string;
    phone: number;
    alterPhone: number;
    address: {
        address1: string;
        address2: string;
        addressType: string;
            city: {
                name: string;
                id: number;
            },
        zip: number
    };
    dob: string;
    gender: string;
    email: string;
    bloodGroup: string;
    occupation: string;
}
