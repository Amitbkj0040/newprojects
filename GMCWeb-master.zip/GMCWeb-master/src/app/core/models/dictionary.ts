export class Dictionary {
    public static ERROR_MSG = 'some error occured';
    public static DOMAIN_EXIST = ' Domain exists, please use another name.';
    public static LOGIN_NAME_EXIST = ' LoginName exists, please use another name.';
    public static LOGIN_ERROR = 'Couldn\'t login now. Please try later.';
    public static FIRSTNAME_REQ = 'First Name is required, enter the first name';
    public static AGE_REQ = 'Age is required, enter the age';
    public static GENDER_REQ = 'Gender is required, select the gender';
    public static CITY_REQ = 'City is required, please select the city';
    public static ZIP_REQ = 'Zip is required, please enter the zip';
    public static PHONE_REQ = 'Phone is required, please enter correct Phone Number';
    public static SPECIALITY_REQ = 'Please select the specialities';
    public static PASSWORD_REQ = 'Password is required, please enter Password';
    public static OTP_SUCCESS = 'Otp sent successfully on your Mobile Number and is valid for the 30 minutes';
    public static DELETE_CONFIRMATION = 'Do you want to delete this data?';
    public static REVOKE_ACCESS = 'Do you want to Revoke Access Permission?';
    public static OVERLAPPING_CONFIRMATION = 'Do you want to Overlap this date?';
    public static SELECT_DATE_ALERT = 'please select the date range';
    public static CANCEL_CONFIRMATION = 'Do you want to leave this page without saving?';
    public static CHECK_CONFIRMATION = 'Do you want to Cancel all Appointments?';
    public static BACK_CONFIRMATION = 'Do you want to leave this page';
    public static PATIENT_CARD_CONFIRMATION = 'Do you want to change the patient without saving?';
    public static LEAVE_PAGE_ALERT = 'Are you sure you want to leave ?';
    public static SCHEDULE_ADD = 'Schedule is saved successfully';
    public static SCHEDULE_UPDATE = 'Schedule has been updated successfully';
    public static ENTITY_DELETION = 'Your data has been deleted successfully';
    public static SUCCESSFUL_PASSWORD_RESET = 'Your password-reset is successful';
    public static NO_DOCTOR_FOUND = 'No Doctor found please register a doctor to access clinic view';
    public static ADD_DOCTOR_ALERT = 'Now Add Your Doctor';
    public static SELECT_VALUE_ALERT = 'Please select the value';
    public static UNREGISTERED_USER = 'User is Not Registered';
    public static IMPORT_PATIENT_SELECTION_ERROR = 'Please Select Patient to import';
    public static IMPORT_PATIENT_SUCCESS = 'Successfully imported patient data';
    public static DELETE_LIST_ALERT = 'This is the last facility , you can not delete this';
    public static EMAIL_SUCCESS = 'Email sent successfully';
    public static SUCCESSFUL_PASSWORD_CHANGED = 'Password Changed successfully';
    public static DISCARD_MEDICINE_INSTRUCTION = 'Do you want to discard changes?';
    public static REMOVE_MEDICINE = 'Do you want to remove the medicine?';
    public static RESET_MEDICINE_INSTRUCTION = 'Do you want to reset current Medicine data';
    public static DELETE_MEDICINE_FROM_MEDICINE_LIST = 'Do you want to delete this medicine ?'
    public static ALREADY_MEDICINE_EXIST = 'Medicine already exist in collection';
    public static ALREADY_IN_EDIT_MODE = 'Medicine already in edit mode';
    public static CHANGE_FORMAT = 'Your csv file contains insufficient data. Please Change format';
    public static DELETE_APPOINTMENT_SUCCESS = 'Delete appointment successfully';
    public static DELETE_APPOINTMENT_ERROR = 'Sorry! Unable to delete appointment';
    // tslint:disable-next-line:max-line-length
    public static ADDRESS_MESSAGE = 'If any of the three fields(Address1, City, ZIP) are missing, address will not be saved. Do you want to continue?';
    public static PATIENT_APPOINTMENT_CONFIRMATION =
        'Appointment for this patient has already booked, Do you want to book appointment again';
    public static ONLINE_PATIENT_APPOINTMENT_CONFIRMATION =
        'Do you Want to convert this patient from Online to Offline ?';
    public static CREDENTIAL_ERROR = 'Either Password or username is incorrect. Please enter correct credentials';
    public static MEDICINE_EMPTY_ERROR = 'Please select Medicine';
    public static PHONE_NO_MSG = 'Please enter valid phone no.';
    public static ALTERNATE_PHONE_NO_MSG = 'Please enter valid alternate phone no.';
    public static APPOINTMENT_CONFIRMATION = (input: DictMessage) => `Appointment confirmed for
    ${input.EntityName} for ${input.Date} ${input.Slot}`
    public static SUCCESSFUL_REGISTRATION = (input: DictMessage) => `${input.EntityName} is registered successfully`;
    public static SUCCESSFUL_ADDITION = (input: DictMessage) => `${input.EntityName}  is saved successfully`;
    public static SUCCESSFUL_UPDATION = (input: DictMessage) => `${input.EntityName} has been successfully updated`;
    public static SUCCESSFUL_TIME_SLOT_UPDATION =
        (input: DictMessage) => `${input.Slot} has been successfully updated to ${input.EntityName}`
    // public static SUCCESSFUL_DELETION = (input: DictMessage) => `${input.EntityName} is deleted successfully`;


}

export interface DictMessage {
    EntityName?: string;
    Name?: string;
    Date?: string;
    Slot?: string;
}
