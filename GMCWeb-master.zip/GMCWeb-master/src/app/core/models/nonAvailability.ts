export interface NonAvailability {
    id?: string;
    startDate: string;
    endDate: string;
    startTime: string;
    endTime: string;
    title: string;
    notifyAndReplace?: boolean;
    notifyAndCancel?: boolean;
    doctorSubstituteVO: {
        type?: string;
        name?: string;
        email: string;
        designation?: string;
        } | null;
}
