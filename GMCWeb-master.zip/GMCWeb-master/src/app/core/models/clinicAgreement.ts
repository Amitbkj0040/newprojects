export interface ClinicAgreement {
    isAgreementSigned: Boolean;
  }
