
export interface StaffSchedule {
  id?: string;
  startDate: string;
  endDate: string;
  scheduleTimings:  Map<string, ScheduleTiming[]>;
}

export class ScheduleTiming {
  dayOfWeek: string;
  startTime: string;
  endTime: string;
  monthWeekAvailablities: WeekStatus;
}

export class WeekStatus {
      firstWeek: boolean;
      secondWeek: boolean;
      thirdWeek: boolean;
      fourthWeek: boolean;
      fifthWeek: boolean;
}

export enum DayOfWeek {
  SUNDAY = 'SUNDAY',
  MONDAY= 'MONDAY',
  TUESDAY = 'TUESDAY',
  WEDNESDAY = 'TUESDAY',
  THURSDAY = 'THURSDAY',
  FRIDAY = 'FRIDAY',
  SATURDAY = 'SATURDAY'
}








// export interface StaffSchedule {
//   id: string;
//   startDate: string;
//   endDate: string;
//   scheduleTimings: ScheduleTiming[] | ScheduleTiming[][];
// }

// export class ScheduleTiming {
//   dayOfWeek: string;
//   startTime: string;
//   endTime: string;
//   monthWeekAvailablities: WeekStatus;
// }

// export class WeekStatus {
//       firstWeek: boolean;
//       secondWeek: boolean;
//       thirdWeek: boolean;
//       fourthWeek: boolean;
//       fifthWeek: boolean;
// }

// export enum DayOfWeek {
//   SUNDAY, MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY
// }


