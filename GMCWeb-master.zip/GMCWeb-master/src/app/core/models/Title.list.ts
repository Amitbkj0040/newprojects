export const Title: Title[] = [
    {
        label: 'Mr',
        value: 'Mr'
    },
    {
        label: 'Mrs',
        value: 'Mrs'
    },
    {
        label: 'Ms',
        value: 'Ms'
    }
];


interface Title {
    label: string;
    value: string;
}