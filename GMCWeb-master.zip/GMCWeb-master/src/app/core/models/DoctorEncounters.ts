import { Encounter } from "./app.models";

export interface DoctorEncounters {
    date: string;
    emrs: Encounter;
}
