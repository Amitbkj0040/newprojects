const LOCAL_API_BASE_URL = 'http://localhost:3000';

export class APIEndPoint {
    // CLINIC APi
    public static CREATE_CLINIC: APIDef = { 'method': 'POST', api: () => 'api/clinics' };
    public static UPDATE_CLINIC: APIDef = {
        'method': 'PUT', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}`
    };
    public static GET_CLINICS: APIDef = { 'method': 'GET', api: () => 'api/clinics' };
    public static GET_CLINIC_BY_ID: APIDef = { 'method': 'GET', api: (input: APIInput) => `api/clinics/${input.clinicId}` };
    public static UPDATE_CLINIC_AGREEMENT: APIDef = {
        'method': 'PUT', api: (input: APIInput) => `api/clinic/${input.clinicId}/agreement`
    };


    // FACILITY API
    public static CREATE_FACILITY: APIDef = {
        'method': 'POST', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities`
    };
    public static UPDATE_FACILITY: APIDef = {
        'method': 'PUT', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}`
    };
    public static GET_FACILITIES: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities`
    };
    public static DELETE_FACILITY: APIDef = {
        'method': 'DELETE', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities`
    };
    public static DELETE_FACILITY_BY_ID: APIDef = {
        'method': 'DELETE', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}`
    };
    public static GET_FACILITY_BY_ID: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}`
    };

    // OTP API
    public static CREATE_OTP: APIDef = { 'method': 'POST', api: () => 'api/otps/registerUser' };
    public static FORGET_PASSWORD: APIDef = { 'method': 'POST', api: () => 'api/otps/resetPassword' };


    // STAFF API
    public static GET_STAFF: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/staffs`
    };
    public static GET_STAFF_BY_ID: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/staffs/${input.staffId}`
    };
    public static CREATE_STAFF: APIDef = {
        'method': 'POST', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/staffs`
    };
    public static DELETE_STAFF_BY_ID: APIDef = {
        'method': 'DELETE', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/staffs/${input.staffId}`
    };
    public static UPDATE_STAFF: APIDef = {
        'method': 'PUT', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/staffs/${input.staffId}`
    };

    // SUPPORT STAFF API
    public static GET_SUPPORT_STAFF_BY_ID: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/supportStaffs/${input.staffId}`
    };
    public static GET_SUPPORT_STAFF: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/supportStaffs`
    };
    // public static  GET_SUPPORT_STAFF_BY_ID: APIDef = {'method': 'GET', api: (input: APIInput) =>
    // `api/clinics/${input.clinicId}/supportStaffs/${input.supportStaffId}`};
    public static CREATE_SUPPORT_STAFF: APIDef = {
        'method': 'POST', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/supportStaffs`
    };
    public static DELETE_SUPPORT_STAFF_BY_ID: APIDef = {
        'method': 'DELETE', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/deleteSupportStaffs/${input.staffId}`
    };
    public static UPDATE_SUPPORT_STAFF: APIDef = {
        'method': 'PUT', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/supportStaffs/${input.staffId}`
    };

    // DOCTOR API
    public static GET_DOCTORS: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/doctors`
    };
    public static CREATE_DOCTOR: APIDef = {
        'method': 'POST', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/doctors`
    };
    public static UPDATE_DOCTOR: APIDef = {
        'method': 'PUT', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/doctors/${input.doctorId}`
    };
    public static GET_DOCTOR_BY_ID: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/doctors/${input.doctorId}`
    };
    public static DELETE_DOCTOR_BY_ID: APIDef = {
        'method': 'DELETE', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/doctors/${input.doctorId}`
    };

    public static GET_PUBLIC_DOCTORS: APIDef = {
        'method': 'GET', api: () =>
            `/api/publicDoctorProfiles`
    };

    // CITIES API
    public static GET_CITIES: APIDef = { 'method': 'GET', api: (input: APIInput) => `api/country/${input.countryId}/cities` };

    // COUNTRIES API
    public static GET_COUNTRIES: APIDef = { 'method': 'GET', api: () => 'api/countries' };

    // SPECIALTIES API
    public static GET_SPECIALITIES: APIDef = { 'method': 'GET', api: () => 'api/specialities' };

    // APPOINTMENT API
    public static GET_SLOTS_APPOINTMENTS: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/doctors/${input.doctorId}/slot-appointments`
    };
    public static GET_APPOINTMENT_BY_ID: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/doctors/${input.doctorId}/appointments/${input.appointmentId}`
    };
    public static GET_APPOINTMENTS: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/doctors/${input.doctorId}/appointments`
    };
    public static CREATE_APPOINTMENT: APIDef = {
        'method': 'POST', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/doctors/${input.doctorId}/appointments`
    };
    public static CREATE_WALKIN_APPOINTMENT: APIDef = {
        'method': 'POST', api: (input: APIInput) =>
            // tslint:disable-next-line:max-line-length
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/doctors/${input.doctorId}/patients/${input.patientId}/appointments`
    };
    public static UPDATE_APPOINTMENT: APIDef = {
        'method': 'PUT', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/doctors/${input.doctorId}/appointments/${input.appointmentId}`
    };
    public static DELETE_APPOINTMENT_BY_ID: APIDef = {
        'method': 'DELETE', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/doctors/${input.doctorId}/appointments/${input.appointmentId}`
    };


    public static GET_PHYSICALEXAM_BY_APPOINTMENT_ID: APIDef = {
        'method': 'GET',
        api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/appointments/${input.appointmentId}/physicalExams`
    };

    public static UPDATE_PHYSICALEXAM_BY_APPOINTMENT_ID: APIDef = {
        'method': 'PUT',
        api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/appointments/${input.appointmentId}/physicalExams`
    };

    // Staff-Schedule Api
    public static CREATE_STAFF_SCHEDULE: APIDef = {
        'method': 'POST', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/staffs/${input.staffId}/schedules`
    };
    public static GET_STAFF_SCHEDULES: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/staffs/${input.staffId}/schedules`
    };
    public static GET_STAFF_SCHEDULE_BY_ID: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/staffs/${input.staffId}/schedules/${input.scheduleId}`
    };
    public static UPDATE_STAFF_SCHEDULE_BY_ID: APIDef = {
        'method': 'PUT', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/staffs/${input.staffId}/schedules/${input.scheduleId}`
    };
    public static DELETE_STAFF_SCHEDULE: APIDef = {
        'method': 'DELETE', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/staffs/${input.staffId}/schedules`
    };
    public static DELETE_STAFF_SCHEDULE_BY_ID: APIDef = {
        'method': 'DELETE', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/staffs/${input.staffId}/schedules/${input.scheduleId}`
    };

    // Encounter Api
    public static GET_ENCOUNTERS_BY_PATIENT_ID: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/doctors/${input.doctorId}/patients/${input.patientId}/encounters`
    };
    public static GET_ENCOUNTERS_WITH_DOC: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/doctors/${input.doctorId}/patients/${input.patientId}/encounters`
    };
    public static GET_ENCOUNTER_BY_ID: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/patients/${input.patientId}/encounters/${input.encounterId}`
    };
    public static CREATE_ENCOUNTER: APIDef = {
        'method': 'POST', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/patients/${input.patientId}/encounters`
    };
    public static UPDATE_ENCOUNTER: APIDef = {
        'method': 'PUT', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/patients/${input.patientId}/encounters/${input.encounterId}`
    };
    public static SHARE_PRESCRIPTION: APIDef = {
        'method': 'POST', api: (input: APIInput) =>
            // tslint:disable-next-line:max-line-length
            `/api/clinics/${input.clinicId}/facilities/${input.facilityId}/doctors/${input.doctorId}/patients/${input.patientId}/encounter/sharePrescription`
    };

    public static GET_DOCTOR_ENCOUNTERS: APIDef = {
        'method': 'GET',
        api: (input: APIInput) =>
            `/api/clinics/${input.clinicId}/facilities/${input.facilityId}/doctors/${input.doctorId}/encounters`
    };


    // Medicine tag list 
    public static GET_TAGLIST_BY_MED_ID: APIDef = {
        'method': 'GET',
        api: () => `gm/api/MedicineTag/Find`
    };
    public static GET_INSTUCTIONS_BY_TAG_ID: APIDef = {
        'method': 'GET',
        api: () => `gm/api/TagInstruction/Find`
    };
    // Encounter-Shared Document
    public static GET_ALL_ENCOUNTERS: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/staffs/${input.staffId}/accessibleDocuments`
    };
    public static GET_SHARED_ENCOUNTER_BY_ID: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/staffs/${input.staffId}/emrs/${input.encounterId}/Documents`
    };

    public static GET_DOCUMENT_BY_ID: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/documents/${input.documentId}`
    };
    public static GET_ENCOUNTER_SHARED_BY_ME: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/staffs/${input.staffId}/sharedEncounterByMe`
    };
    public static GET_ENCOUNTER_SHARED_WITH_ME: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/staffs/${input.staffId}/sharedEncounterwithMe`
    };
    public static GRANT_SHARED_ENCOUNTER: APIDef = {
        'method': 'PUT', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/emrs/${input.emrId}/grant`
    };
    public static REVOKE_SHARED_ENCOUNTER: APIDef = {
        'method': 'PUT', api: (input: APIInput) =>
            // tslint:disable-next-line:max-line-length
            `api/clinics/${input.clinicId}/doctors/${input.doctorId}/revoke`
    };
    public static GET_ACCESS_PERMISSION_LIST: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            // tslint:disable-next-line:max-line-length
            `/api/clinics/${input.clinicId}/staffs/${input.staffId}/emrs/${input.encounterId}/sharedEncounterAccess`
    };

    // IMPORT PATIENT

    // public static UPLOAD_CSV: APIDef = {
    //     'method': 'POST', api: (input: APIInput) =>
    //         `api/clinics/${input.clinicId}/patients/uploadBasicPreview`
    // };
    public static UPLOAD_ORIENTATION: APIDef = {
        'method': 'POST', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/patients/uploadPreviewOrientation`
    };
    public static UPLOAD_HEADERS: APIDef = {
        'method': 'POST', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/patients/uploadPreviewHeaders`
    };
    public static GET_IMPORT_DATA_FIELDS_NAME: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/fields`
    };

    // PATIENT API
    public static CREATE_PATIENT: APIDef = {
        'method': 'POST', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/patients`
    };
    public static UPDATE_PATIENT: APIDef = {
        'method': 'PUT', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/patients/${input.patientId}`
    };
    public static GET_PATIENT_BY_ID: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/patients/${input.patientId}`
    };
    public static GET_PATIENTS: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/patients`
    };
    public static DELETE_PATIENT_BY_ID: APIDef = {
        'method': 'DELETE', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/patients/${input.patientId}`
    };

    // meta controllers
    public static GET_COMPLAINTS: APIDef = { 'method': 'GET', api: () => `api/meta/complaints` };
    public static GET_MED_TIMES: APIDef = { 'method': 'GET', api: () => `api/meta/times` };
    public static GET_OBSERVATIONS: APIDef = { 'method': 'GET', api: () => `api/meta/observations` };
    public static GET_QUANTITIES: APIDef = { 'method': 'GET', api: (input: APIInput) => `api/meta/quantities` };
    public static GET_MED_SCHEDULES: APIDef = { 'method': 'GET', api: (input: APIInput) => `api/meta/schedules` };
    public static GET_MED_FREQUENCIES: APIDef = { 'method': 'GET', api: (input: APIInput) => `api/meta/frequencies` };
    public static GET_MED_DURATION: APIDef = { 'method': 'GET', api: (input: APIInput) => `api/meta/durations` };
    public static GET_MED_ROUTES: APIDef = { 'method': 'GET', api: () => `api/meta/routes` };
    public static GET_MEDICINES: APIDef = { 'method': 'GET', api: (input: APIInput) => `api/meta/medicines` };
    public static GET_DIAGNOSIS: APIDef = { 'method': 'GET', api: (input: APIInput) => `api/meta/diagnosis` };
    public static GET_INVESTIGATIONS: APIDef = { 'method': 'GET', api: (input: APIInput) => `api/meta/investigations` };
    public static GET_PHYSICALEXAMS: APIDef = { 'method': 'GET', api: () => `api/meta/metaVitals` };
    public static GET_DOCUMENT_TYPE: APIDef = { 'method': 'GET', api: () => `api/meta/documentTypes` };
    public static GET_DOCUMENT_TYPE_FOR_MT: APIDef = { 'method': 'GET', api: () => `api/DocumentType` };

    // users
    public static GET_DOMAIN: APIDef = { 'method': 'GET', api: () => `api/clinic/domain` };
    public static RESET_PASSWORD: APIDef = { 'method': 'POST', api: () => `api/reset-password` };
    public static CHANGE_PASSWORD: APIDef = { 'method': 'POST', api: () => `api/change-password` };
    public static GET_LOGIN_NAME: APIDef = { 'method': 'GET', api: () => `api/clinic/user-name` };
    public static CREATE_USER: APIDef = { 'method': 'POST', api: () => 'api/users' };

    // healthController


    // file controller
    public static DOWNLOAD_FILE: APIDef = { 'method': 'GET', api: (input: APIInput) => `api/downloadFile/${input.documentId}` };
    public static UPLOAD_FILE: APIDef = { 'method': 'POST', api: () => `uploadFile` };
    public static UPLOAD_FILES: APIDef = { 'method': 'POST', api: () => `uploadMultipleFiles` };

    // subscription controller
    // public static GET_ACTIVE_SUBSCRIPTION: APIDef = {
    //     'method': 'GET', api: (input: APIInput) =>
    //         `api/clinics/${input.clinicId}/subscriptions`
    // };
    public static GET_ALL_SUBSCRIPTIONS: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/subscriptions`
    };

    public static GET_FORMATES: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/events/${input.eventName}/formats`
    };


    public static GET_ALL_PRINT_PREFERENCE: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/printPreferences`
    };

    public static GET_PRINT_PREFERENCE_BY_DOCTORID: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/doctor/${input.doctorId}/printPreferences`
    };

    public static POST_PRINT_PREFERENCE: APIDef = {
        'method': 'POST', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/doctors/${input.doctorId}/printPreference`
    };

    public static GET_PRINT_PREFERENCE_BY_ID: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/{clinicId}/doctors/{doctorId}/printPreference/{printPreferenceId}`
    };

    public static UPDATE_PRINT_PREFERENCE_BY_ID: APIDef = {
        'method': 'PUT', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/doctors/{doctorId}/printPreference/${input.printPreferenceId}`
    };

    public static DELETE_PRINT_PREFERENCE_BY_ID: APIDef = {
        'method': 'DELETE', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/doctors/{doctorId}/printPreference/${input.printPreferenceId}`
    };

    // Non Availability
    public static GET_SUBSTITUTE_DOCTOR: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/doctorSubstitutes`
    };

    public static GET_ALL_NON_AVAILABILITY: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/staffs/${input.staffId}/nonAvailabilities`
    };

    public static GET_NON_AVAILABILITY_BY_ID: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            // tslint:disable-next-line:max-line-length
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/staffs/${input.staffId}/nonAvailabilities/${input.nonAvailabilityId}`
    };

    public static POST_NON_AVAILABLITY: APIDef = {
        'method': 'POST', api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/staffs/${input.staffId}/nonAvailabilities`
    };
    public static UPDATE_NON_AVAILABILITY_BY_ID: APIDef = {
        'method': 'PUT', api: (input: APIInput) =>
            // tslint:disable-next-line:max-line-length
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/staffs/${input.staffId}/nonAvailabilities/${input.nonAvailabilityId}`
    };
    public static DELETE_NON_AVAILABILITY_BY_ID: APIDef = {
        'method': 'DELETE', api: (input: APIInput) =>
            // tslint:disable-next-line:max-line-length
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/staffs/${input.staffId}/nonAvailabilities/${input.nonAvailabilityId}`
    };

    // Virtual Appointmnet
    public static CREATE_VIRTUAL_APPOINTMENT: APIDef = {
        'method': 'POST',
        api: (input: APIInput) =>
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/doctors/${input.doctorId}/virtualAppointments`
    };

    public static UPDATE_VIRTUAL_APPOINTMENT: APIDef = {
        'method': 'PUT',
        api: (input: APIInput) =>
            // tslint:disable-next-line: max-line-length
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/doctors/${input.doctorId}/virtualAppointments/${input.appointmentId}`
    };

    public static GET_VIRTUAL_APPOINTMENT_BY_ID: APIDef = {
        'method': 'GET',
        api: (input: APIInput) =>
            // tslint:disable-next-line: max-line-length
            `api/clinics/${input.clinicId}/facilities/${input.facilityId}/doctors/${input.doctorId}/virtualAppointments/${input.appointmentId}`
    };

    public static GET_ALL_PARTICIPANTS: APIDef = {
        'method': 'GET',
        api: (input: APIInput) =>
            `/api/clinics/${input.clinicId}/participants`
    };

    public static GET_METAVITALS: APIDef = {
        'method': 'GET',
        api: () =>
            `${LOCAL_API_BASE_URL}/metaVitals`
    };

    // SHARED VITAL

    public static GET_SHARED_VITAL_BY_SHAREWITHID: APIDef = {
        'method': 'GET', api: (input: APIInput) =>
            `api/patients/shareVitals/sharedWith/${input.sharedWithId}/view`
    };


}

export interface APIDef {
    method: string;
    api: any;
}

export interface APIInput {
    clinicId?: string;
    facilityId?: string;
    staffId?: string;
    // supportStaffId: string;
    doctorId?: string;
    appointmentId?: string;
    scheduleId?: string;
    patientId?: string;
    encounterId?: string;
    medicineName?: string;
    fileName?: string;
    documentId?: string;
    eventName?: string;
    printPreferenceId?: string;
    nonAvailabilityId?: string;
    sharedDataId?: string;
    virtualAppointmentId?: string;
    emrId?: any;
    sharedWithId?: string;
    countryId?: string;
}
