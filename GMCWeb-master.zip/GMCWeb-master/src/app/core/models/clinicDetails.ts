// clinic details interface
export interface ClinicDetails {
    id?: string;
    gstin: string;
    address: {
        address1: string,
        address2?: string,
        addressType: string,
        city: {
            id: number,
            // state: {
            //     country: {
            //         id: number
            //     },
            //     id: number
            // }
        },
        zip: string
    };
    email: string;
    clinicFacilityType?: string;
    isDisplayed: boolean;
    phone: string;
    landLine: string;
    description: string;
    domainName: string;
    logo?: string;
    name: string;
    portalURL?: string;
    registrationId: string;
    isAgreementSigned?: boolean;
    isSubscriptionActive?: boolean;
    specialities: [{
        id: number;
    }];
}


