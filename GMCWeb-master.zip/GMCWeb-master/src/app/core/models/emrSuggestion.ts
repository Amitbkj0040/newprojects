export interface EMRSuggestion {
    id: number;
    emr: object;
    name: string;
    recommended: string;
    avoid: string;
}





