import { TestBed, async, inject } from '@angular/core/testing';

import { SubscriptionRouteGuardGuard } from './subscription-route-guard.guard';

describe('SubscriptionRouteGuardGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [SubscriptionRouteGuardGuard]
    });
  });

  it('should ...', inject([SubscriptionRouteGuardGuard], (guard: SubscriptionRouteGuardGuard) => {
    expect(guard).toBeTruthy();
  }));
});
