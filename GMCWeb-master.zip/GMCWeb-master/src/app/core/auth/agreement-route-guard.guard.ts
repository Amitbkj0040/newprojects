import { Injectable, OnInit, OnDestroy } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import { AuthService } from './auth.service';
import { ClinicDetails } from 'app/core/models/clinicDetails';
import { RestapiService } from 'app/core/services/restapi.service';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';

@Injectable()
export class AgreementRouteGuardGuard implements CanActivate, OnInit, OnDestroy {
  private unsubscribe = new Subject<void>();
  public clinicId: string;
  public isSubscriptionActive: Boolean;
  constructor(public router: Router,
    private restapiservice: RestapiService,
    public authService: AuthService,
  ) { }
  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    this.clinicId = this.authService.getClinicId();
    return this.restapiservice
      .invoke<ClinicDetails>(APIEndPoint.GET_CLINIC_BY_ID,
        { clinicId: this.clinicId }).takeUntil(this.unsubscribe).map((response) => {
          console.log('response fm clinic', response);
          if (this.authService.isUserAdmin() && response.isAgreementSigned) {
            return true;
          } else if (!response.isAgreementSigned && this.authService.isUserAdmin()) {
            this.router.navigate(['/agreement']);
            return false;
          } else if (!response.isAgreementSigned && !(this.authService.isUserAdmin())) {
            this.router.navigate(['/agreement'], {
              queryParams: {
                isUnsigned: true
              }
            });
            return false;
          } else {
            return true;
          }
        });
  }

  ngOnInit() {
    this.clinicId = this.authService.getClinicId();
  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
