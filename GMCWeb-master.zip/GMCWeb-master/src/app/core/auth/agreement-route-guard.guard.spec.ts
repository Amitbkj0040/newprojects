import { TestBed, async, inject } from '@angular/core/testing';

import { AgreementRouteGuardGuard } from './agreement-route-guard.guard';

describe('AgreementRouteGuardGuard', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AgreementRouteGuardGuard]
    });
  });

  it('should ...', inject([AgreementRouteGuardGuard], (guard: AgreementRouteGuardGuard) => {
    expect(guard).toBeTruthy();
  }));
});
