import { Injectable, OnInit, OnDestroy } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { RestapiService } from 'app/core/services/restapi.service';
import { APIEndPoint } from 'app/core/models/ApiEndPoint';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs/Subject';
import { AuthService } from './auth.service';
import { ClinicDetails } from 'app/core/models/clinicDetails';


@Injectable()
export class SubscriptionRouteGuardGuard implements CanActivate, OnInit, OnDestroy {
  private unsubscribe = new Subject<void>();
  public clinicId: string;
  public isSubscriptionActive: Boolean;
  constructor(public router: Router,
    private restapiservice: RestapiService,
    public authService: AuthService,
  ) { }

  canActivate(
    next: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean> | Promise<boolean> | boolean {
    this.clinicId = this.authService.getClinicId();
    return this.restapiservice
      .invoke<ClinicDetails>(APIEndPoint.GET_CLINIC_BY_ID,
        { clinicId: this.clinicId }).takeUntil(this.unsubscribe).map((response) => {
          console.log('response fm clinic', response);
          if (!response.isSubscriptionActive) {
            this.router.navigate(['/subscription']);
            return false;
          } else {
            return true;
          }
        });
  }

  ngOnInit() {
    this.clinicId = this.authService.getClinicId();
    console.log('clinic id', this.clinicId);

  }

  ngOnDestroy() {
    this.unsubscribe.next();
    this.unsubscribe.complete();
  }
}
