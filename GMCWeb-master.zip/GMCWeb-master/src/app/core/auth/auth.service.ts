import { OnInit, OnDestroy } from '@angular/core';
import { Cookie } from 'ng2-cookies';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/delay';
import 'rxjs/add/operator/map';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { AuthToken, StaffType } from 'app/core/models/app.models';
import { Injectable } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { JwtHelperService } from './jwt-helper.service';
import { RestapiService } from 'app/core/services/restapi.service';
import { Subject } from 'rxjs/Subject';



@Injectable()
export class AuthService implements OnInit, OnDestroy {
    // Assuming this would be cached somehow from a login call.
    public authTokenStale = 'stale_auth_token';
    public authTokenNew = 'new_auth_token';
    public currentToken: string;
    private decodedToken: any;
    private refreshToken: string;
    private unsubscribe = new Subject<void>();
    constructor(
        private router: Router,
        private http: HttpClient,
        private jwt: JwtHelperService,
        private api: RestapiService,
        private toastrService: ToastrService/* , private jwtHelper: JwtHelperService */) {
        this.setCurrentTokens(Cookie.get('access_token'), Cookie.get('refresh_token'));
    }

    getAuthToken() {
        return this.currentToken;
    }

    getTokenExpirationDate() {
        // return this.jwtHelper.getTokenExpirationDate(this.currentToken);
        return new Date();
    }

    saveToken(token: AuthToken) {
        const expireDate = new Date().getTime() + (1000 * token.expires_in);
        Cookie.set('access_token', token.access_token, expireDate, '/');
        Cookie.set('refresh_token', token.refresh_token, expireDate, '/');
        console.log('Obtained Access token');
        this.setCurrentTokens(token.access_token, token.refresh_token);
    }

    deleteToken() {
        Cookie.delete('access_token', '/');
        Cookie.delete('refresh_token', '/');
        this.setCurrentTokens(null, null);
    }

    private setCurrentTokens(accessToken: string, refreshToken: string) {
        this.currentToken = accessToken;
        this.refreshToken = refreshToken;
        if (this.currentToken) {
            this.decodedToken = this.jwt.decodeToken(this.currentToken);
        } else {
            this.decodedToken = null;
        }
    }

    refreshAccessToken(): Observable<string> {
        /*
            The call that goes in here will use the existing refresh token to call
            a method on the oAuth server (usually called refreshToken) to get a new
            authorization token for the API calls.
        */

        const params = new URLSearchParams();
        params.append('grant_type', 'refresh_token');
        params.append('refresh_token', this.refreshToken);
        // params.append('client_id', 'gmc-client');
        const headers = new HttpHeaders({
            'Content-type': 'application/x-www-form-urlencoded; charset=utf-8',
            'Authorization': 'Basic ' + btoa('gmc-client:password1234')
        });
        const httpOptions = { headers: headers };
        console.log(params.toString());
        return this.http.post<AuthToken>('oauth/token',
            params.toString(),
            httpOptions).flatMap(data => {
                console.log('refresh data set', data);
                this.saveToken(data);
                return Observable.of(this.currentToken).delay(200);
            });

    }

    loginAndSetTokens(username: string, password: string): Observable<AuthToken> {
        const params = new URLSearchParams();
        params.append('username', username);
        params.append('password', password);
        params.append('grant_type', 'password');
        params.append('client_id', 'gmc-client');
        params.append('client_secret', 'password1234');
        const headers = new HttpHeaders({
            'Content-type': 'application/x-www-form-urlencoded; charset=utf-8',
            // 'Authorization': 'Basic ' + btoa('gmc-client:password1234')
        });
        const httpOptions = { headers: headers };
        console.log(params.toString());
        return this.http.post<AuthToken>('oauth/token',
            params.toString(),
            httpOptions).map(data => {
                console.log('login data set', data);
                this.saveToken(data);
                return data;
            });
    }

    logoutUser() {
        // Route to the login page (implementation up to you)
        this.deleteToken();
        // this.router.navigate(['login']);
        return Observable.of('');
    }


    public getClinicId() {
        return this.decodedToken.clinic;
    }

    public getDoctorId() {
        return this.decodedToken.doctor;
    }

    public getFacilityId() {
        if (this.decodedToken.facilities && this.decodedToken.facilities.length > 0) {
            return this.decodedToken.facilities[0];
        }
    }

    public getStaffId() {
        return this.decodedToken.staff;
    }

    public getdomainName(): string {
        return this.decodedToken.domainName;
    }

    public isUserDoctor() {
        return this.decodedToken.roles.includes(StaffType.DOCTOR);
    }

    public getRoles() {
        return this.decodedToken.roles;
    }
    public isUserAdmin() {
        return this.decodedToken.roles.includes(StaffType.ADMIN);
    }

    public isVirtualClinic(): boolean {
        return  this.decodedToken.isVirtualClinic;
    }

    public isUserSupportStaff(): boolean {
        return this.decodedToken.roles.includes(StaffType.SUPPORT_STAFF);
    }

    ngOnInit() { }

    ngOnDestroy() {
        this.unsubscribe.next();
        this.unsubscribe.complete();
    }
}
