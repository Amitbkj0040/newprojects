import { Injectable } from '@angular/core';
import { APIDef, APIEndPoint } from '../models/ApiEndPoint';
import { RestapiService } from './restapi.service';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class UniqueNameService {
  // public getUniqueNameApi: APIDef;
  constructor(public restapiService: RestapiService) { }

  getDomainOrLoginName(uniqueNameObject: Object, getUniqueNameApi: APIDef): Observable<boolean> {
    console.log(uniqueNameObject);
    return this.restapiService.invoke<any>(getUniqueNameApi, null, null, uniqueNameObject).map(resp => {
      console.log('domain ka resp', resp);
      return true;
    }).catch(err => Observable.of(false));
  }
}
