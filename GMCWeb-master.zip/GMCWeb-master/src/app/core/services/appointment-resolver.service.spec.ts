import { TestBed, inject } from '@angular/core/testing';

import { AppointmentResolverService } from './appointment-resolver.service';

describe('AppointmentResolverService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AppointmentResolverService]
    });
  });

  it('should be created', inject([AppointmentResolverService], (service: AppointmentResolverService) => {
    expect(service).toBeTruthy();
  }));
});
