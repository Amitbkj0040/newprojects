import { Injectable } from '@angular/core';
import { GMParam, Doctor, Facility, Staff } from '../models/app.models';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class ParamSelectionService {
  private paramSubject = new BehaviorSubject<GMParam>({});
  private param$ = this.paramSubject.asObservable();

  constructor() { }

  setParam(key: 'doctor' | 'staff' | 'facility', value: Doctor | Facility | Staff) {
    const param = this.paramSubject.getValue();
    param[key] = value;
    this.paramSubject.next(param);
  }

  params(): Observable<GMParam> {
    return this.param$;
  }
}
