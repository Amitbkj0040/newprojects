import { Injectable } from '@angular/core';
import { RestapiService } from './restapi.service';
import { Router, Resolve, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { Doctor, Facility } from '../models/app.models';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class AppointmentResolverService implements Resolve<{ doctor: Doctor, facility: Facility }> {
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<{ doctor: Doctor, facility: Facility }> {
    throw new Error('Method not implemented.');
  }

  constructor(apiService: RestapiService, router: Router) { }



}
