import { Injectable } from '@angular/core';
import POSTCODEREGEX from '../models/PostCodeRegx';

@Injectable()
export class PostCodeValidatorService {

  constructor() { }

  validate(country, code) {
    const countryUpperCase = country.toUpperCase();
    if (POSTCODEREGEX.hasOwnProperty(countryUpperCase)) {
      return POSTCODEREGEX[countryUpperCase].test(code);
    } else {
      // Error out if the country code is not recognised
      throw new Error(`Invalid country code: ${countryUpperCase}`);
    }
  }

  isZipCodeRequired(countryCode) {
    const countryUpperCase = countryCode ? countryCode.toUpperCase() : null;
    return POSTCODEREGEX.hasOwnProperty(countryUpperCase);
  }

}
