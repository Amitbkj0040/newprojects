import { TestBed, inject } from '@angular/core/testing';

import { ClinicServiceService } from './clinic-service.service';

describe('ClinicServiceService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ClinicServiceService]
    });
  });

  it('should be created', inject([ClinicServiceService], (service: ClinicServiceService) => {
    expect(service).toBeTruthy();
  }));
});
