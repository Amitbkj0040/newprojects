import { Injectable } from '@angular/core';
import { Patient, Appointment } from 'app/core/models/app.models';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class AppointmentEncounterService {

  private appointmentSubject = new Subject<{ appointment: Appointment, appointmentIndex: number, isClose: boolean }>();
  private appointment$ = this.appointmentSubject.asObservable();
  private startedAppointmentSubject = new Subject<{ appointment, appointmentIndex }>();
  private startedAppointment$ = this.startedAppointmentSubject.asObservable();
  private closeAppointmentSubject = new Subject<Appointment>();
  private skipAppointmentSubject = new Subject<Appointment>();
  private closedAppointment$ = this.closeAppointmentSubject.asObservable();
  private skipAppointment$ = this.skipAppointmentSubject.asObservable();
  private selectedAppointmentIndexAndTotalEncounter = new Subject<{ selectedAppointementIndex: number, totalEncounter: number }>();
  private selectedAppointmentIndexAndTotalEncounter$ = this.selectedAppointmentIndexAndTotalEncounter.asObservable();

  constructor() { }

  startEncounterForAppointment(appointment: Appointment, appointmentIndex: number, isClose: boolean) {
    this.appointmentSubject.next({ appointment: appointment, appointmentIndex: appointmentIndex, isClose: isClose });
  }
  setSelectedAppointmentIndexAndTotalEncounter(selectedAppointementIndex: number, totalEncounter: number) {
    this.selectedAppointmentIndexAndTotalEncounter.next({
      selectedAppointementIndex: selectedAppointementIndex,
      totalEncounter: totalEncounter
    });
  }

  closeAppointment(appointment: Appointment) {
    this.closeAppointmentSubject.next(appointment);
  }

  skipAppointment(appointment: Appointment) {
    this.skipAppointmentSubject.next(appointment);
  }

  getSkipAppointment(): Observable<Appointment> {
    return this.skipAppointment$;
  }

  getStartedAppointment(): Observable<{ appointment, appointmentIndex }> {
    return this.startedAppointment$;
  }

  appointmentStarted(appointment: Appointment, appointmentIndex: number) {
    return this.startedAppointmentSubject.next({ appointment: appointment, appointmentIndex: appointmentIndex });
  }

  getClosedAppointment(): Observable<Appointment> {
    return this.closedAppointment$;
  }

  getNextAppointment(): Observable<{ appointment: Appointment, appointmentIndex: number }> {
    return this.appointment$;
  }
  getselectedAppointmentIndexAndTotalEncounter() {
    return this.selectedAppointmentIndexAndTotalEncounter$;
  }
}
