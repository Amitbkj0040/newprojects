import { TestBed, inject } from '@angular/core/testing';

import { UniqueNameService } from './unique-name.service';

describe('UniqueNameService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UniqueNameService]
    });
  });

  it('should be created', inject([UniqueNameService], (service: UniqueNameService) => {
    expect(service).toBeTruthy();
  }));
});
