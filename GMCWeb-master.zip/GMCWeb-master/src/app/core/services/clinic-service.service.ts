import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Subject } from 'rxjs/Subject';
@Injectable()
export class ClinicService {

  public _changeFacility = new Subject<any>();
  public changeFacility = this._changeFacility.asObservable();

  constructor(private httpClient: HttpClient) { }

  callFacilityChange(value: any) {
    this._changeFacility.next(value);
  }

  public getClinics() {

  }

}
