import { Injectable } from '@angular/core';
import { ReplaySubject } from 'rxjs/ReplaySubject';
import { Subject } from 'rxjs/Subject';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class ConfirmationPopupService {
  public _showConfirmationPopup = new Subject<{message, showPopup}>();
  public showConfirmationPopup = this._showConfirmationPopup.asObservable();
  public _userAction = new Subject<boolean>();
  public userAction = this._userAction.asObservable();
  constructor() { }

//  public toggleConfirmationPopup(value: any) {
//     this._showConfirmationPopup.next(value);
//  }

//   public getConfirmationPopup(value: boolean) {
//     console.log('user action value', value);
//     this._userAction.next(value);
//   }

  toggle(value: boolean) {
    this._userAction.next(value);
    this._showConfirmationPopup.next({message: '', showPopup: false});
  }

  public confirm(options: {message}): Observable<boolean> {
    this._showConfirmationPopup.next({message: options.message, showPopup: true});
    return this.userAction.take(1);
  }


}
