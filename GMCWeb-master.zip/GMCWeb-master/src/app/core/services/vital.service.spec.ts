import { TestBed, inject } from '@angular/core/testing';

import { VitalService } from './vital.service';

describe('VitalService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [VitalService]
    });
  });

  it('should be created', inject([VitalService], (service: VitalService) => {
    expect(service).toBeTruthy();
  }));
});
