export const restapiUrl = {
    API_URL: '/api',
    API_VERSION: 'v1',
    API_DIR: '/',
    IMAGE_URL: 'images',
    LOGIN: 'login',
    LOGOUT : 'logout',
    STAFFSCHEDULE: 'staffSchedule',
    APPOINTMENTS: 'appointments',
    PATIENT: 'patient',
    PATIENTS: 'patients',
    OTP: 'otps',
    CLINICS: 'clinics',
    FACILITIES: 'facilities'
   };
