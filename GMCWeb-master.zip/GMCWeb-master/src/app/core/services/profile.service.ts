import { Injectable } from '@angular/core';
import { ReplaySubject } from 'rxjs/ReplaySubject';


@Injectable()
export class ProfileService {
  public profileDefault = 'assets/img/avatar.png';
  public profileImgEvent = new ReplaySubject();
  public profileImg = this.profileImgEvent.asObservable();

  constructor() {
  }

  setImage(profileImg) {
    this.profileImgEvent.next(profileImg);
  }

  getImage() {
   return this.profileImg;
  }

}
