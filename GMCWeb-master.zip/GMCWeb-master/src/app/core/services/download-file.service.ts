import { Injectable } from '@angular/core';
 import {HttpClient, HttpHeaders } from '@angular/common/http';


@Injectable()
export class DownloadFileService {
  constructor(public http: HttpClient) {}



  public downloadDocument(documentId) {
    const url = 'api/downloadFile/' + documentId;
    const headers = new HttpHeaders({ 'Content-Type': 'application/json'});
    headers.set('Accept', '*/*');
    return this.http.get(url, {headers: headers, responseType: 'blob'});
  }
  // private DOCUMENT_API_PATH = 'api/downloadFile';
  // download(documentId: string): Observable <Blob> {
  //   // set headers for the file and response to be Blob
  //   const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  //    const options = new RequestOptions({ headers: h});
  //   options.responseType = ResponseContentType.Blob;

  //   return this.http.get(`${this.DOCUMENT_API_PATH}/${documentId}`)
  //     .map((res: Response) => res)
  //     .catch(this.handleError);
  // }
  // handle error
  // private handleError (error: any) {
  //   return Observable.throw(error);
  // }

}


