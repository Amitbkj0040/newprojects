import { TestBed, inject } from '@angular/core/testing';

import { PostCodeValidatorService } from './post-code-validator.service';

describe('PostCodeValidatorService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [PostCodeValidatorService]
    });
  });

  it('should be created', inject([PostCodeValidatorService], (service: PostCodeValidatorService) => {
    expect(service).toBeTruthy();
  }));
});
