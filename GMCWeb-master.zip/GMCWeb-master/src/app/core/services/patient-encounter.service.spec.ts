import { TestBed, inject } from '@angular/core/testing';

import { AppointmentEncounterService } from './patient-encounter.service';

describe('PatientEncounterService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AppointmentEncounterService]
    });
  });

  it('should be created', inject([AppointmentEncounterService], (service: AppointmentEncounterService) => {
    expect(service).toBeTruthy();
  }));
});
