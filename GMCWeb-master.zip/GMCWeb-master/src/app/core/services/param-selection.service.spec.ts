import { TestBed, inject } from '@angular/core/testing';

import { ParamSelectionService } from './param-selection.service';

describe('ParamSelectionService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ParamSelectionService]
    });
  });

  it('should be created', inject([ParamSelectionService], (service: ParamSelectionService) => {
    expect(service).toBeTruthy();
  }));
});
