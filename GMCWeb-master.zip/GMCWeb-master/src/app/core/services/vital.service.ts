import { Injectable } from '@angular/core';
import { DoctorPhysicalExam } from '../models/DoctorPhysicalExam';

@Injectable()
export class VitalService {
  doctorPhysicalExam: DoctorPhysicalExam[];
  constructor() { }

  createMetaVitalsList(metaVitals: any, mode?: string) {
    let results: any;
    if (mode !== 'edit') {
      results = metaVitals.map((elem => {
        return {
          metaVital: elem, observedValue: null,
          metaVitalUnit: { id: elem.units[0].id },
          unit: elem.units[0]
        };
      }));
    } else {
      results = metaVitals.map((elem => {
        return {
          metaVital: elem.metaVital,
          observedValue: elem.observedValue,
          metaVitalUnit: elem.metaVitalUnit,
          unit: elem.metaVital.units.find((unit) => unit.id === elem.metaVitalUnit.id)
        };
      }));
    }
    return results;
  }

}


