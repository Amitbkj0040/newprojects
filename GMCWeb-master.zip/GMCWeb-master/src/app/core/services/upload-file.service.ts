import { Injectable } from '@angular/core';
import { HttpClient, HttpRequest, HttpEvent, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { AuthService } from 'app/core/auth/auth.service';
import { JwtHelperService } from 'app/core/auth/jwt-helper.service';
import { UploadFile } from '../models/app.models';
@Injectable()
export class UploadFileService {

  public document: UploadFile[] = [{
    documentType: null,
    entityType: null,
    URI: null,
    fileName: null
  }];

  constructor(
    private http: HttpClient,
    private authService: AuthService,
    private jwtHelper: JwtHelperService
  ) { }

  private getToken() {
    return this.jwtHelper.decodeToken(this.authService.getAuthToken());
  }

  public uploadFile(url: string, body: any) {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    headers.append('Authorization', this.getToken());
    headers.set('Accept', 'application/json');
    return this.http.post(url, body, { headers: headers });
  }
  public singleFileUploader(file: File, documentType, entityId, entityType): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);
    const queryParams = new HttpParams()
      .append('documentType', documentType)
      .append('entityType', entityType);
    if (entityId) {
      queryParams.append('entityId', entityId);
    }
    const req = new HttpRequest('POST', '/api/uploadFile', formdata, {
      params: queryParams,
      reportProgress: true,
      responseType: 'text'
    });

    return this.http.request(req);
  }

  public csvFileUploader(file: File, clinicId, requestId): Observable<HttpEvent<{}>> {
    const formdata: FormData = new FormData();
    formdata.append('file', file);
    const queryParams = new HttpParams()
      .append('clinicId', clinicId)
      .append('requestId', requestId);
    const req = new HttpRequest('POST', `/api/clinics/${clinicId}/patients/uploadBasicPreview`, formdata, {
      params: queryParams,
      reportProgress: true,
      responseType: 'text'
    });

    return this.http.request(req);
  }

  public multipleFileUploader(files: string[], documentType, entityId, entityType): Observable<HttpEvent<{}>> {
    const formData = new FormData();
    for (let i = 0; i < files.length; i++) {
      formData.append('fileUpload', files[i]);
    }
    const queryParams = new HttpParams()
      .append('documentType', documentType)
      .append('entityType', entityType)
      .append('entityId', entityId);

    const req = new HttpRequest('POST', '/api/uploadMultipleFiles', formData, {
      params: queryParams,
      reportProgress: true,
      responseType: 'text'
    });

    return this.http.request(req);
  }
}
