import { Injectable } from '@angular/core';

@Injectable()
export class UtilityService {

  constructor() { }

  public areAllFieldsNull(obj: any): boolean {
    for (const key in obj) {
      if (obj[key] !== null && obj[key] !== '') {
        return false;
      }
    }
    return true;
  }


}
