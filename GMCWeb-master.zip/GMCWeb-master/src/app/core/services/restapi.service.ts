import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { restapiUrl } from './rest-api-variable';
import { HttpClient, HttpHeaders, HttpEvent, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { APIDef, APIInput } from '../models/ApiEndPoint';
import { catchError } from 'rxjs/operators';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { ToastrService } from 'ngx-toastr';
import { query } from '@angular/animations';
import { Location } from '@angular/common';



@Injectable()
export class RestapiService {
  constructor(
    public http: HttpClient,
    private router: Router,
    public toastrService: ToastrService,
    private location: Location,
  ) { }

  invoke<T>(def: APIDef, apiInput: APIInput = {}, data?: T, queryMap?: any): Observable<T> {
    return this.invokeAPI(def.api(apiInput), def.method, data, queryMap);
  }

  // function for post
  private invokeAPI<T>(api: string, method: string, body?: T, queryMap?: any): Observable<T> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    let queryParams = new HttpParams();
    for (const property in queryMap) {
      if (queryMap.hasOwnProperty(property)) {
        // console.log(property, queryMap[property]);
        queryParams = queryParams.append(property, queryMap[property]);
      }
    }
    // queryParams.set('a1', 'a2');
    // console.log(queryParams);
    // if (queryMap) {
    //   queryMap.forEach((value: string, key: string) => {
    //     queryParams.set(key, value);
    //   });
    // }
    const httpOptions: GMCOption = { headers: headers, params: queryParams, observe: 'body' };
    switch (method) {
      case 'POST':
        return this.post<T>(api, body, httpOptions);
      case 'GET':
        return this.get<T>(api, httpOptions);
      case 'PUT':
        return this.put<T>(api, body, httpOptions);
      case 'DELETE':
        return this.delete<T>(api, httpOptions);
      default:
        break;
    }
  }

  public printHTML(url: string, templateFormat: string) {
    let queryParams = new HttpParams();
    queryParams = queryParams.append('format', templateFormat);
    const headers = new HttpHeaders({ 'Content-Type': 'text/html' });
    return this.http.get(url, { headers: headers, observe: 'response', responseType: 'text', params: queryParams });
  }

  public printPdf(url: string) {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http.get(url, { headers: headers, responseType: 'arraybuffer' });
  }

  public uploadFile(url: string, body: any, documentType: string, personId: string) {
    const formdata: FormData = new FormData();
    formdata.append('file', body);
    const headers = new HttpHeaders({ 'Content-Type': ' multipart/form-data' });
    return this.http.post(url, formdata, { headers: headers, params: { documentType: documentType, personId: personId } });
  }

  private post<T>(api: string, body: T, httpOptions: GMCOption): Observable<T> {
    return this.http.post<T>(api, body, httpOptions).catch(err => this.handleError<T>(err));
  }

  private get<T>(api: string, httpOptions: GMCOption): Observable<T> {
    return this.http.get<T>(api, httpOptions);
  }

  private put<T>(api: string, body: T, httpOptions: GMCOption): Observable<T> {
    return this.http.put<T>(api, body, httpOptions).catch(err => this.handleError<T>(err));
  }
  private delete<T>(api: string, httpOptions: GMCOption): Observable<T> {
    return this.http.delete<T>(api, httpOptions).catch(err => this.handleError<T>(err));
  }

  private handleError<T>(error: HttpErrorResponse): Observable<T> {
    if (error.error instanceof ErrorEvent) {
      // A client-side or network error occurred. Handle it accordingly.
      console.error('An error occurred:', error.error.message);
    } else if (error.status === 422 || error.status === 409 || error.status === 403) {
      // The backend returned an unsuccessful response code.
      // The response body may contain clues as to what went wrong,
      // console.error(
      //   `Backend returned code ${error.status}, ` +
      //   `body was: ${error.error}`);
      // console.log('TOASTR SERVICE #################', error.error.errorMessages);
      // this.toastrService.error(error.error.errorMessages.join('\n'));
      error.error.errorMessages.forEach(mesaage => {
        this.toastrService.error(mesaage);
      });
    }

    // return an observable with a user-facing error message
    return Observable.throw(error);
  }
}

interface GMCOption {
  headers?: HttpHeaders | {
    [header: string]: string | string[];
  };
  observe?: 'body';
  params?: HttpParams | {
    [param: string]: string | string[];
  };
  reportProgress?: boolean;
  responseType?: 'json';
  withCredentials?: boolean;
}
