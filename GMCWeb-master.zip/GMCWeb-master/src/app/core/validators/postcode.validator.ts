import { AbstractControl, ValidatorFn } from '@angular/forms';
import POSTCODEREGEX from '../models/PostCodeRegx';


export class PostCode {
    valid(countryCode: string): ValidatorFn {
        return (control: AbstractControl): { [key: string]: boolean } | null => {
            return validate(control.value, countryCode);
        };
    }
    // required(countryCode: string): ValidatorFn {
    //     return (control: AbstractControl): { [key: string]: boolean } | null => {
    //         return isZipCodeRequired(countryCode);
    //     };
    // }
}

function validate(code, countryCode) {
    const countryUpperCase = countryCode ? countryCode.toUpperCase() : null;
    if (POSTCODEREGEX.hasOwnProperty(countryUpperCase)) {
        return POSTCODEREGEX[countryUpperCase].test(code) ? null : { zipCodeValid: false };
    } else {
        // Error out if the country code is not recognised
        return null;
    }
}

// function isZipCodeRequired(countryCode) {
//     const countryUpperCase = countryCode.toUpperCase();
//     return POSTCODEREGEX.hasOwnProperty(countryUpperCase) ? null : { postCodeRequired: false };
// }


