import { AbstractControl, ValidatorFn } from '@angular/forms';
import { parsePhoneNumberFromString } from 'libphonenumber-js';
import { PhoneNumberUtil, PhoneNumber } from 'google-libphonenumber';
const phoneUtil = PhoneNumberUtil.getInstance();


export function PhoneValidator(countryCode: string): ValidatorFn {
    return (control: AbstractControl): { [key: string]: boolean } | null => {
        return phoneValidator(control.value, countryCode);
    };
}

// export declare class PhoneValidator {
//     static phoneValidate(countryCode: string): ValidatorFn;
// }

// export function ValidateUrl(control: AbstractControl) {
//     phoneValidator(control.value, 'IN');
// }

function phoneValidator(phone, countryCode: any) {
    if (phone) {
        if (phone && phone.length >= 8) {
            try {
                const number = phoneUtil.parseAndKeepRawInput(phone, countryCode.toUpperCase());
                const phoneNumber = phoneUtil.isValidNumberForRegion(number, countryCode.toUpperCase());
                if (phoneNumber) {
                    return null;
                } else {
                    return { validPhone: true };
                }
            } catch {
                console.log('error in phone lib');
                return { validPhone: true };
            }
        } else {
            return { validPhone: true };
        }
    }
}
